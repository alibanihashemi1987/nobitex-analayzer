# ADDITIONAL MODULE: AGENT DASHBOARD & SYSTEM HEALTH

Add a Persian RTL Agent Dashboard.

The dashboard must provide a clear operational overview without exposing unnecessary technical complexity.

## DASHBOARD

Show:

```text
🤖 Trading Agent

وضعیت Agent: 🟢 فعال
پایش بازار: 🟢 فعال

نوبیتکس: 🟢 متصل
Bale: 🟢 متصل
Database: 🟢 آماده

نمادهای منتخب: 12
تایم‌فریم‌ها: 4H / 1H / 15M / 5M

آخرین پایش:
08:42:15

پایش بعدی:
08:47:15

هشدارهای امروز:
3

تحلیل‌های امروز:
57
```

## HEALTH MONITORING

Track:

- Nobitex API health
- Bale API health
- Database health
- Monitoring worker health
- Last successful scan
- Last failed scan
- Number of errors
- Number of alerts

## DEGRADED STATE

If a service fails:

```text
⚠️ وضعیت سیستم

نوبیتکس: 🔴 قطع
Bale: 🟢 متصل
Database: 🟢 آماده
پایش: ⏸ متوقف

علت:
ارتباط با API نوبیتکس برقرار نیست.
```

Do not terminate the whole application because of one service failure.

## ACCEPTANCE CRITERIA

- Dashboard is Persian RTL.
- System health is visible.
- Monitoring status is visible.
- Connection problems are understandable.
- Errors are logged technically but presented simply to the user.