# External API Reference

**Not verified against live endpoints in this build** (no network access
during development — see README.md). Re-check field names/behavior
against current provider docs before deploying.

## Nobitex

Client: `app/data/nobitex/client.py:NobitexClient`

### `GET /market/udf/history` — OHLCV candles

Params: `symbol`, `resolution` (`1`,`5`,`15`,`30`,`60`,`240`,`D`), `from`,
`to` (unix seconds).

Expected response shape:
```json
{"t": [...], "o": [...], "h": [...], "l": [...], "c": [...], "v": [...], "s": "ok"}
```
`s` is `"ok"` or `"no_data"`. Any other value, missing keys, or mismatched
array lengths raise `NobitexAPIError`.

### `GET /v2/orderbook/{symbol}` — order book

Expected response shape: `{"bids": [[price, volume], ...], "asks": [...]}`.
Missing `bids`/`asks` raises `NobitexAPIError`.

### Error handling

- HTTP 429 -> `NobitexRateLimitError`
- HTTP 5xx -> `NobitexAPIError`
- HTTP 4xx -> `NobitexAPIError` (not retried)
- Timeout / connection error / malformed JSON -> retried up to 4 attempts
  with exponential backoff (`tenacity`), then raised.

## Bale Messenger Bot

Client: `app/notifications/bale/client.py:BaleClient`

Base URL: `https://tapi.bale.ai/bot{token}` (Telegram-Bot-API-compatible
for the endpoints used here).

- `POST /sendMessage` — `{"chat_id", "text", "parse_mode": "Markdown"}`
- `POST /sendPhoto` — multipart form: `chat_id`, `caption`, `photo` file

Both check `response.json()["ok"] == True`; any HTTP error or
`ok: false` raises `BaleAPIError`. Retried up to 3 attempts on
timeout/connection error only.
