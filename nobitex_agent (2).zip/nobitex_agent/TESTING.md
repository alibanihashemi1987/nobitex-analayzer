# Testing

## Running the suite

With a networked environment (recommended):

```bash
pip install -e ".[dev]"
pytest
```

Without network access (this repo was developed inside a sandboxed
container with no internet -- see README.md), a stdlib-only runner is
included:

```bash
python3 scripts/run_tests_offline.py
```

It discovers every `test_*` function in `tests/unit/test_*.py` and runs
them directly. It's fully self-contained: `scripts/offline_shims/`
ships lightweight stand-ins for the handful of third-party packages
some tests transitively import (`structlog`, `httpx`, `tenacity`,
`sqlalchemy`, `aiosqlite`, `mplfinance`, `apscheduler`) purely so those
modules can be *imported* without error -- they never perform real I/O
and are never used outside this runner. All 160 tests pass as of this
build (see SETUP_AND_UI.md's Testing section for the credential-storage,
watchlist, scheduler, and web-UI suites added alongside the First-Run
Setup/Dashboard/Bale-Control-Center modules — several of those use the
REAL `Flask` and `cryptography` packages, which are genuinely installed
here, not stood in). This is a temporary stand-in -- prefer real `pytest` once
`pip install` is available; nothing about the shims affects production
behavior since `pyproject.toml`'s real dependencies are what actually
ship.

## What's covered

- `test_indicators.py` -- SMA, MA200 warm-up gating, RSI/MFI bounds and
  directional sanity.
- `test_structure.py` -- swing detection, BOS/CHoCH after a pullback +
  breakout.
- `test_fvg.py` -- bullish/bearish FVG detection and mitigation-state
  transitions.
- `test_ict_detectors.py` -- Order Block detection (incl. ATR-warmup
  rejection), Breaker Block formation, liquidity sweep + reversal
  confirmation.
- `test_risk.py` -- long/short Entry/SL/TP calculation, R:R,
  inverted-SL rejection, opposing-level target capping.
- `test_lookahead.py` -- detector-level regression: structure breaks,
  moving averages, FVGs, and RSI computed on a truncated candle series
  are never altered by candles appended afterward.
- `test_hard_gates.py` -- Gates 1-5 individually (data validity, HTF
  structure confirmed, valid POI, premium/discount direction, valid
  R:R), plus scoring-config validation (`CategoryWeights` summing to 100).
- `test_primary_poi.py` -- the priority-ordered Primary POI selection
  (OB outranks FVG outranks OTE, wrong-direction and invalidated POIs
  excluded, no-POI-found returns `None`/zero strength).
- `test_premium_discount_scoring.py` -- the Equilibrium Buffer rule:
  Discount/Premium score full and never fail the gate; the wrong zone
  scores zero AND fails Gate 4; missing zone data doesn't fail the gate.
- `test_resolver.py` -- every case from `MANDATORY_ARCHITECTURE_CHANGE.md`
  section 6-13 and `ADDITIONAL_ARCHITECTURE_REQUIREMENTS.md` section
  10-16: both NOT_READY -> WAIT, one-sided READY -> BUY/SELL, large score
  gap picks the winner, small gap without HTF signal -> CONFLICT, small
  gap WITH a clear HTF alignment difference -> tie-broken, equal-strength
  alignment never forces a decision, CRITICAL market risk disables the
  tie-breaker, SPOT-mode SHORT stays technically READY but yields WAIT.
- `test_dual_direction_pipeline.py` -- end-to-end: builds a real
  `MarketContext`, runs `evaluate_long`/`evaluate_short`/
  `resolve_final_decision` together, asserts every category score stays
  within its configured maximum, and that re-evaluating LONG alone
  reproduces the identical result (independence guarantee).
- `test_backtest_service.py` -- the dual-direction backtester runs both
  directions at every historical step (never a BUY-only shortcut), is
  reproducible given identical inputs, and its summary report exposes
  LONG/SHORT/WAIT/CONFLICT counts rather than "BUY signals" alone.
- `test_report_serialization.py` -- round-trips real `evaluate_long`/
  `evaluate_short` output through `app/database/serialization.py` and
  back, asserting every field the Detailed Report needs (scores,
  per-factor evidence, Primary POI, risk/R:R, rejection reasons, HTF
  alignment) survives losslessly -- this is what lets the Detailed
  Report be regenerated later with zero recomputation.
- `test_reporting.py` -- the Persian reporting layer (BALE_REPORTING_
  ENGINE_REFACTOR): both Summary and Detailed reports are scanned with a
  regex for any 4+-word run of English prose and asserted to have none;
  WAIT always shows both LONG and SHORT; the inline-keyboard builder and
  its `detailed_analysis:{id}` callback parser round-trip correctly and
  reject malformed input; the Persian intent recognizer matches expected
  phrases; `translate_reason()` never leaks English (falls back safely
  for unrecognized text) and preserves embedded numbers from dynamic
  templates.
- `test_signal_service_reporting.py` -- `send_summary_report`,
  `process_and_alert`, and `handle_detailed_report_request` exercised
  with duck-typed fake `Database`/`BaleClient` doubles (no real
  SQLAlchemy/httpx needed): confirms auto-alerts stay silent on WAIT
  (cooldown-gated, BUY/SELL-only) while `send_summary_report` always
  sends, and that the detailed-report handler returns the Persian
  "not found" message for an unknown analysis_id without raising.

## What's NOT yet covered (needs a networked environment)

- `app/data/nobitex/client.py` against the real Nobitex API (response
  shape validation, retry/backoff behavior under real rate limits).
- `app/notifications/bale/client.py` against the real Bale Bot API.
- `app/database/db.py` / `AnalysisRecord` persistence (needs
  `sqlalchemy` + `aiosqlite` installed).
- `app/charts/chart_generator.py` (needs `mplfinance` installed).
- `app/scheduler/scheduler.py` (needs `apscheduler` installed).
- Individual direct unit tests for `category_liquidity.py`,
  `category_momentum.py`, `category_mtf.py`, `category_orderbook.py`,
  `category_execution.py`, and `market_risk.py` in isolation -- these
  are currently exercised only indirectly through
  `test_dual_direction_pipeline.py`'s end-to-end run. Adding crafted
  per-category unit tests (mirroring the `test_premium_discount_scoring.py`
  pattern) is a natural next hardening step.
- End-to-end integration test: real candles -> full dual-direction
  pipeline -> a persisted `AnalysisRecord`/`Signal` -> a Bale alert. Add
  this under `tests/integration/` once network access is available,
  using recorded/replayed fixture responses (not live calls) so CI
  stays deterministic.
- Multi-timeframe resampling in the backtester (see STRATEGY.md's
  "Known limitations" -- the backtester currently reuses one candle
  series for all four timeframe roles).

## Adding a lookahead-bias test for a new detector

Follow the pattern in `test_lookahead.py`: compute the detector's output
on `candles[:i]`, then again on `candles` (with more candles appended),
and assert that every output element with an index `< i` is identical
between the two runs. `test_backtest_service.py::test_backtest_is_reproducible`
does the analogous check at the full-pipeline level. If a detector's
output changes when unrelated future candles are appended, it has a
lookahead bug -- find and fix the line that's implicitly using
`len(candles)` or a global "latest" index outside of the loop bound.

## Adding a test for a new scoring category or gate

1. Import the category function directly (e.g. `score_liquidity`) and
   construct minimal `StructureState`/`LiquidityContext`/etc. fixtures by
   hand -- see `test_dual_direction_pipeline.py`'s `_swing`/`_break`
   helpers for the pattern.
2. Assert the returned points never exceed the category's configured
   maximum from `scoring_config.yaml`.
3. If the change affects a Hard Gate, add a case to `test_hard_gates.py`
   showing both the pass and fail path with a human-readable `reason`.
4. If the change affects the resolver's decision logic, add a scenario
   to `test_resolver.py` following the existing naming convention
   (`test_<condition>_<expected_outcome>`).
