# Architecture

## Data flow (one dual-direction analysis cycle)

```
NobitexClient.fetch_candles(symbol, tf) x4 roles (HTF/MTF/LTF/EXECUTION)
NobitexClient.fetch_orderbook(symbol)
        |
        v
build_market_context()             <- ONE immutable snapshot (app/domain/context.py)
        |   every shared calculation (swings, BOS/CHoCH, FVG, OB, Breaker,
        |   Mitigation Block, VI, liquidity sweeps, MA20/MA200+slope,
        |   RSI14, MFI10, ATR, Premium/Discount) computed exactly once,
        |   per timeframe role, and cached here.
        |
        +----------------------+----------------------+
        v                                              v
evaluate_long(context, config)          evaluate_short(context, config)
  (app/strategy/directional/)             (app/strategy/directional/)
  - selects Primary POI (LONG)            - selects Primary POI (SHORT)
  - scores categories A-H (LONG)          - scores categories A-H (SHORT)
  - runs Hard Gates 1-5 (LONG)            - runs Hard Gates 1-5 (SHORT)
  - computes Entry/SL/TP (LONG)           - computes Entry/SL/TP (SHORT)
  - classifies Market Risk (LONG)         - classifies Market Risk (SHORT)
        |                                              |
        +----------------------+----------------------+
                               v
              resolve_final_decision(long, short, execution_mode)
                    (app/strategy/directional/resolver.py)
                    - applies SPOT/COMMITMENT execution eligibility
                    - compares scores, tries HTF tie-break if close
                    - BUY / SELL / WAIT / CONFLICT
                               v
              process_and_alert() -> AnalysisRecord (always) +
                    Signal (BUY/SELL only) + Bale alert
```

`evaluate_long` and `evaluate_short` are pure functions of
`(direction, MarketContext, ScoringConfig, risk_profile)` — see
`app/strategy/directional/common.py:_evaluate_direction`. Calling it
twice with LONG then SHORT is a code-reuse detail only; it creates no
data dependency between the two (MANDATORY_ARCHITECTURE_CHANGE section 1).

## Module boundaries

- **`app/domain`** has zero third-party dependencies (stdlib
  `dataclasses` only — see "Why dataclasses" below). Everything else
  depends on it; it depends on nothing else. `app/domain/context.py`
  (`MarketContext`) and `app/domain/events.py` (`ScoreFactor`,
  `ScoreBreakdown`, `EventRegistry`) are the shared vocabulary between
  the scoring engine and the resolver.
- **`app/config`** — two deliberately separate files. `settings.py` is
  operational config (secrets, connection strings, scan interval).
  `scoring_config.py`/`.yaml` is every STRATEGY numeric constant
  (category weights, thresholds, risk-profile cutoffs, timeframe-role
  mapping). Never mix the two.
- **`app/data`** is the only layer allowed to talk to the network
  (Nobitex). It converts raw JSON into `Candle` objects; `only_closed()`
  (`app/data/market/timeframe.py`) is the one place that filters out the
  currently-forming candle.
- **`app/indicators` / `app/strategy/ict` / `app/strategy/liquidity` /
  `app/strategy/fibonacci` / `app/strategy/smc`** are the low-level
  detectors (unchanged from the first-generation build): pure functions
  `list[Candle] -> <detector output>`.
- **`app/domain/context.py`** calls all of the above exactly once per
  cycle and packages the results into an immutable `MarketContext`.
- **`app/strategy/scoring/`** — the 8-category deterministic scoring
  engine (Categories A-H), Hard Gates, Primary POI selection, HTF
  alignment classification, and Market Risk classification. Every
  function here is a pure function of `(direction, MarketContext-derived
  data, ScoringConfig)` — never network, never mutation.
- **`app/risk`** turns a Primary POI + direction into concrete Entry/SL/
  TP levels; raises `InvalidSetupError` rather than ever returning an
  inverted stop.
- **`app/strategy/directional/`** — `evaluate_long`, `evaluate_short`
  (thin direction-parameterized wrappers around `common.py`), and
  `resolver.py` (comparison-only, no technical analysis).
- **`app/database` / `app/tracking`** — persistence. `AnalysisRecord`
  stores every cycle's full dual-direction result (live or backtest);
  `SignalRecord` stores only cycles that resulted in BUY/SELL and tracks
  their TP/SL outcome over time.
- **`app/services`** — orchestration: `analysis_service.py` (live,
  performs the only network I/O), `backtest_service.py` (historical,
  network-free, same evaluate/resolve pipeline), `signal_service.py`
  (formatting + persistence + Bale alerting), `replay_service.py`
  (first-generation lookahead-bias regression harness, still used by
  `tests/unit/test_lookahead.py` against the individual detectors).

## Why dataclasses instead of Pydantic

The entire analytical core (`app/domain`, `app/indicators`,
`app/strategy`) is implemented with stdlib `dataclasses` rather than
Pydantic, even though the source specs describe `BaseModel`. This keeps
every non-I/O module free of third-party dependencies, so it can be
imported and unit-tested in any Python 3.12+ environment — including
fully offline ones — with zero `pip install` step. Only the I/O-facing
layers (`data/nobitex`, `notifications/bale`, `database`, `charts`,
`scheduler`) depend on third-party packages (`httpx`, `sqlalchemy`,
`mplfinance`, `apscheduler`), because they inherently need them.
`app/config/scoring_config.py` uses `PyYAML` for the same reason
`json`/`csv` would be acceptable — it's a stdlib-adjacent, dependency-light
format for the one genuinely-external config file.

## Immutability and the single-snapshot guarantee

`MarketContext` is a frozen dataclass. `build_market_context()` must be
called exactly once per analysis cycle (or once per historical timestamp
during backtesting); the result is passed unchanged into both
evaluators and the resolver. Neither evaluator mutates the context,
the other evaluator's result, or the final decision — this is what
guarantees LONG and SHORT always see identical market data
(ADDITIONAL_ARCHITECTURE_REQUIREMENTS sections 1-4).

## Timeframe hierarchy

`scoring_config.yaml: scoring.mtf_timeframes` names four roles — HTF,
MTF, LTF, EXECUTION — each mapped to a configurable timeframe string
(defaults: 4H / 1H / 15M / 5M). `MarketContext.timeframes` is keyed by
role name, not timeframe string, so category-scoring functions read
`context.timeframes["HTF"]` etc. regardless of which concrete timeframe
that role is configured to.
