# Deployment

## Docker (recommended)

```bash
cp .env.example .env   # fill in real values
docker compose up --build -d
docker compose logs -f
```

The container runs `main.py` (24/7 dual-direction scheduler). SQLite
data persists in the `agent-data` named volume, mounted at `/app/data`
inside the container — set
`DATABASE_URL=sqlite+aiosqlite:///./data/nobitex_agent.db` (the default)
so the DB file lands inside that volume. Both `AnalysisRecord` (every
cycle, both directions) and `SignalRecord` (taken trades only) tables
are created automatically on first run.

## Bare metal / VM

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e .
cp .env.example .env
python main.py
```

Run under a process supervisor (systemd, supervisord, or `docker
compose`'s own `restart: unless-stopped`) so it recovers from crashes.
A minimal systemd unit:

```ini
[Unit]
Description=Nobitex Agent
After=network.target

[Service]
WorkingDirectory=/opt/nobitex-agent
ExecStart=/opt/nobitex-agent/.venv/bin/python main.py
Restart=on-failure
EnvironmentFile=/opt/nobitex-agent/.env

[Install]
WantedBy=multi-user.target
```

## Before going live — verification checklist

Since this build was produced without network access, verify the
following against the real services before trusting live output:

- [ ] `NobitexClient.fetch_candles` against real Nobitex data: confirm
      field names in `/market/udf/history` and correct `resolution`
      values for each timeframe you use.
- [ ] `NobitexClient.fetch_orderbook` against `/v2/orderbook/{symbol}`.
- [ ] `NobitexClient.fetch_all_market_symbols` against Nobitex's real
      market-list endpoint — the Setup Wizard's symbol discovery
      (step 4) and the Bale Control Center's watchlist search depend on
      its response shape being correct.
- [ ] `BaleClient.send_message` / `send_photo` against your real bot
      token and chat ID.
- [ ] `pip install -e ".[dev]"` succeeds and `pytest` passes (this repo
      only ran a stdlib-only stand-in runner — see TESTING.md).
- [ ] Confirm `DATABASE_URL` points at a writable, persisted path/volume.
- [ ] Run `python main.py analyze <SYMBOL>` manually a few times and
      sanity-check the Entry/SL/TP levels against a real chart before
      trusting the 24/7 scheduler's alerts.
- [ ] Review `EXECUTION_MODE` (`SPOT` vs `COMMITMENT`) — SPOT never
      executes SHORT setups even if the technical analysis reports
      SHORT as READY (see STRATEGY.md's SPOT/COMMITMENT section).
- [ ] Review the category weights, risk-profile thresholds, and ATR/
      R:R multipliers in `app/config/scoring_config.yaml` against your
      own risk tolerance — the defaults are reasonable starting points
      per the source specs, not tuned/backtested values. Remember:
      `CategoryWeights` must sum to exactly 100 (validated at load time).
- [ ] Backtest against real historical data via `app/services/
      backtest_service.py:run_backtest` before trusting live signals —
      note its one documented simplification (single candle series
      reused for all timeframe roles; see STRATEGY.md).
- [ ] **Web UI security**: confirm `WEB_UI_HOST` is `127.0.0.1` unless
      you have deliberately put a firewall, VPN, or authenticating
      reverse proxy in front of the published port — the Setup Wizard/
      Dashboard/Settings have no login of their own (see SETUP_AND_UI.md).
- [ ] Complete the Setup Wizard once via a real browser and confirm
      "🔌 تست اتصال" succeeds for both Nobitex and Bale before relying
      on the agent unattended.
- [ ] If deploying with `keyring` unavailable (typical for a bare
      Docker/VPS), confirm `CredentialManager.backend_name` reports
      `encrypted_file` and that `./data/.credential_key` persists across
      container restarts (it lives in the same mounted volume as the
      database — losing it makes stored credentials unrecoverable by
      design; re-run the wizard in that case).
