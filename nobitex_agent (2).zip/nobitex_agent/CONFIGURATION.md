# Configuration Reference

Configuration is deliberately split into two files with two different
purposes — never mix numeric STRATEGY constants into `.env`, and never
put secrets/operational knobs into the YAML.

## `.env` / `app/config/settings.py` — operational config

| Variable | Default | Description |
|---|---|---|
| `NOBITEX_BASE_URL` | `https://apiv2.nobitex.ir` | Nobitex API base URL |
| `NOBITEX_API_TOKEN` | *(none)* | Nobitex API token |
| `BALE_BOT_TOKEN` | *(none)* | Bale bot token; alerts are skipped (logged as a warning) if unset |
| `BALE_CHAT_ID` | *(none)* | Target chat ID for Bale alerts |
| `DATABASE_URL` | `sqlite+aiosqlite:///./data/nobitex_agent.db` | SQLAlchemy async database URL |
| `LOG_LEVEL` | `INFO` | One of `DEBUG`/`INFO`/`WARNING`/`ERROR`/`CRITICAL` |
| `DEFAULT_SYMBOL` | `BTCIRT` | Symbol scanned by the scheduler |
| `DEFAULT_RISK_PROFILE` | `moderate` | One of the `scoring.risk_profiles` keys in `scoring_config.yaml` |
| `EXECUTION_MODE` | `SPOT` | `SPOT` (long-only execution) or `COMMITMENT` (long + short). Technical analysis always evaluates both directions regardless — this only affects which side can be traded (`MANDATORY_ARCHITECTURE_CHANGE.md` sections 12-13) |
| `SCAN_INTERVAL_SECONDS` | `300` | Scheduler poll interval |
| `ALERT_COOLDOWN_SECONDS` | `1800` | Minimum gap between repeat alerts for the same symbol |
| `CANDLE_COUNT` | `500` | Candles requested per timeframe-role fetch |
| `WEB_UI_HOST` | `127.0.0.1` | Bind address for the Setup Wizard/Dashboard/Settings web UI. **No authentication is implemented** — only change this away from loopback behind a firewall/VPN/reverse-proxy (see SETUP_AND_UI.md) |
| `WEB_UI_PORT` | `8765` | Port for the web UI |

Note: as of the Setup Wizard, `NOBITEX_API_TOKEN`/`BALE_BOT_TOKEN`/
`BALE_CHAT_ID` in `.env` are an optional power-user/headless-Docker
override — when both Nobitex and Bale credentials are present in
`.env`, `main.py` uses them directly. Otherwise these are collected
once through the browser wizard and stored via `CredentialManager`
(OS keyring or an encrypted local file — never plaintext SQLite; see
SETUP_AND_UI.md section 1), and trading configuration (risk profile,
execution mode, scan interval, alert cooldown, enabled timeframes,
monitoring toggles) lives in the database's `RuntimeConfigRecord`,
editable from the web UI or the Bale Control Center at any time without
a restart.

All fields are validated at startup (`Settings.__post_init__`); an
out-of-range or invalid value raises immediately.

## `app/config/scoring_config.yaml` / `scoring_config.py` — strategy config

Every weight, threshold, and timeframe mapping used by the scoring
engine lives here (`REPLACEMENT_MODULE.md` section 42: "Do not scatter
numerical constants across Python files"). `CategoryWeights` is
validated to sum to exactly 100 at load time.

```yaml
scoring:
  categories:            # must sum to 100
    structure: 20
    poi: 25
    liquidity: 15
    momentum: 10
    mtf: 10
    orderbook: 10
    execution: 5
    premium_discount: 5

  premium_discount:
    equilibrium: 0.50    # 50% mark of the HTF dealing range
    buffer: 0.02         # +/-2% Equilibrium Buffer around it

  execution:
    minimum_score: 3     # minimum Execution Quality (0-5) for a READY status
    early_ltf_penalty: 1 # Execution Quality penalty for an EARLY_LTF_ENTRY

  mtf_timeframes:
    htf: "4H"
    mtf: "1H"
    ltf: "15M"
    execution: "5M"

  ma20_slope_lookback: 3           # candles used for MA20 slope (section 13.A3)

  divergence:
    min_swing_distance: 5
    min_price_separation_pct: 0.1

  risk_profiles:
    conservative:
      threshold: 85
      minimum_execution: 4
      maximum_market_risk: MEDIUM
    moderate:
      threshold: 75
      minimum_execution: 3
      maximum_market_risk: HIGH
    aggressive:
      threshold: 60
      minimum_execution: 3
      maximum_market_risk: HIGH

decision:
  minimum_directional_score_difference: 8   # below this gap -> CONFLICT (or HTF tie-break)

order_block:
  strong_move_atr_multiplier: 1.5   # impulse-leg ATR threshold to qualify as an Order Block
  atr_period: 14

fvg:
  invalidation_pct: 0.5             # gap penetration fraction that marks an FVG mitigated

risk:
  r_multiples: [1.0, 2.0, 3.0]      # TP1/TP2/TP3 as multiples of initial risk
  atr_buffer_multiplier: 0.25       # SL buffer beyond the POI boundary, as a fraction of ATR
  minimum_risk_reward: 1.0          # Gate 5 / Category G threshold
```

Loaded and validated by `get_scoring_config()`
(`app/config/scoring_config.py`), cached via `functools.lru_cache`. Pass
an explicit path to load an alternate file (e.g. for tests exercising
non-default weights).

## Symbols scanned by the scheduler

`main.py`'s `run_forever()` currently scans only `settings.default_symbol`.
To scan multiple symbols, pass a list into `build_scheduler(..., symbols=[...])`
in `app/scheduler/scheduler.py` — a natural next step would be a
comma-separated `SYMBOLS` env var.
