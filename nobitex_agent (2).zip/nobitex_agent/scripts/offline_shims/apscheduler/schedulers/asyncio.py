from __future__ import annotations
class AsyncIOScheduler:
    def __init__(self, *a, **k):
        self._jobs = []
    def add_job(self, func, trigger=None, **kwargs):
        self._jobs.append((func, trigger, kwargs))
        return None
    def start(self):
        return None
    def shutdown(self, wait=True):
        return None
