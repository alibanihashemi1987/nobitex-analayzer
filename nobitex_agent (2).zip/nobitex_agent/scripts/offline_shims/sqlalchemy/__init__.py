"""Minimal offline shim for sqlalchemy -- only what app/database/models.py
and app/database/db.py need at IMPORT time. No real database operations
are performed; this exists purely so modules that transitively import
sqlalchemy can still be imported (and their non-DB functions exercised
with duck-typed fakes) in the offline test environment."""
from __future__ import annotations


class Column:
    def __init__(self, *a, **k):
        pass


def select(*a, **k):
    return None


def update(*a, **k):
    return None


class _TypeStub:
    def __init__(self, *a, **k):
        pass
    def __call__(self, *a, **k):
        return self


JSON = _TypeStub()
Float = _TypeStub()
String = _TypeStub()
DateTime = _TypeStub()


def mapped_column(*a, **k):
    return None


class Mapped:
    def __class_getitem__(cls, item):
        return cls


class DeclarativeBase:
    pass
