"""Minimal offline shim for sqlalchemy.ext.asyncio."""
from __future__ import annotations


class AsyncSession:
    pass


def async_sessionmaker(*a, **k):
    def factory(*a2, **k2):
        return None
    return factory


def create_async_engine(*a, **k):
    return None
