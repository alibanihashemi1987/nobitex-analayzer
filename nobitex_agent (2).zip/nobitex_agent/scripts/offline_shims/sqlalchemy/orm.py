"""Minimal offline shim for sqlalchemy.orm."""
from __future__ import annotations


class DeclarativeBase:
    metadata = None


class Mapped:
    def __class_getitem__(cls, item):
        return cls


def mapped_column(*a, **k):
    return None
