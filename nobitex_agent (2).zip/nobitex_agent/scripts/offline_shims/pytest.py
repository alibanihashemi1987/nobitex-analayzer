from __future__ import annotations
class _RaisesContext:
    def __init__(self, expected_exception):
        self.expected_exception = expected_exception
        self.exception = None
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            raise AssertionError(f"Expected {self.expected_exception} but no exception was raised")
        if not issubclass(exc_type, self.expected_exception):
            return False
        self.exception = exc_val
        return True
def raises(expected_exception):
    return _RaisesContext(expected_exception)
