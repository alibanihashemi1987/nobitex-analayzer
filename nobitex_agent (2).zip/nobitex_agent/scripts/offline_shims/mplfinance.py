"""Minimal offline shim for mplfinance -- just enough for
app/charts/chart_generator.py to import; .plot() is a no-op stub since
we don't need actual chart rendering for offline unit tests."""
from __future__ import annotations


def plot(*args, **kwargs):
    return None
