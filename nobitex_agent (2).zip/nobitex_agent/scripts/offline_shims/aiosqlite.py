"""Empty offline shim -- aiosqlite is only referenced indirectly via the
DATABASE_URL dialect string, never imported directly by our code."""
