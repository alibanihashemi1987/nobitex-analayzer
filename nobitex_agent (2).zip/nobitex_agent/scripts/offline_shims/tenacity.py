"""Minimal offline shim for tenacity -- decorators become no-ops so
modules using @retry(...) still import and behave (without actual
retry/backoff) in the offline test environment."""
from __future__ import annotations


def retry(*args, **kwargs):
    def decorator(fn):
        return fn
    return decorator


def retry_if_exception_type(*a, **k):
    return None


def stop_after_attempt(*a, **k):
    return None


def wait_exponential(*a, **k):
    return None
