"""Minimal offline shim for structlog -- only what app/core/logging.py's
get_logger() needs at import/call time for our offline tests. Not a
real structlog. configure() and processors are never exercised by
tests (only main.py calls configure_logging() at process startup)."""
from __future__ import annotations


class _DummyLogger:
    def _log(self, *a, **k):
        return None
    info = warning = error = exception = debug = critical = _log
    def bind(self, **k):
        return self


def get_logger(name=None):
    return _DummyLogger()


class contextvars:
    @staticmethod
    def merge_contextvars(*a, **k):
        return {}


class stdlib:
    class BoundLogger:
        pass
    class LoggerFactory:
        def __init__(self, *a, **k):
            pass
    @staticmethod
    def add_log_level(*a, **k):
        return {}


class processors:
    class TimeStamper:
        def __init__(self, *a, **k):
            pass
    class StackInfoRenderer:
        def __init__(self, *a, **k):
            pass
    class JSONRenderer:
        def __init__(self, *a, **k):
            pass
    @staticmethod
    def format_exc_info(*a, **k):
        return {}


def make_filtering_bound_logger(level):
    return _DummyLogger


def configure(*a, **k):
    return None
