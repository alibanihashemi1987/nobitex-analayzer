"""Minimal offline shim for httpx -- just enough surface area for
app/data/nobitex/client.py and app/notifications/bale/client.py to
import and be constructed in offline tests. Does not perform real
network I/O; any actual .get()/.post() call will raise NotImplementedError."""
from __future__ import annotations


class TimeoutException(Exception):
    pass


class ConnectError(Exception):
    pass


class RemoteProtocolError(Exception):
    pass


class Response:
    def __init__(self, status_code=200, text="", json_data=None):
        self.status_code = status_code
        self.text = text
        self._json = json_data or {}

    def json(self):
        return self._json


class AsyncClient:
    def __init__(self, *args, **kwargs):
        self._base_url = kwargs.get("base_url", "")
        self._headers = kwargs.get("headers", {})

    async def get(self, path, params=None):
        raise NotImplementedError("offline shim: no real network access")

    async def post(self, path, json=None, data=None, files=None):
        raise NotImplementedError("offline shim: no real network access")

    async def aclose(self):
        return None
