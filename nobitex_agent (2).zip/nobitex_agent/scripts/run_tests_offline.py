"""Offline test runner.

Runs every `test_*` function in `tests/unit/test_*.py` without requiring
pytest OR any of the project's real third-party dependencies to be
installed (this repo's sandbox has no network access).

Two things make this possible:

1. A minimal local `pytest` shim (only `pytest.raises` is used by this
   test suite).
2. `scripts/offline_shims/` -- lightweight stand-ins for `structlog`,
   `httpx`, `tenacity`, `sqlalchemy` (+ `.orm`/`.ext.asyncio`),
   `aiosqlite`, `mplfinance`, and `apscheduler`. These exist SOLELY so
   the I/O-facing modules (`app/core/logging.py`, `app/data/nobitex/
   client.py`, `app/database/db.py`, `app/notifications/bale/client.py`,
   `app/charts/chart_generator.py`, `app/scheduler/scheduler.py`) can be
   IMPORTED without error when a test transitively pulls them in (e.g.
   `app/services/signal_service.py` imports the Bale client). They do
   NOT perform real I/O -- calling an actual network/DB method on one of
   these stand-ins raises `NotImplementedError`. They are never used
   outside this offline test runner and are NOT a substitute for the
   real packages in `pyproject.toml`.

In any environment with real internet/pip access, prefer:
    pip install -e .[dev] && pytest
which uses the real dependencies throughout — no shims involved.

Usage:
    python scripts/run_tests_offline.py
"""

from __future__ import annotations

import importlib
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHIMS = Path(__file__).resolve().parent / "offline_shims"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(SHIMS))


def discover_test_modules() -> list[str]:
    test_dir = ROOT / "tests" / "unit"
    modules = []
    for path in sorted(test_dir.glob("test_*.py")):
        rel = path.relative_to(ROOT).with_suffix("")
        modules.append(".".join(rel.parts))
    return modules


def run() -> int:
    modules = discover_test_modules()
    total = 0
    failed = 0
    failures: list[tuple[str, str]] = []

    for mod_name in modules:
        try:
            module = importlib.import_module(mod_name)
        except Exception:
            print(f"[IMPORT ERROR] {mod_name}")
            traceback.print_exc()
            failed += 1
            failures.append((mod_name, "IMPORT ERROR"))
            continue

        test_funcs = [
            getattr(module, name)
            for name in dir(module)
            if name.startswith("test_") and callable(getattr(module, name))
        ]
        for fn in test_funcs:
            total += 1
            qualified = f"{mod_name}::{fn.__name__}"
            try:
                fn()
                print(f"PASS  {qualified}")
            except Exception as exc:
                failed += 1
                failures.append((qualified, f"{type(exc).__name__}: {exc}"))
                print(f"FAIL  {qualified}")
                traceback.print_exc()

    print("\n" + "=" * 60)
    print(f"Ran {total} tests, {total - failed} passed, {failed} failed")
    if failures:
        print("\nFailures:")
        for name, reason in failures:
            print(f"  - {name}: {reason}")
    print("=" * 60)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(run())
