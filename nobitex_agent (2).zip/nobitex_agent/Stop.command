#!/bin/bash
# توقف ایجنت معاملاتی نوبیتکس

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "در حال توقف ایجنت..."
pkill -f "$DIR/.venv/bin/python.*main.py" 2>/dev/null
pkill -f "python.*$DIR/main.py" 2>/dev/null
sleep 1
echo "متوقف شد."
echo "این پنجره را می‌توانید ببندید."
sleep 2
