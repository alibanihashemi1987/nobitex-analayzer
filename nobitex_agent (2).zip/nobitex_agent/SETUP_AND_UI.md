# First-Run Setup, Web UI, Watchlist, Health, and Bale Control Center

Implements the five modules in `ADDITIONAL_MODULE_*.md`. All are additive
extensions on top of the existing dual-direction analysis engine and
Bale reporting layer -- none of that logic was touched.

## 1. Credential Storage (`app/security/`)

- `credential_store.py` -- the `CredentialStore` Protocol, plus two
  implementations:
  - `KeyringCredentialStore`: delegates to the `keyring` package (OS
    Keychain / Credential Manager / Secret Service, depending on
    platform).
  - `EncryptedFileCredentialStore`: Fernet-encrypted (via `cryptography`)
    JSON file, with the key in a sibling `0600`-permission file. This is
    the realistic path for this agent's actual deployment target: a
    headless server/Docker container has no desktop keyring service.
- `credential_manager.py` -- `CredentialManager`, what the rest of the
  app actually uses. Tries the keyring backend; if it's unavailable at
  construction OR fails on first real use (common on a bare Linux
  server with no D-Bus session), falls back to the encrypted-file store
  for the rest of the process's lifetime, logging the switch once.
  Never stores plaintext credentials in SQLite.

## 2. Dynamic Symbol Discovery & Watchlist (`app/watchlist/`, `app/data/nobitex/client.py`)

- `NobitexClient.fetch_all_market_symbols()` -- queries Nobitex for the
  full list of tradeable markets and classifies each as `RIAL` or
  `TETHER`. **Not verified against a live response** (no network access
  during development, same caveat as the candle/order-book endpoints in
  API.md) -- re-check field names before relying on it in production.
- `app/watchlist/logic.py` -- pure functions: symbol format validation,
  market-type inference, search/filter, sort/reorder. No I/O, fully
  unit-tested.
- `app/watchlist/service.py` -- `WatchlistService`, the thin async layer
  wrapping `Database`'s watchlist CRUD methods (`add`, `remove`,
  `set_enabled`, `list_all`, `list_enabled`).
- `app/database/models.py: WatchlistSymbolRecord` -- persisted watchlist
  entries (`symbol`, `market_type`, `enabled`, `display_order`,
  timestamps).
- **Scheduler integration**: `app/scheduler/scheduler.py`'s `scan_job`
  calls `_resolve_symbols()` every cycle, which reads the enabled
  watchlist fresh from the database (falling back to
  `settings.default_symbol` only when the watchlist is empty). Editing
  the watchlist from the web UI or Bale Control Center takes effect on
  the very next scan -- no restart needed.

## 3. Agent Health & Status (`app/monitoring/`)

- `health_service.py` -- `HealthService` (in-memory: last scan
  success/failure, error count) + `build_status_snapshot()` (pure
  function combining that in-memory state with live Nobitex/Bale/DB
  connectivity checks and today's DB-backed counters into an
  `AgentStatusSnapshot`).
- `status_formatter.py` -- pure Persian text formatting of a snapshot,
  shared by the Bale Control Center and the web Dashboard so the two
  surfaces render identical status text.
- `app/database/models.py: DailyCounterRecord` -- per-day counters
  (`analyses_run`, `alerts_sent`, `scan_errors`), incremented by
  `scan_job` and read by both status surfaces for "امروز" figures.
- **Degraded state**: a failed Nobitex/Bale/DB check is reflected in the
  snapshot (`degraded=True` with the specific service's `detail`) --
  the agent keeps running and keeps trying; one service failing never
  crashes the process (ADDITIONAL_MODULE_AGENT_DASHBOARD section
  "Degraded State").

## 4. Bale Agent Control Center (`app/reporting/bale_control.py`)

`BaleCommandRouter` -- given inbound text or `callback_data`, dispatches
to a handler (status, watchlist management, settings, monitoring
start/pause/resume) and returns `(text, keyboard)`. Reuses:
- `HealthService`/`status_formatter` for the status menu,
- `WatchlistService` for symbol management,
- `DatabaseRuntimeConfigAccessor` (`app/runtime/config_accessor.py`) for
  settings changes -- the SAME accessor the web UI uses, so a setting
  changed via Bale is immediately visible in the Dashboard and vice
  versa,
- `MonitoringController` for start/pause/resume.

**What's NOT built**: an actual inbound Bale webhook/long-polling
server. This is the same gap documented in `REPORTING.md` for the
Detailed Report button -- the routing/handler logic is complete and
tested with fakes, but nothing currently calls it from a real incoming
Bale update. Wiring a real transport is the natural next step.

## 5. First-Run Setup Wizard & Web UI (`app/web/`)

A local Flask app (Persian, `dir="rtl"`, no external JS framework or
CDN dependency) serving:

- `/setup/1` .. `/setup/5` -- the wizard: Nobitex connection (with a
  real "تست اتصال" that calls `NobitexClient.test_connection()`), Bale
  connection (test-sends a real message), trading configuration, symbol/
  watchlist selection (with live-if-possible symbol discovery), and
  monitoring configuration. Each step **persists immediately on
  submit** (not buffered in a session) -- closing the browser mid-wizard
  loses no progress; revisiting `/setup/N` shows already-saved values.
- `/dashboard` -- the health/status view + monitoring pause/resume
  buttons, sharing `AgentStatusSnapshot`/`status_formatter` with Bale.
- `/settings` -- reconfiguration entry points (credentials, trading
  config, watchlist, monitoring) plus a full "بازنشانی تنظیمات" reset.

### Nobitex authentication: a single token, not "API Key + Secret"

**Corrected after a real user hit this in production** (persistent
Nobitex connection failure, no symbols could load). `ADDITIONAL_MODULE_
FIRST_RUN_SETUP...md` lists both an API Key and an API Secret field,
which this build originally followed literally. Checking Nobitex's real
API docs (`apidocs.nobitex.ir`) and current third-party integration
guides confirmed: **Nobitex has no key+secret pair for its trading/data
API.** Authentication is a single token (`Authorization: Token <value>`,
generated from the account's "پروفایل و تنظیمات ← کلید API" panel page),
exactly matching what `NobitexClient` already implemented correctly.
The now-removed "API Secret" field corresponded to nothing real — it
was blocking users who correctly had only a token to enter, and likely
caused wrong values to end up in the wrong field. `setup_step1.html`
now collects a single "توکن API نوبیتکس" field with inline instructions
for where to find it in the Nobitex panel;
`CredentialManager.save_nobitex_credentials(token, "")` is called with
an empty second argument for backward compatibility with the storage
schema (no other code path ever read the second value — every caller
already did `api_key, _ = await credential_manager.get_nobitex_credentials()`).
The (unrelated) payment-gateway product Nobitex also offers does use a
key+secret pair, which is easy to conflate with the trading API but is
a separate product this agent doesn't use.

Connection-test failures (both Nobitex and Bale) now surface the real
exception detail (HTTP status + Nobitex's own response body) in the
Persian error message, instead of a single generic guess — this was the
other real gap the same incident exposed: there was no way to tell a
wrong-token failure from a permission-scope failure from a transient
network error without reading server logs.

### Threading & the async bridge (`app/web/async_bridge.py`)

Flask's dev server runs in its own OS thread; the scheduler and
`Database` live on the main thread's asyncio event loop. Rather than
running a second `Database`/engine on a second event loop, every Flask
route submits its async work to the ONE real loop via
`asyncio.run_coroutine_threadsafe` (`AsyncBridge.run(coro)`) and blocks
for the result. One `Database` instance, one source of truth, for the
whole process.

### Startup sequence (`main.py: run_forever`)

```
Load .env Settings
        v
Init Database
        v
Start web UI thread (always -- Setup/Settings must be reachable
        |             immediately, per FIRST-RUN_SETUP section 1)
        v
setup_completed?  --no--> print the local URL, wait (poll every 2s)
        |                  until the wizard finishes
       yes
        v
Resolve effective Nobitex/Bale credentials
   (.env overrides CredentialManager, for headless/Docker power users)
        v
Build NobitexClient / BaleClient
        v
Start the scheduler (dynamic watchlist, MonitoringController-gated)
```

Building the live clients only AFTER setup completes (rather than at
process start with possibly-empty credentials) means the very first run
never needs a restart to pick up what was just entered in the wizard.
**A LATER credential change via Settings, while the agent is already
running, does still require a restart to take effect** -- a documented,
intentionally accepted limitation (see DEPLOYMENT.md).

### Security note (no authentication)

**The web UI has no login/authentication in this build.** It's a
credential-configuration surface, so this matters: `WEB_UI_HOST`
defaults to `127.0.0.1` (loopback-only, unreachable from outside the
host) specifically so a careless deployment doesn't expose it. Docker
deployments that need the dashboard reachable from outside the
container must explicitly set `WEB_UI_HOST=0.0.0.0` (see
`docker-compose.yml`'s comment) and are responsible for putting a
firewall, VPN, or authenticating reverse proxy in front of the
published port. `main.py` logs a warning at startup if bound to a
non-loopback address. Adding real authentication (a login page, a
generated setup token, etc.) is a natural next step before any
public-facing deployment.

## 6. Web Dashboard extensions (`MODULE_7_WEB_DASHBOARD.md`)

`MODULE_7` asks for a FastAPI backend + React/TypeScript/Tailwind SPA
frontend. **This was deliberately not done.** By the time MODULE_7
arrived, section 5's Flask-based Setup Wizard/Dashboard/Settings already
existed, tested and working. Rebuilding it on FastAPI+React would mean
discarding that working code — directly against this project's standing
rule ("Do not rewrite existing working modules") and against MODULE_7's
own section 23 ("Do not rewrite the existing project from scratch...
reuse existing components"). Every acceptance criterion in MODULE_7's
section 24 is about *user-facing capability* ("opens in a browser",
"Persian and RTL", "can view both LONG and SHORT", "charts are
visible", etc.) — none of it requires a specific framework. So MODULE_7
was implemented as an extension of the existing Flask app instead,
reusing the same `AsyncBridge`, `WatchlistService`, `HealthService`, and
report generators as section 5.

### New pages

- **`/analysis`** (`app/web/analysis_routes.py`) — pick a watchlist
  symbol, "▶️ اجرای تحلیل فوری" runs `run_dual_analysis` (the identical
  function the scheduler calls) on demand, without touching
  `MonitoringController` — the automatic scanner keeps running
  independently (section 12). Renders the SAME `SummaryReportGenerator`/
  `DetailedReportGenerator` text already used for Bale — reusing rather
  than reimplementing the report content — inside a `white-space:
  pre-wrap` block, plus an embedded chart.
- **`/reports`** and **`/reports/<analysis_id>`**
  (`app/web/reports_routes.py`) — report history with symbol/decision
  filters, reading `AnalysisRecord` (every cycle) and, where a trade was
  taken, the linked `SignalRecord`'s outcome status (`TP1_HIT`,
  `SL_HIT`, etc.) for the "نتیجه" column. The detail page reconstructs
  and renders the exact stored `MarketAnalysisResult` — same mechanism
  the Bale "مشاهده تحلیل کامل" button already uses
  (`Database.get_stored_market_analysis_result`), zero recomputation.
- **Dashboard market-overview widget** — one line per enabled watchlist
  symbol showing its most recent final decision, added to the existing
  `/dashboard` page.
- **Bale test button in Settings** — `/settings/bale-test`, independent
  of the Setup Wizard's step-2 test (section 11).

### Chart visualization (section 7)

Reuses `app/charts/chart_generator.py:generate_signal_chart` (mplfinance
— already built for Bale's `sendPhoto`) exactly as section 7 explicitly
allows: *"If the existing project already generates mplfinance charts,
preserve that functionality and expose the generated charts in the
dashboard as an additional option."* The Live Analysis page fetches
fresh execution-timeframe candles and embeds the PNG as a base64 `data:`
URI — no new charting library, no TradingView Lightweight Charts
integration (that remains a real gap if an interactive, zoomable chart
is later required — the current chart is a static image per analysis run).

### JSON API (`app/web/api_routes.py`, section 18)

Flask, not FastAPI, but the same route shapes MODULE_7 lists:
`GET/POST /api/watchlist`, `PUT/DELETE /api/watchlist/<symbol>`,
`GET /api/analysis/<symbol>`, `POST /api/analysis/<symbol>/run`,
`GET /api/reports[/<id>]`, `GET/PUT /api/settings`,
`POST /api/bale/test`, `POST /api/scanner/start|stop|scan-now`, plus
`GET /api/status` and `GET /api/symbols`. Every handler is a thin
`jsonify(...)` wrapper around the identical service call the HTML route
uses — verified by `tests/unit/test_web_ui.py`'s `test_api_*` tests,
which hit the real Flask routes, not a mock.

### What's still a real gap

- **No React/TypeScript/Tailwind frontend** — the UI is server-rendered
  Jinja2 (Persian, RTL, responsive via CSS grid/media queries, but not a
  client-side SPA). If a richer, app-like experience is later required,
  the `/api/*` endpoints already exist to build one against.
- **No interactive/zoomable chart** (TradingView Lightweight Charts) —
  static PNG per analysis run, as noted above.
- **CSRF protection** (section 16) is not implemented — Flask's session
  cookie is used only for one-shot flash messages, and every mutating
  route lives behind the "no external auth" boundary already documented
  in section 5's security note; adding CSRF tokens is a reasonable
  follow-up before any multi-user or public-facing use.



- `test_credential_store.py`, `test_credential_manager.py` -- both
  storage backends and the fallback logic, using real `cryptography`
  (genuinely installed, not shimmed) against temp directories.
- `test_watchlist_logic.py` -- the pure search/filter/sort/validate
  functions.
- `test_monitoring_controller.py` -- thread-safety of pause/resume,
  verified by actually pausing from a second `threading.Thread`.
- `test_scheduler.py` -- dynamic watchlist resolution, the
  monitoring-paused skip path, and that a per-symbol analysis failure is
  caught, counted, and reflected via `HealthService.record_scan_failure`
  without crashing the job.
- `test_web_ui.py` -- the full Flask app via its real test client, with
  a real background event-loop thread (exactly the production
  threading model) and a duck-typed `FakeDatabase`: setup flow
  (redirects, form validation, credential persistence, watchlist add/
  remove, completion + monitoring auto-start), dashboard rendering,
  settings reset, the Live Analysis page (including the "no credentials
  configured" Persian error path), Report History (listing, symbol
  filtering, outcome labels, detail-page reconstruction), and every
  `/api/*` JSON endpoint. This suite caught a real bug during
  development — `WatchlistService.list_enabled()` returns plain symbol
  strings, not row objects, and two new routes had wrongly assumed
  otherwise; the tests failed immediately and pinpointed exactly where.

See TESTING.md for the complete file-by-file list.
