# ADDITIONAL MODULE: DYNAMIC NOBITEX SYMBOL & WATCHLIST MANAGER

Implement a dynamic symbol management system.

## 1. FETCH ALL SYMBOLS

Do not hard-code the list of available Nobitex symbols.

Fetch supported market symbols dynamically from Nobitex APIs where possible.

## 2. MARKET TYPES

Clearly distinguish:

- Rial markets
- Tether markets

Examples:

```text
BTC/IRT
BTC/USDT
ETH/IRT
ETH/USDT
```

## 3. USER WATCHLIST

The user can create a personal selected-symbol list.

Each symbol should have:

```python
symbol
market_type
enabled
display_order
created_at
updated_at
```

## 4. WATCHLIST OPERATIONS

Support:

- Add
- Remove
- Enable
- Disable
- Reorder
- Search
- Filter by market type
- Select all
- Deselect all

## 5. UI

Provide:

```text
⭐ نمادهای منتخب

🟢 BTC/USDT
🟢 BTC/IRT
🟢 ETH/USDT
⚪ ETH/IRT

[➕ افزودن]
[➖ حذف]
[✏️ ویرایش]
[🔄 بروزرسانی نمادها]
```

## 6. MONITORING INTEGRATION

The autonomous monitoring engine must scan only symbols that are:

```text
enabled = true
```

in the active watchlist.

## 7. PERSISTENCE

Persist the watchlist in the existing database.

Do not require source-code changes when the user changes symbols.

## ACCEPTANCE CRITERIA

- All available symbols can be discovered dynamically.
- Rial and Tether markets are supported.
- User can maintain a persistent watchlist.
- Watchlist controls monitoring.