# ADDITIONAL MODULE: PERSIAN RTL USER INTERFACE

Refactor the user-facing application interface to support Persian RTL properly.

This applies to the application interface itself, not only Bale reports.

## REQUIREMENTS

All user-facing UI must be:

- Persian
- RTL
- readable
- consistent
- technically professional

Internal code MUST remain English.

Do not rename Python classes, variables, database fields, APIs, or enums into Persian.

## UI LANGUAGE

Examples:

```text
داشبورد
تنظیمات
اتصال به نوبیتکس
اتصال به Bale
نمادهای منتخب
پایش بازار
گزارش‌ها
هشدارها
پروفایل ریسک
حالت معامله
وضعیت سیستم
```

## RTL MIXED CONTENT

Prices, symbols, percentages, technical indicators and English identifiers must remain visually readable.

Examples:

```text
نماد: BTC/USDT
قیمت: 102,450.00
امتیاز: 87 / 100
R:R: 1 : 3
```

Do not blindly reverse technical strings.

Use appropriate Unicode direction handling where necessary.

## IMPORTANT

Do not translate technical identifiers in source code.

Correct:

```python
MarketAnalysisResult
DirectionalAnalysis
ExecutionEligibility
```

Incorrect:

```python
نتیجه_تحلیل_بازار
تحلیل_جهت
```

## BALE

All user-facing Bale reports must also be Persian and RTL-friendly.

The existing Summary/Detailed reporting architecture must remain intact.

## ACCEPTANCE CRITERIA

- Application UI is Persian.
- Application UI is RTL.
- Bale reports are Persian.
- Technical values remain readable.
- Internal source code remains English.