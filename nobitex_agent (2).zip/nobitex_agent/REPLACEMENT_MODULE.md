# REPLACEMENT MODULE
# ADVANCED DETERMINISTIC CONFLUENCE, LIQUIDITY & EXECUTION ENGINE

Replace ALL previous versions of the Confluence Scoring, Hard Gate, Decision Engine, Premium/Discount, Order Book, Closed Candle, and Scoring Event logic with this module.

This module defines the complete deterministic decision architecture of the trading agent.

The system must NOT make trading decisions using subjective interpretation, arbitrary scoring, or dynamically invented point values.

Every decision must be reproducible from the same market data, configuration, and timestamp.

The engine must separate:

1. Market Context
2. Trade Location
3. Liquidity
4. Momentum
5. Multi-Timeframe Confirmation
6. Order Book Conditions
7. Execution Quality
8. Premium/Discount Location
9. Mandatory Validation Gates
10. Final Confluence Score
11. Execution Risk
12. Final BUY / SELL / WAIT Decision

---

# 1. CORE ARCHITECTURE

The decision pipeline must follow this exact order:

```text
Market Data
    ↓
Data Validation
    ↓
HTF Market Structure
    ↓
HTF POI Detection
    ↓
Premium / Discount Analysis
    ↓
Liquidity Analysis
    ↓
LTF Confirmation Engine
    ↓
Momentum Analysis
    ↓
Order Book Analysis
    ↓
Execution Analysis
    ↓
Hard-Gate Validation
    ↓
Deterministic 100-Point Scoring
    ↓
Execution Quality Assessment
    ↓
Market Risk Assessment
    ↓
Final Decision
    ↓
BUY / SELL / WAIT
```

The scoring engine must NEVER operate independently of the validation engine.

A high score cannot override a mandatory invalidation condition.

---

# 2. THREE DISTINCT OUTPUT DIMENSIONS

The agent must NOT reduce the entire market condition to a single number.

Every completed analysis must produce three independent outputs:

```text
A. CONFLUENCE SCORE
B. EXECUTION QUALITY
C. MARKET RISK
```

Example:

```text
Confluence Score:    91/100
Execution Quality:   8.7/10
Market Risk:         MEDIUM
```

These values must remain independent.

A high Confluence Score does NOT automatically mean BUY or SELL.

---

# 3. CONFLUENCE SCORE

The total Confluence Score is exactly:

```text
A. Market Structure                  20 points
B. POI Quality                       25 points
C. Liquidity & Price Action          15 points
D. Momentum                          10 points
E. Multi-Timeframe Alignment         10 points
F. Order Book & Market Depth         10 points
G. Execution Quality                  5 points
H. Premium/Discount Location          5 points
                                      ----
TOTAL                                100 points
```

The engine must enforce:

```python
assert 0 <= total_score <= 100
```

No category may exceed its defined maximum.

No hidden points may exist.

No AI-generated score modifications are permitted.

---

# 4. HARD GATES VS SCORING

The system must clearly separate:

## Hard Gates

Mandatory conditions that determine whether a setup is technically valid.

Hard Gates do NOT contribute points.

A failed Hard Gate invalidates the trade regardless of score.

## Scoring Factors

Factors that measure the quality of an otherwise technically valid setup.

Therefore:

```text
Valid Trade =
    All Mandatory Hard Gates Passed
    AND
    Confluence Score >= Risk Profile Threshold
    AND
    Execution Quality >= Minimum
    AND
    Market Risk != Critical
```

Otherwise:

```text
WAIT
```

---

# 5. HARD GATES

## GATE 1: DATA VALIDITY

Required:

```text
VALID
```

The following states are invalid:

```text
STALE
PARTIAL
INSUFFICIENT_DATA
API_ERROR
DATA_GAP
```

If data validity fails:

```text
WAIT
```

---

# 6. GATE 2: HTF STRUCTURE MUST BE CONFIRMED

The Higher Timeframe market context must be based only on confirmed closed candles.

The system must NEVER use a currently forming HTF candle to establish:

- BOS
- CHoCH
- Swing High
- Swing Low
- HTF trend
- HTF Order Block
- HTF FVG confirmation

If HTF structure is unclear:

```text
WAIT
```

However, the system may still use lower timeframes for early execution confirmation as described later.

---

# 7. GATE 3: VALID HTF POI

A valid higher-timeframe Point of Interest must exist.

Supported POIs:

```text
FVG
Order Block
Breaker Block
Mitigation Block
Liquidity Sweep
OTE
Volume Imbalance
Dynamic MA
```

The POI must be:

- technically valid
- active
- not fully invalidated
- structurally relevant

If no valid POI exists:

```text
WAIT
```

---

# 8. GATE 4: PREMIUM / DISCOUNT DIRECTION

The system must NOT use a rigid 50% boundary.

Instead, implement an Equilibrium Buffer.

Default:

```text
Equilibrium = 50%
Buffer = ±2%
```

Therefore:

```text
0% - 48%       = Discount
48% - 52%      = Equilibrium Buffer
52% - 100%     = Premium
```

For LONG:

```text
Discount          = Preferred
Equilibrium       = Allowed with penalty
Premium           = Invalid
```

For SHORT:

```text
Premium           = Preferred
Equilibrium       = Allowed with penalty
Discount          = Invalid
```

IMPORTANT:

The Equilibrium Buffer does NOT receive the same score as the preferred zone.

It is a permitted but lower-quality location.

---

# 9. PREMIUM / DISCOUNT SCORING

Maximum:

```text
5 points
```

## LONG

```text
Deep Discount / ideal location       = 5
Normal Discount                      = 5
Equilibrium Buffer                   = 2
Premium                              = 0 + HARD GATE FAIL
```

## SHORT

```text
Deep Premium / ideal location        = 5
Normal Premium                       = 5
Equilibrium Buffer                   = 2
Discount                             = 0 + HARD GATE FAIL
```

The exact Fibonacci equilibrium calculation must use the active structural range:

```text
HTF Swing High
HTF Swing Low
```

The system must document which swing pair was used.

---

# 10. EARLY LTF ENTRY CONFIRMATION

The system must NOT require every timeframe candle to close before an entry can be considered.

Instead, distinguish between:

## HTF CONTEXT

Must use closed candles.

Examples:

```text
4H
1H
```

## LTF EXECUTION

May use the most recently closed LTF candle to trigger an early entry.

Examples:

```text
15M
5M
```

Architecture:

```text
4H / 1H
Confirmed HTF Context
        ↓
HTF POI
        ↓
Price enters HTF POI
        ↓
15M / 5M Confirmation
        ↓
Entry
```

---

# 11. LTF CONFIRMATION RULES

An LTF confirmation may consist of:

```text
Liquidity Sweep
+
BOS / CHoCH
+
FVG creation
+
Order Block reaction
+
Momentum confirmation
```

Example LONG:

```text
HTF Bullish OB
+
Price enters Discount
+
SSL Sweep on 15M
+
Bullish CHoCH
+
15M Bullish FVG
```

This may trigger an early LONG entry without waiting for the next 1H candle to close.

IMPORTANT:

A forming candle may NEVER be used to confirm an HTF structural event.

The LTF engine may only use:

- fully closed LTF candles
- or explicitly configured real-time execution signals

Real-time signals must be clearly marked as:

```text
EARLY_EXECUTION
```

---

# 12. EARLY ENTRY RISK

Early LTF execution carries additional risk.

Therefore, if an entry is triggered before confirmation from the next HTF candle:

```text
Execution Risk = elevated
```

The system must explicitly display:

```text
⚠️ EARLY LTF ENTRY
```

and apply a configurable execution-quality penalty.

Default penalty:

```text
-1 execution-quality point
```

This penalty affects Execution Quality, not the underlying structural score.

---

# 13. CATEGORY A
# MARKET STRUCTURE
# MAXIMUM = 20 POINTS

## A1. HTF Structural Direction = 10 Points

LONG:

```text
Strong bullish structure = 10
Moderate bullish structure = 7
Weak bullish structure = 4
Neutral = 0
Bearish = 0
```

SHORT:

```text
Strong bearish structure = 10
Moderate bearish structure = 7
Weak bearish structure = 4
Neutral = 0
Bullish = 0
```

Structure is based on:

- Swing Highs
- Swing Lows
- BOS
- CHoCH

---

## A2. MA200 Macro Bias = 5 Points

LONG:

```text
Price > MA200 = 5
Price <= MA200 = 0
```

SHORT:

```text
Price < MA200 = 5
Price >= MA200 = 0
```

---

## A3. MA20 Direction = 3 Points

LONG:

```text
Bullish slope = 3
Neutral slope = 1
Bearish slope = 0
```

SHORT:

```text
Bearish slope = 3
Neutral slope = 1
Bullish slope = 0
```

Slope must be calculated mathematically.

Default:

```python
slope =
    (MA20[current] - MA20[N]) / MA20[N]
```

Default:

```text
N = 3 closed candles
```

---

## A4. MA20 / MA200 Relationship = 2 Points

LONG:

```text
MA20 > MA200 = 2
MA20 crossing above MA200 = 1
MA20 < MA200 = 0
```

SHORT:

```text
MA20 < MA200 = 2
MA20 crossing below MA200 = 1
MA20 > MA200 = 0
```

---

# 14. CATEGORY B
# POI QUALITY
# MAXIMUM = 25 POINTS

The engine must identify all valid POIs but select ONE as the Primary POI.

POIs must NOT stack without restriction.

Priority hierarchy:

```text
1. Liquidity Sweep + Structural Shift
2. Order Block / Breaker Block
3. FVG
4. OTE
5. Mitigation Block
6. Volume Imbalance
7. Dynamic MA
```

---

## B1. Primary POI Strength = 12 Points

```text
Liquidity Sweep + Structural Shift = 12
Order Block / Breaker Block        = 10
FVG                                = 8
OTE                                = 7
Mitigation Block                   = 6
Volume Imbalance                   = 5
Dynamic MA                         = 4
```

Only the strongest Primary POI receives this score.

---

## B2. POI Freshness = 5 Points

```text
Untouched                         = 5
Lightly mitigated                 = 3
Heavily mitigated but valid       = 1
Invalidated                       = 0
```

---

## B3. Structural Association = 5 Points

```text
POI directly associated with BOS/CHoCH = 5
POI near confirmed structure           = 3
Weak association                       = 1
No association                         = 0
```

---

## B4. POI Reaction Quality = 3 Points

```text
Strong rejection / displacement = 3
Moderate reaction               = 2
Weak reaction                   = 1
No reaction                     = 0
```

---

# 15. CATEGORY C
# LIQUIDITY & PRICE ACTION
# MAXIMUM = 15 POINTS

## C1. Liquidity Sweep = 7 Points

LONG:

```text
Confirmed SSL Sweep + bullish rejection = 7
Weak SSL Sweep                          = 4
No valid sweep                          = 0
```

SHORT:

```text
Confirmed BSL Sweep + bearish rejection = 7
Weak BSL Sweep                          = 4
No valid sweep                          = 0
```

A sweep requires:

- previously identifiable liquidity
- wick penetration
- body close back inside prior range

A normal breakout must NOT be classified as a sweep.

---

## C2. Structural Reaction = 4 Points

```text
Confirmed directional BOS/CHoCH = 4
Early/weak shift                = 2
No confirmation                 = 0
```

Do not double-count the exact same event used to classify the Primary POI.

---

## C3. Liquidity Target Quality = 4 Points

```text
Clear external liquidity target = 4
Clear internal liquidity target = 3
Weak target                     = 1
No meaningful target             = 0
```

TP targets must be structurally derived.

---

# 16. CATEGORY D
# MOMENTUM
# MAXIMUM = 10 POINTS

## D1. MFI10 = 5 Points

LONG:

```text
Bullish divergence + confirmation = 5
Bullish divergence                = 4
Oversold + bullish reaction       = 3
Supportive momentum               = 2
Neutral                           = 1
Bearish                           = 0
```

SHORT:

```text
Bearish divergence + confirmation = 5
Bearish divergence                = 4
Overbought + bearish reaction     = 3
Supportive momentum               = 2
Neutral                           = 1
Bullish                           = 0
```

---

## D2. RSI14 = 5 Points

LONG:

```text
Bullish divergence + confirmation = 5
Bullish divergence                = 4
Oversold + bullish reaction       = 3
Supportive momentum               = 2
Neutral                           = 1
Bearish                           = 0
```

SHORT:

```text
Bearish divergence + confirmation = 5
Bearish divergence                = 4
Overbought + bearish reaction     = 3
Supportive momentum               = 2
Neutral                           = 1
Bullish                           = 0
```

---

# 17. CATEGORY E
# MULTI-TIMEFRAME ALIGNMENT
# MAXIMUM = 10 POINTS

The system must support configurable timeframes.

Default:

```text
HTF = 4H
MTF = 1H
LTF = 15M
Execution = 5M
```

The exact timeframe hierarchy must be configurable by the user.

---

## E1. HTF + MTF Alignment = 6 Points

LONG:

```text
HTF bullish + MTF bullish = 6
HTF bullish + MTF neutral = 4
HTF bullish + MTF bearish = 1
HTF bearish = 0
```

SHORT is the exact inverse.

---

## E2. LTF Confirmation = 4 Points

LONG:

```text
Strong bullish LTF confirmation = 4
Moderate confirmation           = 3
Weak confirmation               = 1
No confirmation                 = 0
```

SHORT uses the bearish equivalent.

This allows an HTF setup to be entered using LTF confirmation without waiting for the next HTF candle.

---

# 18. CATEGORY F
# NOBITEX ORDER BOOK & MARKET DEPTH
# MAXIMUM = 10 POINTS

Order Book analysis must be a first-class scoring component.

The engine must fetch:

```text
/v2/orderbook/{symbol}
```

and analyze:

- bid volume
- ask volume
- bid/ask imbalance
- liquidity walls
- wall distance from Entry
- wall distance from SL
- wall distance from TP
- potential absorption
- potential execution obstruction

---

## F1. Directional Liquidity Support = 5 Points

LONG:

```text
Strong supportive bid liquidity = 5
Moderate supportive liquidity    = 4
Neutral                          = 2
Weak support                     = 1
Adverse                          = 0
```

SHORT:

```text
Strong supportive ask liquidity = 5
Moderate supportive liquidity   = 4
Neutral                         = 2
Weak support                    = 1
Adverse                         = 0
```

---

## F2. Liquidity Path Quality = 5 Points

Evaluate the path:

```text
Entry → SL
Entry → TP1
Entry → TP2
```

Scoring:

```text
Very clean liquidity path = 5
Good                     = 4
Acceptable               = 3
Obstructed               = 1
Severely obstructed      = 0
```

A large liquidity wall directly before TP may reduce this score.

A large adverse wall close to Entry may also reduce this score.

---

# 19. ORDER BOOK RISK FILTER

Order Book must also generate a separate risk classification.

Possible values:

```text
LOW
MEDIUM
HIGH
CRITICAL
```

Examples of CRITICAL conditions:

- extreme opposing liquidity wall immediately near Entry
- severe liquidity imbalance against the trade
- insufficient liquidity for expected execution size
- abnormal spread
- major obstruction immediately before TP1
- severe order-book instability

If:

```text
Market Risk = CRITICAL
```

the final decision must be:

```text
WAIT
```

regardless of Confluence Score.

---

# 20. CATEGORY G
# EXECUTION QUALITY
# MAXIMUM = 5 POINTS

Evaluate:

- distance from Primary POI
- Entry precision
- SL placement
- expected slippage
- R:R
- spread
- order book conditions
- early-entry status

Scoring:

```text
Excellent = 5
Very Good = 4
Good = 3
Acceptable = 2
Poor = 1
Invalid = 0
```

Minimum default Execution Quality:

```text
3/5
```

If:

```text
Execution Quality < 3
```

then:

```text
WAIT
```

---

# 21. EARLY ENTRY PENALTY

If the setup uses LTF confirmation before the next HTF candle closes:

```text
Execution Quality penalty = -1
```

Minimum cannot fall below zero.

This penalty must be visible in the report:

```text
⚠️ Early LTF Execution: -1
```

The structural confluence score must NOT be artificially reduced because of this penalty.

---

# 22. CATEGORY H
# PREMIUM / DISCOUNT LOCATION
# MAXIMUM = 5 POINTS

This category uses the Equilibrium Buffer defined earlier.

LONG:

```text
Discount          = 5
Equilibrium       = 2
Premium           = 0 + Gate Failure
```

SHORT:

```text
Premium           = 5
Equilibrium       = 2
Discount           = 0 + Gate Failure
```

---

# 23. ANTI-DOUBLE-COUNTING ARCHITECTURE

The system must prevent the same underlying event from receiving points multiple times.

Examples:

```text
SSL Sweep
↓
CHoCH
↓
FVG
```

The engine must distinguish these as separate technical events only if they provide genuinely independent information.

The same candle/event must not automatically generate points under every category.

---

# 24. PYDANTIC EVENT MODELS

Use Pydantic models for structured events.

Minimum models:

```python
class MarketEvent(BaseModel):
    event_id: str
    event_type: str
    symbol: str
    timeframe: str
    timestamp: datetime
    direction: Optional[str]
    candle_indices: list[int]
    evidence: dict


class POIEvent(BaseModel):
    event_id: str
    poi_type: str
    symbol: str
    timeframe: str
    direction: str
    zone_high: float
    zone_low: float
    created_at: datetime
    mitigation_status: str
    structural_event_id: Optional[str]


class ScoreFactor(BaseModel):
    factor_id: str
    category: str
    name: str
    awarded_points: float
    maximum_points: float
    evidence: str
    event_ids: list[str]


class ScoreBreakdown(BaseModel):
    structure: float
    poi: float
    liquidity: float
    momentum: float
    mtf: float
    orderbook: float
    execution: float
    premium_discount: float
    total: float
    factors: list[ScoreFactor]
```

---

# 25. EVENT REGISTRY

Create a centralized Event Registry.

The registry must track:

```text
event_id
event_type
symbol
timeframe
timestamp
source candles
related POI
related score factors
```

Before a factor is awarded:

```text
Check whether the underlying event has already been counted.
```

If yes:

```text
Do not count it again.
```

The Event Registry must be deterministic.

---

# 26. OPTIONAL DECORATOR SYSTEM

Decorators may be used to simplify registration of scoring events.

Example concept:

```python
@register_scoring_event(
    factor_id="C1",
    maximum_points=7
)
def evaluate_liquidity_sweep(...):
    ...
```

However, decorators must NOT hide decision logic.

All scoring rules must remain discoverable and testable.

The core engine must remain understandable without reading decorator internals.

---

# 27. FINAL SCORE FORMULA

The exact formula is:

```text
Score =
    Structure
    + POI
    + Liquidity
    + Momentum
    + MTF
    + OrderBook
    + Execution
    + PremiumDiscount
```

Maximum:

```text
20 + 25 + 15 + 10 + 10 + 10 + 5 + 5 = 100
```

The system must verify:

```python
assert structure <= 20
assert poi <= 25
assert liquidity <= 15
assert momentum <= 10
assert mtf <= 10
assert orderbook <= 10
assert execution <= 5
assert premium_discount <= 5
assert 0 <= total_score <= 100
```

---

# 28. SIGNAL STRENGTH

Use:

```text
0-39     VERY WEAK
40-59    WEAK
60-69    MODERATE
70-79    GOOD
80-89    STRONG
90-100   EXCEPTIONAL
```

This classification is informational only.

---

# 29. RISK PROFILES

Default thresholds:

## CONSERVATIVE

```text
Score >= 85
Execution Quality >= 4/5
Market Risk must be LOW or MEDIUM
```

## MODERATE

```text
Score >= 75
Execution Quality >= 3/5
Market Risk must not be CRITICAL
```

## AGGRESSIVE

```text
Score >= 60
Execution Quality >= 3/5
Market Risk must not be CRITICAL
```

All thresholds must be configurable.

---

# 30. FINAL DECISION ENGINE

Use this deterministic decision tree:

```text
1. Validate data
        ↓
2. Validate HTF closed structure
        ↓
3. Identify HTF POI
        ↓
4. Calculate Premium/Discount
        ↓
5. Check directional Gate
        ↓
6. Wait for or detect LTF confirmation
        ↓
7. Analyze liquidity
        ↓
8. Analyze momentum
        ↓
9. Analyze Order Book
        ↓
10. Calculate Execution Quality
        ↓
11. Run Hard Gates
        ↓
12. Calculate Confluence Score
        ↓
13. Compare Risk Profile Threshold
        ↓
14. Evaluate Market Risk
        ↓
15. BUY / SELL / WAIT
```

---

# 31. FINAL BUY CONDITIONS

A LONG signal requires:

```text
HTF bullish structure
+
Valid bullish HTF POI
+
Price in Discount
OR valid Equilibrium Buffer with reduced score
+
Bullish LTF confirmation
+
Valid SL
+
Valid TP
+
Minimum R:R
+
Hard Gates passed
+
Score >= Risk Threshold
+
Execution Quality >= minimum
+
Market Risk != CRITICAL
```

---

# 32. FINAL SELL CONDITIONS

A SHORT signal requires:

```text
HTF bearish structure
+
Valid bearish HTF POI
+
Price in Premium
OR valid Equilibrium Buffer with reduced score
+
Bearish LTF confirmation
+
Valid SL
+
Valid TP
+
Minimum R:R
+
Hard Gates passed
+
Score >= Risk Threshold
+
Execution Quality >= minimum
+
Market Risk != CRITICAL
```

---

# 33. WAIT CONDITIONS

The system must return WAIT when:

```text
No valid POI
OR
HTF structure unclear
OR
Wrong Premium/Discount zone
OR
Invalid SL
OR
Invalid TP
OR
Insufficient R:R
OR
Score below threshold
OR
Execution Quality below minimum
OR
Critical Order Book Risk
OR
Invalid data
```

The report must identify the exact reason.

---

# 34. SCORE EXPLANATION

Every signal must expose the full scoring breakdown.

Example:

```text
📊 CONFLUENCE SCORE

Market Structure
  HTF Structure             10/10
  MA200                      5/5
  MA20 Direction             3/3
  MA20/MA200                 2/2
  Subtotal                  20/20

POI Quality
  Primary POI               10/12
  Freshness                  5/5
  Structure Association      5/5
  Reaction Quality            2/3
  Subtotal                  22/25

Liquidity
  SSL Sweep                  7/7
  Structural Reaction        4/4
  Liquidity Target           4/4
  Subtotal                  15/15

Momentum
  MFI                         5/5
  RSI                         4/5
  Subtotal                   9/10

MTF
  HTF + MTF                   6/6
  LTF Confirmation            4/4
  Subtotal                  10/10

Order Book
  Directional Liquidity       4/5
  Liquidity Path              4/5
  Subtotal                   8/10

Execution
  Entry Quality               4/5

Premium / Discount
  Discount                    5/5

────────────────────────────
TOTAL                        93/100
────────────────────────────
```

The numbers above are illustrative only.

The actual values must come from the engine.

---

# 35. MARKET RISK REPORT

Every analysis must also report:

```text
Market Risk:
LOW
MEDIUM
HIGH
CRITICAL
```

Factors:

```text
Order Book instability
Liquidity obstruction
Spread
Expected slippage
Distance to SL
Distance to TP
Volatility
Early LTF execution
HTF/LTF conflict
```

Example:

```text
⚠️ MARKET RISK: MEDIUM

Reasons:
- Large opposing ask wall near TP1
- Early 5M confirmation
- Moderate spread
```

---

# 36. EXECUTION QUALITY REPORT

Example:

```text
🎯 EXECUTION QUALITY

Entry Quality:       4/5
SL Quality:          5/5
Liquidity Path:      4/5
Expected Slippage:   Good
Early Entry:         YES
Penalty:             -1

Final Execution:     4/5
```

The exact calculation must be deterministic.

---

# 37. TRANSPARENT REJECTION REPORT

When the system returns WAIT, it must NOT simply say:

```text
WAIT
```

It must explain:

```text
⏸ وضعیت: WAIT

Score: 78/100
Required: 85

Reason:
Score below Conservative threshold.

Additional factors:
- Order Book Risk: HIGH
- LTF confirmation incomplete
- Entry quality: 2/5

Failed Conditions:
❌ Risk threshold
❌ Minimum execution quality
```

---

# 38. SCORE TRACEABILITY

Store all scoring information in SQLite.

Required fields:

```text
signal_id
symbol
direction
timestamp

total_score

structure_score
poi_score
liquidity_score
momentum_score
mtf_score
orderbook_score
execution_score
premium_discount_score

execution_quality
market_risk

risk_profile
decision

primary_poi
poi_event_id

hard_gate_results

score_factors
```

Store score factors as structured JSON where appropriate.

---

# 39. REPRODUCIBILITY

Given:

```text
same symbol
same historical data
same timestamp
same configuration
same risk profile
```

the system MUST produce:

```text
same score
same decision
same POI
same risk classification
```

No randomness.

No LLM-generated numerical adjustments.

No subjective score modifications.

---

# 40. AUDITABILITY

The system must answer all of the following:

```text
Why did this setup receive 83?

Why did it lose 7 points?

Which POI generated the score?

Which liquidity event was detected?

Which candles produced the event?

Why was the trade allowed inside the Equilibrium Buffer?

Why was the Order Book considered supportive?

Why was Market Risk classified as HIGH?

Why was the final decision WAIT despite a score of 88?
```

Every answer must be traceable to structured engine data.

---

# 41. TESTING REQUIREMENTS

Create automated unit and integration tests for:

1. Bullish HTF structure.
2. Bearish HTF structure.
3. MA200 bullish bias.
4. MA200 bearish bias.
5. MA20 slope.
6. Golden Cross.
7. Death Cross.
8. FVG detection.
9. Order Block detection.
10. Breaker Block detection.
11. Mitigation Block detection.
12. SSL Sweep.
13. BSL Sweep.
14. BOS.
15. CHoCH.
16. OTE.
17. MFI divergence.
18. RSI divergence.
19. Discount.
20. Premium.
21. Equilibrium Buffer.
22. Invalid directional zone.
23. HTF closed candle.
24. LTF early confirmation.
25. Order Book imbalance.
26. Liquidity wall detection.
27. Liquidity obstruction near TP.
28. Spread risk.
29. Execution quality.
30. Critical Market Risk.
31. Anti-double-counting.
32. Score exactly 60.
33. Score exactly 75.
34. Score exactly 85.
35. Score 100.
36. Score below threshold.
37. Invalid SL.
38. Invalid TP.
39. Invalid R:R.
40. Insufficient data.

---

# 42. CONFIGURATION

All numerical values must be centralized.

Example:

```yaml
scoring:

  categories:
    structure: 20
    poi: 25
    liquidity: 15
    momentum: 10
    mtf: 10
    orderbook: 10
    execution: 5
    premium_discount: 5

  premium_discount:
    equilibrium: 0.50
    buffer: 0.02

  execution:
    minimum_score: 3
    early_ltf_penalty: 1

  risk_profiles:

    conservative:
      threshold: 85
      minimum_execution: 4
      maximum_market_risk: MEDIUM

    moderate:
      threshold: 75
      minimum_execution: 3
      maximum_market_risk: HIGH

    aggressive:
      threshold: 60
      minimum_execution: 3
      maximum_market_risk: HIGH
```

Do not scatter numerical constants across Python files.

---

# 43. IMPORTANT DESIGN PRINCIPLE

The agent must NOT behave like:

```text
"Score > 80 = BUY"
```

Instead:

```text
Context
+
Location
+
Liquidity
+
Confirmation
+
Order Book
+
Execution
+
Risk
=
Decision
```

The Confluence Score measures the quality of the setup.

The Hard Gates determine technical validity.

Execution Quality determines whether the entry is practical.

Market Risk determines whether current market conditions make execution dangerous.

Only when all required conditions are satisfied may the agent generate:

```text
BUY
```

or

```text
SELL
```

Otherwise:

```text
WAIT
```

---

# 44. FINAL MANDATORY REQUIREMENT

The implementation must completely replace the previous simplistic scoring system:

```text
Trend = 25
POI = 35
MFI = 20
RSI = 20
```

That model must NOT remain active anywhere in the codebase.

The new architecture must be implemented as a single centralized deterministic Decision Engine.

Every point must have:

1. A defined factor.
2. A maximum value.
3. A deterministic calculation.
4. Structured evidence.
5. Associated event IDs.
6. A reproducible result.

The engine must never invent a score.

The engine must never override a failed mandatory gate simply because the total score is high.

The engine must always explain both:

```text
WHY THIS TRADE WAS ACCEPTED
```

and:

```text
WHY THIS TRADE WAS REJECTED
```

The resulting system must be deterministic, modular, testable, auditable, configurable, and suitable for production deployment.