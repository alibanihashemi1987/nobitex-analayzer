from __future__ import annotations

import asyncio
import threading

from app.runtime.monitoring_controller import MonitoringController


def test_starts_active_by_default():
    controller = MonitoringController()
    assert controller.is_active() is True


def test_pause_deactivates():
    controller = MonitoringController()
    asyncio.run(controller.pause())
    assert controller.is_active() is False


def test_resume_reactivates():
    controller = MonitoringController(initially_active=False)
    assert controller.is_active() is False
    asyncio.run(controller.resume())
    assert controller.is_active() is True


def test_visible_across_threads():
    """The whole point of this object: a pause requested from one thread
    (simulating the Flask UI thread) must be visible to code polling from
    another thread (simulating the asyncio scheduler thread)."""
    controller = MonitoringController(initially_active=True)

    def pause_from_other_thread():
        asyncio.run(controller.pause())

    t = threading.Thread(target=pause_from_other_thread)
    t.start()
    t.join()

    assert controller.is_active() is False
