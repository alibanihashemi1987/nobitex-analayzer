from __future__ import annotations

import asyncio
import stat
import tempfile
from pathlib import Path

from app.security.credential_store import EncryptedFileCredentialStore


def test_save_and_get_round_trip():
    with tempfile.TemporaryDirectory() as tmp:
        store = EncryptedFileCredentialStore(tmp)
        asyncio.run(store.save("nobitex_api_key", "secret-value-123"))
        result = asyncio.run(store.get("nobitex_api_key"))
        assert result == "secret-value-123"


def test_get_missing_key_returns_none():
    with tempfile.TemporaryDirectory() as tmp:
        store = EncryptedFileCredentialStore(tmp)
        assert asyncio.run(store.get("nonexistent")) is None


def test_delete_removes_key():
    with tempfile.TemporaryDirectory() as tmp:
        store = EncryptedFileCredentialStore(tmp)
        asyncio.run(store.save("bale_token", "abc"))
        asyncio.run(store.delete("bale_token"))
        assert asyncio.run(store.get("bale_token")) is None


def test_delete_nonexistent_key_does_not_raise():
    with tempfile.TemporaryDirectory() as tmp:
        store = EncryptedFileCredentialStore(tmp)
        asyncio.run(store.delete("never-existed"))  # must not raise


def test_multiple_keys_coexist():
    with tempfile.TemporaryDirectory() as tmp:
        store = EncryptedFileCredentialStore(tmp)
        asyncio.run(store.save("key_a", "value_a"))
        asyncio.run(store.save("key_b", "value_b"))
        assert asyncio.run(store.get("key_a")) == "value_a"
        assert asyncio.run(store.get("key_b")) == "value_b"


def test_data_file_is_not_plaintext():
    with tempfile.TemporaryDirectory() as tmp:
        store = EncryptedFileCredentialStore(tmp)
        asyncio.run(store.save("nobitex_api_secret", "super-secret-plaintext-marker"))
        raw_bytes = (Path(tmp) / "credentials.enc").read_bytes()
        assert b"super-secret-plaintext-marker" not in raw_bytes


def test_key_file_has_restrictive_permissions_on_posix():
    with tempfile.TemporaryDirectory() as tmp:
        EncryptedFileCredentialStore(tmp)
        key_path = Path(tmp) / "credentials.key"
        mode = key_path.stat().st_mode
        # Owner read/write only -- no group/other permission bits set.
        assert not (mode & stat.S_IRGRP)
        assert not (mode & stat.S_IROTH)
        assert not (mode & stat.S_IWGRP)
        assert not (mode & stat.S_IWOTH)


def test_persists_across_store_instances_with_same_dir():
    with tempfile.TemporaryDirectory() as tmp:
        store1 = EncryptedFileCredentialStore(tmp)
        asyncio.run(store1.save("persisted_key", "persisted_value"))

        store2 = EncryptedFileCredentialStore(tmp)  # reload key from disk
        assert asyncio.run(store2.get("persisted_key")) == "persisted_value"


def test_update_overwrites_existing_value():
    with tempfile.TemporaryDirectory() as tmp:
        store = EncryptedFileCredentialStore(tmp)
        asyncio.run(store.save("k", "first"))
        asyncio.run(store.save("k", "second"))
        assert asyncio.run(store.get("k")) == "second"
