from __future__ import annotations

from dataclasses import replace
from datetime import UTC, datetime

from app.config.scoring_config import get_scoring_config
from app.domain.context import build_market_context
from app.domain.enums import ExecutionMode, FinalDecision
from app.reporting.report_localization import ANALYSIS_NOT_FOUND_MESSAGE
from app.services.analysis_service import _build_market_overview
from app.strategy.directional.evaluate_long import evaluate_long
from app.strategy.directional.evaluate_short import evaluate_short
from app.strategy.directional.resolver import resolve_final_decision
from tests.fixtures.sample_candles import uptrend_candles


def _real_result(execution_mode=ExecutionMode.COMMITMENT):
    cfg = get_scoring_config()
    candles = uptrend_candles(n=250)
    ctx = build_market_context(
        symbol="BTCIRT", timestamp=datetime.now(UTC),
        candles_by_role={"HTF": candles, "MTF": candles, "LTF": candles, "EXECUTION": candles},
        role_to_timeframe={"HTF": "4H", "MTF": "1H", "LTF": "15M", "EXECUTION": "5M"},
        divergence_min_swing_distance=cfg.divergence.min_swing_distance,
        divergence_min_price_separation_pct=cfg.divergence.min_price_separation_pct,
        ma20_slope_lookback=cfg.ma20_slope_lookback,
        ob_atr_multiplier=cfg.order_block.strong_move_atr_multiplier,
        ob_atr_period=cfg.order_block.atr_period,
        fvg_invalidation_pct=cfg.fvg.invalidation_pct,
        premium_discount_equilibrium_buffer=cfg.premium_discount.buffer,
        orderbook_raw={"bids": [["99", "5"], ["98", "3"]], "asks": [["101", "4"], ["102", "2"]]},
        entry_hint=candles[-1].close,
    )
    long_r = evaluate_long(ctx, cfg, "moderate")
    short_r = evaluate_short(ctx, cfg, "moderate")
    result = resolve_final_decision(long_r, short_r, execution_mode, cfg.decision, "BTCIRT", datetime.now(UTC))
    return replace(result, market_overview=_build_market_overview(ctx))


class FakeDatabase:
    """Duck-typed stand-in for app.database.db.Database — no real DB, no
    sqlalchemy — just records what was saved and answers lookups from an
    in-memory dict, so signal_service's orchestration logic can be
    exercised without a real database or async engine."""

    def __init__(self):
        self.saved_analyses: list = []
        self.saved_signals: list = []
        self._by_id: dict = {}

    async def save_analysis_result(self, result, risk_profile, linked_signal_id=None):
        self.saved_analyses.append((result, risk_profile, linked_signal_id))
        self._by_id[result.analysis_id] = result
        return result.analysis_id

    async def save_signal(self, signal):
        self.saved_signals.append(signal)
        return "fake-signal-id"

    async def get_stored_market_analysis_result(self, analysis_id):
        return self._by_id.get(analysis_id)


class FakeBale:
    def __init__(self):
        self.sent_messages: list = []
        self.sent_photos: list = []

    async def send_message(self, text, parse_mode="Markdown", reply_markup=None):
        self.sent_messages.append((text, reply_markup))

    async def send_photo(self, photo_bytes, caption="", reply_markup=None):
        self.sent_photos.append((caption, reply_markup))


async def _run(coro):
    return await coro


def test_send_summary_report_always_sends_regardless_of_decision():
    import asyncio
    from app.services.signal_service import send_summary_report

    result = _real_result()  # WAIT in this synthetic scenario
    assert result.final_decision == FinalDecision.WAIT

    db, bale = FakeDatabase(), FakeBale()
    asyncio.run(send_summary_report(result, db, bale, "moderate"))

    assert len(db.saved_analyses) == 1
    assert len(bale.sent_messages) == 1
    text, keyboard = bale.sent_messages[0]
    assert "\u062e\u0631\u06cc\u062f" in text  # Persian BUY-side label present
    assert keyboard is not None
    assert keyboard["inline_keyboard"][0][0]["callback_data"] == f"detailed_analysis:{result.analysis_id}"


def test_process_and_alert_does_not_message_bale_on_wait():
    import asyncio
    from app.services.signal_service import process_and_alert

    result = _real_result()
    assert result.final_decision == FinalDecision.WAIT

    db, bale = FakeDatabase(), FakeBale()
    asyncio.run(process_and_alert(result, db, bale, cooldown_seconds=0, timeframe="5M"))

    # AnalysisRecord is always persisted...
    assert len(db.saved_analyses) == 1
    # ...but no Bale message for WAIT (auto-alerts are BUY/SELL only to avoid spam).
    assert len(bale.sent_messages) == 0
    assert len(bale.sent_photos) == 0


def test_handle_detailed_report_request_returns_report_for_known_id():
    import asyncio
    from app.services.signal_service import handle_detailed_report_request, send_summary_report

    result = _real_result()
    db, bale = FakeDatabase(), FakeBale()
    asyncio.run(send_summary_report(result, db, bale, "moderate"))

    report = asyncio.run(handle_detailed_report_request(result.analysis_id, db, bale, "moderate"))
    assert result.analysis_id in report
    assert report != ANALYSIS_NOT_FOUND_MESSAGE
    # A second Bale message (the detailed report) was sent, in addition
    # to the original summary.
    assert len(bale.sent_messages) == 2


def test_handle_detailed_report_request_returns_not_found_for_unknown_id():
    import asyncio
    from app.services.signal_service import handle_detailed_report_request

    db, bale = FakeDatabase(), FakeBale()
    report = asyncio.run(handle_detailed_report_request("nonexistent-id", db, bale, "moderate"))
    assert report == ANALYSIS_NOT_FOUND_MESSAGE
    assert bale.sent_messages[-1][0] == ANALYSIS_NOT_FOUND_MESSAGE
