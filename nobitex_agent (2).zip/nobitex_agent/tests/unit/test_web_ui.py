from __future__ import annotations

import asyncio
import tempfile
import threading

from app.monitoring.health_service import HealthService
from app.runtime.monitoring_controller import MonitoringController
from app.security.credential_manager import CredentialManager
from app.web.app_factory import create_app
from app.web.async_bridge import AsyncBridge


class _FakeWatchlistRow:
    def __init__(self, symbol, market_type, enabled=True, display_order=0):
        self.symbol = symbol
        self.market_type = market_type
        self.enabled = enabled
        self.display_order = display_order


class _FakeRuntimeConfig:
    def __init__(self):
        self.setup_completed = False
        self.execution_mode = "SPOT"
        self.risk_profile = "moderate"
        self.scan_interval_seconds = 300
        self.enabled_timeframes = ["4H", "1H", "15M", "5M"]
        self.auto_monitoring_enabled = True
        self.scheduled_reports_enabled = False
        self.event_alerts_enabled = True
        self.alert_cooldown_seconds = 1800
        self.candle_close_reports_enabled = False


class _FakeCounter:
    def __init__(self):
        self.alerts_sent = 0
        self.analyses_run = 0
        self.scan_errors = 0


class _FakeAnalysisRecord:
    def __init__(self, id, symbol, timestamp, final_decision="WAIT", long_score=50.0,
                 short_score=40.0, linked_signal_id=None, risk_profile="moderate"):
        self.id = id
        self.symbol = symbol
        self.timestamp = timestamp
        self.execution_mode = "SPOT"
        self.risk_profile = risk_profile
        self.long_score = long_score
        self.long_status = "NOT_READY"
        self.short_score = short_score
        self.short_status = "NOT_READY"
        self.final_decision = final_decision
        self.final_reason = "test reason"
        self.directional_winner = None
        self.long_entry = None
        self.long_sl = None
        self.long_tp1 = None
        self.long_tp2 = None
        self.long_tp3 = None
        self.short_entry = None
        self.short_sl = None
        self.short_tp1 = None
        self.short_tp2 = None
        self.short_tp3 = None
        self.linked_signal_id = linked_signal_id


class _FakeSignalRecord:
    def __init__(self, id, status="OPEN"):
        self.id = id
        self.status = status


class FakeDatabase:
    """Duck-typed stand-in for app.database.db.Database, covering every
    method app_factory.py's routes actually call. No SQLAlchemy needed."""

    def __init__(self):
        self._watchlist: dict[str, _FakeWatchlistRow] = {}
        self._config = _FakeRuntimeConfig()
        self._counters: dict[str, _FakeCounter] = {}
        self._analysis_records: list[_FakeAnalysisRecord] = []
        self._signals: dict[str, _FakeSignalRecord] = {}
        self._stored_results: dict[str, object] = {}

    async def get_watchlist(self, enabled_only: bool = False):
        rows = list(self._watchlist.values())
        if enabled_only:
            rows = [r for r in rows if r.enabled]
        return sorted(rows, key=lambda r: r.display_order)

    async def add_watchlist_symbol(self, symbol: str, market_type: str):
        row = _FakeWatchlistRow(symbol, market_type, True, len(self._watchlist))
        self._watchlist[symbol] = row
        return row

    async def remove_watchlist_symbol(self, symbol: str) -> bool:
        return self._watchlist.pop(symbol, None) is not None

    async def set_watchlist_symbol_enabled(self, symbol: str, enabled: bool) -> bool:
        row = self._watchlist.get(symbol)
        if row is None:
            return False
        row.enabled = enabled
        return True

    async def reorder_watchlist(self, ordered_symbols):
        for i, symbol in enumerate(ordered_symbols):
            if symbol in self._watchlist:
                self._watchlist[symbol].display_order = i

    async def get_runtime_config(self):
        return self._config

    async def update_runtime_config(self, **fields):
        for k, v in fields.items():
            setattr(self._config, k, v)
        return self._config

    async def get_daily_counter(self, date_str: str):
        return self._counters.get(date_str)

    async def increment_daily_counter(self, field: str, date_str: str) -> None:
        counter = self._counters.setdefault(date_str, _FakeCounter())
        setattr(counter, field, getattr(counter, field) + 1)

    async def all_analysis_records(self, symbol: str | None = None):
        if symbol:
            return [r for r in self._analysis_records if r.symbol == symbol]
        return list(self._analysis_records)

    async def get_analysis_by_id(self, analysis_id: str):
        return next((r for r in self._analysis_records if r.id == analysis_id), None)

    async def get_stored_market_analysis_result(self, analysis_id: str):
        return self._stored_results.get(analysis_id)

    async def get_signal_by_id(self, signal_id: str):
        return self._signals.get(signal_id)


class _BackgroundLoop:
    """Runs a real asyncio event loop on a dedicated thread, exactly
    like main.py's main-thread loop would in production -- so AsyncBridge
    is exercised for real, not mocked."""

    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def stop(self):
        self.loop.call_soon_threadsafe(self.loop.stop)
        self.thread.join(timeout=2)


def _build_test_app(tmp_dir: str):
    bg = _BackgroundLoop()
    bridge = AsyncBridge(bg.loop)
    db = FakeDatabase()
    credential_manager = CredentialManager(data_dir=tmp_dir)
    monitoring = MonitoringController(initially_active=False)
    health = HealthService()

    app = create_app(
        bridge=bridge, db=db, credential_manager=credential_manager,
        monitoring_controller=monitoring, health=health,
        nobitex_base_url="https://apiv2.nobitex.ir", data_dir=tmp_dir,
    )
    app.config["TESTING"] = True
    return app, db, credential_manager, monitoring, bg


def test_root_redirects_to_setup_when_not_configured():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.get("/")
            assert resp.status_code == 302
            assert "/setup/1" in resp.headers["Location"]
        finally:
            bg.stop()


def test_setup_step1_renders_persian_rtl_form():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.get("/setup/1")
            assert resp.status_code == 200
            body = resp.get_data(as_text=True)
            assert 'dir="rtl"' in body
            assert "\u0646\u0648\u0628\u06cc\u062a\u06a9\u0633" in body
        finally:
            bg.stop()


def test_setup_step1_continue_saves_credentials_and_advances():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, credential_manager, monitoring, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            # Nobitex authenticates with a single API token (no separate
            # secret) -- see MAC_INSTALL... no, see SETUP_AND_UI.md section 5.
            resp = client.post("/setup/1", data={"action": "continue", "api_token": "tok1"})
            assert resp.status_code == 302
            assert "/setup/2" in resp.headers["Location"]

            key, secret = asyncio.run(credential_manager.get_nobitex_credentials())
            assert key == "tok1"
        finally:
            bg.stop()


def test_setup_step1_continue_without_fields_shows_error():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.post("/setup/1", data={"action": "continue"}, follow_redirects=True)
            assert resp.status_code == 200
            assert "\u0644\u0637\u0641\u0627\u064b" in resp.get_data(as_text=True)
        finally:
            bg.stop()


def test_setup_step4_add_and_remove_watchlist_symbol():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.post("/setup/4", data={"action": "add", "symbol": "BTCUSDT", "market_type": "TETHER"})
            assert resp.status_code == 302
            assert "BTCUSDT" in db._watchlist

            resp = client.post("/setup/4", data={"action": "remove", "symbol": "BTCUSDT"})
            assert resp.status_code == 302
            assert "BTCUSDT" not in db._watchlist
        finally:
            bg.stop()


def test_setup_step4_rejects_invalid_symbol_format():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            client.post("/setup/4", data={"action": "add", "symbol": "not a symbol!!", "market_type": "TETHER"})
            assert len(db._watchlist) == 0
        finally:
            bg.stop()


def test_setup_step5_completes_setup_and_starts_monitoring():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, _cm, monitoring, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            assert monitoring.is_active() is False

            resp = client.post("/setup/5", data={
                "auto_monitoring": "on", "event_alerts": "on",
                "alert_cooldown_seconds": "900",
            })
            assert resp.status_code == 302
            assert "/dashboard" in resp.headers["Location"]
            assert db._config.setup_completed is True
            assert monitoring.is_active() is True
        finally:
            bg.stop()


def test_setup_step5_without_auto_monitoring_keeps_paused():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, _cm, monitoring, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            client.post("/setup/5", data={})  # no checkboxes checked
            assert monitoring.is_active() is False
        finally:
            bg.stop()


def test_dashboard_shows_persian_status_after_setup():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            db._config.setup_completed = True
            client = app.test_client()
            resp = client.get("/dashboard")
            assert resp.status_code == 200
            body = resp.get_data(as_text=True)
            assert "\u067e\u0627\u06cc\u0634 \u0628\u0627\u0632\u0627\u0631" in body
            assert "\u0646\u0648\u0628\u06cc\u062a\u06a9\u0633" in body
        finally:
            bg.stop()


def test_root_redirects_to_dashboard_when_configured():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            db._config.setup_completed = True
            client = app.test_client()
            resp = client.get("/")
            assert resp.status_code == 302
            assert "/dashboard" in resp.headers["Location"]
        finally:
            bg.stop()


def test_dashboard_monitoring_pause_and_resume():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, _cm, monitoring, bg = _build_test_app(tmp)
        try:
            db._config.setup_completed = True
            asyncio.run(monitoring.start())
            client = app.test_client()

            resp = client.post("/dashboard/monitoring/pause")
            assert resp.status_code == 302
            assert monitoring.is_active() is False

            resp = client.post("/dashboard/monitoring/start")
            assert resp.status_code == 302
            assert monitoring.is_active() is True
        finally:
            bg.stop()


def test_settings_reset_clears_credentials_and_setup_flag():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, credential_manager, monitoring, bg = _build_test_app(tmp)
        try:
            asyncio.run(credential_manager.save_nobitex_credentials("k", "s"))
            db._config.setup_completed = True
            asyncio.run(monitoring.start())

            client = app.test_client()
            resp = client.post("/settings/reset")
            assert resp.status_code == 302

            key, _ = asyncio.run(credential_manager.get_nobitex_credentials())
            assert key is None
            assert db._config.setup_completed is False
            assert monitoring.is_active() is False
        finally:
            bg.stop()


def test_dashboard_redirects_to_setup_when_not_configured():
    """A stale bookmarked/reused browser tab must not be able to reach
    the dashboard before setup was ever completed."""
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            assert db._config.setup_completed is False
            client = app.test_client()
            resp = client.get("/dashboard")
            assert resp.status_code == 302
            assert "/setup/1" in resp.headers["Location"]
        finally:
            bg.stop()


def test_settings_home_renders():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.get("/settings")
            assert resp.status_code == 200
            assert "\u062a\u0646\u0638\u06cc\u0645\u0627\u062a" in resp.get_data(as_text=True)
        finally:
            bg.stop()


# --- MODULE_7: Live Analysis, Report History, JSON API ---------------- #

def test_analysis_page_renders_with_empty_watchlist():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.get("/analysis")
            assert resp.status_code == 200
            assert 'dir="rtl"' in resp.get_data(as_text=True)
        finally:
            bg.stop()


def test_analysis_run_without_credentials_shows_persian_error():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            db._watchlist["BTCUSDT"] = _FakeWatchlistRow("BTCUSDT", "TETHER")
            client = app.test_client()
            resp = client.get("/analysis?symbol=BTCUSDT&run=1")
            assert resp.status_code == 200
            body = resp.get_data(as_text=True)
            assert "\u0627\u062a\u0635\u0627\u0644 \u0646\u0648\u0628\u06cc\u062a\u06a9\u0633 \u062a\u0646\u0638\u06cc\u0645 \u0646\u0634\u062f\u0647" in body
        finally:
            bg.stop()


def test_reports_page_renders_empty():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.get("/reports")
            assert resp.status_code == 200
            assert "\u062a\u0627\u0631\u06cc\u062e\u0686\u0647" in resp.get_data(as_text=True)
        finally:
            bg.stop()


def test_reports_page_lists_records_with_outcome():
    import datetime as dt

    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            db._analysis_records.append(_FakeAnalysisRecord(
                "abc123", "BTCUSDT", dt.datetime.now(dt.UTC), final_decision="BUY",
                linked_signal_id="sig1",
            ))
            db._signals["sig1"] = _FakeSignalRecord("sig1", status="TP1_HIT")

            client = app.test_client()
            resp = client.get("/reports")
            assert resp.status_code == 200
            body = resp.get_data(as_text=True)
            assert "BTCUSDT" in body
            assert "\u0647\u062f\u0641 \u0627\u0648\u0644 \u0641\u0639\u0627\u0644 \u0634\u062f" in body  # TP1_HIT label
        finally:
            bg.stop()


def test_reports_page_filters_by_symbol():
    import datetime as dt

    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            db._analysis_records.append(_FakeAnalysisRecord("a1", "BTCUSDT", dt.datetime.now(dt.UTC)))
            db._analysis_records.append(_FakeAnalysisRecord("a2", "ETHUSDT", dt.datetime.now(dt.UTC)))

            client = app.test_client()
            resp = client.get("/reports?symbol=ETHUSDT")
            body = resp.get_data(as_text=True)
            assert "ETHUSDT" in body
            assert "BTCUSDT" not in body
        finally:
            bg.stop()


def test_report_detail_shows_not_available_for_unknown_id():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.get("/reports/nonexistent")
            assert resp.status_code == 200
            assert "\u062f\u0631 \u062f\u0633\u062a\u0631\u0633 \u0646\u06cc\u0633\u062a" in resp.get_data(as_text=True)
        finally:
            bg.stop()


def test_api_status_returns_json():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.get("/api/status")
            assert resp.status_code == 200
            data = resp.get_json()
            assert "monitoring_active" in data
            assert "nobitex" in data
            assert "enabled_symbol_count" in data
        finally:
            bg.stop()


def test_api_watchlist_get_and_post():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.post("/api/watchlist", json={"symbol": "BTCUSDT", "market_type": "TETHER"})
            assert resp.status_code == 201
            assert "BTCUSDT" in db._watchlist

            resp = client.get("/api/watchlist")
            assert resp.status_code == 200
            data = resp.get_json()
            assert any(item["symbol"] == "BTCUSDT" for item in data)
        finally:
            bg.stop()


def test_api_watchlist_post_rejects_invalid_symbol():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.post("/api/watchlist", json={"symbol": "!!bad!!", "market_type": "TETHER"})
            assert resp.status_code == 400
            assert len(db._watchlist) == 0
        finally:
            bg.stop()


def test_api_watchlist_delete():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            db._watchlist["BTCUSDT"] = _FakeWatchlistRow("BTCUSDT", "TETHER")
            client = app.test_client()
            resp = client.delete("/api/watchlist/BTCUSDT")
            assert resp.status_code == 200
            assert resp.get_json()["removed"] is True
            assert "BTCUSDT" not in db._watchlist
        finally:
            bg.stop()


def test_api_scanner_start_stop():
    with tempfile.TemporaryDirectory() as tmp:
        app, db, _cm, monitoring, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            client.post("/api/scanner/stop")
            assert monitoring.is_active() is False
            client.post("/api/scanner/start")
            assert monitoring.is_active() is True
        finally:
            bg.stop()


def test_api_reports_returns_json_list():
    import datetime as dt

    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            db._analysis_records.append(_FakeAnalysisRecord("a1", "BTCUSDT", dt.datetime.now(dt.UTC)))
            client = app.test_client()
            resp = client.get("/api/reports")
            assert resp.status_code == 200
            data = resp.get_json()
            assert len(data) == 1
            assert data[0]["symbol"] == "BTCUSDT"
        finally:
            bg.stop()


def test_api_analysis_run_without_credentials_returns_400():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.post("/api/analysis/BTCUSDT/run")
            assert resp.status_code == 400
            assert resp.get_json()["error"] == "nobitex_not_configured"
        finally:
            bg.stop()


def test_api_bale_test_without_credentials_returns_400():
    with tempfile.TemporaryDirectory() as tmp:
        app, *_rest, bg = _build_test_app(tmp)
        try:
            client = app.test_client()
            resp = client.post("/api/bale/test")
            assert resp.status_code == 400
            assert resp.get_json()["ok"] is False
        finally:
            bg.stop()


def test_dashboard_market_overview_shown_for_enabled_symbols():
    import datetime as dt

    with tempfile.TemporaryDirectory() as tmp:
        app, db, *_rest, bg = _build_test_app(tmp)
        try:
            db._config.setup_completed = True
            db._watchlist["BTCUSDT"] = _FakeWatchlistRow("BTCUSDT", "TETHER", enabled=True)
            db._analysis_records.append(_FakeAnalysisRecord(
                "a1", "BTCUSDT", dt.datetime.now(dt.UTC), final_decision="SELL",
            ))

            client = app.test_client()
            resp = client.get("/dashboard")
            assert resp.status_code == 200
            body = resp.get_data(as_text=True)
            assert "BTCUSDT" in body
        finally:
            bg.stop()
