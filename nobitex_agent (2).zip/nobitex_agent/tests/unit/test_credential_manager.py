from __future__ import annotations

import asyncio
import tempfile

from app.security.credential_manager import (
    BALE_BOT_TOKEN,
    NOBITEX_API_KEY,
    NOBITEX_API_SECRET,
    CredentialManager,
)


def test_falls_back_to_encrypted_file_when_keyring_unavailable():
    """In this sandboxed test environment there is no real OS keyring
    backend (no Secret Service / D-Bus session), so CredentialManager
    must transparently fall back to the encrypted-file store rather than
    raising."""
    with tempfile.TemporaryDirectory() as tmp:
        manager = CredentialManager(data_dir=tmp)
        asyncio.run(manager.save(NOBITEX_API_KEY, "my-key"))
        result = asyncio.run(manager.get(NOBITEX_API_KEY))
        assert result == "my-key"
        # Whichever backend it landed on, it must be one of the two
        # known, named backends -- never silently something else.
        assert manager.backend_name in ("keyring", "encrypted_file")


def test_save_and_get_nobitex_credentials_pair():
    with tempfile.TemporaryDirectory() as tmp:
        manager = CredentialManager(data_dir=tmp)
        asyncio.run(manager.save_nobitex_credentials("key-123", "secret-456"))
        key, secret = asyncio.run(manager.get_nobitex_credentials())
        assert key == "key-123"
        assert secret == "secret-456"


def test_save_and_get_bale_credentials_pair():
    with tempfile.TemporaryDirectory() as tmp:
        manager = CredentialManager(data_dir=tmp)
        asyncio.run(manager.save_bale_credentials("bot-token-xyz", "chat-id-789"))
        token, chat_id = asyncio.run(manager.get_bale_credentials())
        assert token == "bot-token-xyz"
        assert chat_id == "chat-id-789"


def test_clear_all_removes_every_credential():
    with tempfile.TemporaryDirectory() as tmp:
        manager = CredentialManager(data_dir=tmp)
        asyncio.run(manager.save_nobitex_credentials("k", "s"))
        asyncio.run(manager.save_bale_credentials("t", "c"))
        asyncio.run(manager.clear_all())

        assert asyncio.run(manager.get(NOBITEX_API_KEY)) is None
        assert asyncio.run(manager.get(NOBITEX_API_SECRET)) is None
        assert asyncio.run(manager.get(BALE_BOT_TOKEN)) is None


def test_get_missing_credentials_returns_none_tuple():
    with tempfile.TemporaryDirectory() as tmp:
        manager = CredentialManager(data_dir=tmp)
        key, secret = asyncio.run(manager.get_nobitex_credentials())
        assert key is None
        assert secret is None


def test_backend_name_is_stable_across_calls():
    with tempfile.TemporaryDirectory() as tmp:
        manager = CredentialManager(data_dir=tmp)
        first = manager.backend_name
        asyncio.run(manager.save(NOBITEX_API_KEY, "x"))
        second = manager.backend_name
        assert first == second
