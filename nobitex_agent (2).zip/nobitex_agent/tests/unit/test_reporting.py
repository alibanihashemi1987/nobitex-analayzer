from __future__ import annotations

import re
from dataclasses import replace
from datetime import UTC, datetime

from app.config.scoring_config import get_scoring_config
from app.domain.context import build_market_context
from app.domain.enums import ExecutionMode
from app.reporting.detailed_report import DetailedReportGenerator
from app.reporting.intent import is_detailed_report_request
from app.reporting.report_formatter import translate_reason
from app.reporting.report_keyboard import ReportKeyboardBuilder, parse_detailed_analysis_callback
from app.reporting.summary_report import SummaryReportGenerator
from app.services.analysis_service import _build_market_overview
from app.strategy.directional.evaluate_long import evaluate_long
from app.strategy.directional.evaluate_short import evaluate_short
from app.strategy.directional.resolver import resolve_final_decision
from tests.fixtures.sample_candles import uptrend_candles

_ENGLISH_PROSE_RE = re.compile(r"[A-Za-z]+(?:\s+[A-Za-z]+){3,}")


def _real_result(execution_mode=ExecutionMode.COMMITMENT):
    cfg = get_scoring_config()
    candles = uptrend_candles(n=250)
    ctx = build_market_context(
        symbol="BTCIRT", timestamp=datetime.now(UTC),
        candles_by_role={"HTF": candles, "MTF": candles, "LTF": candles, "EXECUTION": candles},
        role_to_timeframe={"HTF": "4H", "MTF": "1H", "LTF": "15M", "EXECUTION": "5M"},
        divergence_min_swing_distance=cfg.divergence.min_swing_distance,
        divergence_min_price_separation_pct=cfg.divergence.min_price_separation_pct,
        ma20_slope_lookback=cfg.ma20_slope_lookback,
        ob_atr_multiplier=cfg.order_block.strong_move_atr_multiplier,
        ob_atr_period=cfg.order_block.atr_period,
        fvg_invalidation_pct=cfg.fvg.invalidation_pct,
        premium_discount_equilibrium_buffer=cfg.premium_discount.buffer,
        orderbook_raw={"bids": [["99", "5"], ["98", "3"]], "asks": [["101", "4"], ["102", "2"]]},
        entry_hint=candles[-1].close,
    )
    long_r = evaluate_long(ctx, cfg, "moderate")
    short_r = evaluate_short(ctx, cfg, "moderate")
    result = resolve_final_decision(long_r, short_r, execution_mode, cfg.decision, "BTCIRT", datetime.now(UTC))
    return replace(result, market_overview=_build_market_overview(ctx))


def test_summary_report_shows_both_directions_on_wait():
    result = _real_result()
    report = SummaryReportGenerator().generate(result, "moderate")
    assert "\u062e\u0631\u06cc\u062f" in report  # BUY-side label present
    assert "\u0641\u0631\u0648\u0634" in report  # SELL-side label present
    assert f"{result.long_analysis.score:.0f}" in report
    assert f"{result.short_analysis.score:.0f}" in report


def test_summary_report_has_no_english_prose():
    result = _real_result()
    report = SummaryReportGenerator().generate(result, "moderate")
    matches = _ENGLISH_PROSE_RE.findall(report)
    assert matches == [], f"leaked English prose: {matches}"


def test_summary_report_spot_mode_short_ready_shows_not_eligible_not_hidden():
    result = _real_result(execution_mode=ExecutionMode.SPOT)
    report = SummaryReportGenerator().generate(result, "moderate")
    # Regardless of whether SHORT ends up READY in this synthetic
    # scenario, the report must always render without error and must
    # never silently omit the SHORT block.
    assert "\U0001F534" in report  # SHORT emoji present


def test_detailed_report_has_no_english_prose():
    result = _real_result()
    report = DetailedReportGenerator().generate(result, "moderate")
    matches = _ENGLISH_PROSE_RE.findall(report)
    assert matches == [], f"leaked English prose: {matches}"


def test_detailed_report_contains_analysis_id_and_both_scenarios():
    result = _real_result()
    report = DetailedReportGenerator().generate(result, "moderate")
    assert result.analysis_id in report
    assert "LONG" in report or "\u062e\u0631\u06cc\u062f" in report
    assert "SHORT" in report or "\u0641\u0631\u0648\u0634" in report


def test_detailed_report_shows_category_scores_for_both_directions():
    result = _real_result()
    report = DetailedReportGenerator().generate(result, "moderate")
    assert f"{result.long_analysis.score_breakdown.total:.0f}/100" in report
    assert f"{result.short_analysis.score_breakdown.total:.0f}/100" in report


def test_keyboard_builder_produces_correct_callback_format():
    kb = ReportKeyboardBuilder().detailed_analysis_button("abc123")
    button = kb["inline_keyboard"][0][0]
    assert button["callback_data"] == "detailed_analysis:abc123"
    assert len(button["text"]) > 0


def test_keyboard_callback_round_trip():
    kb = ReportKeyboardBuilder().detailed_analysis_button("my-analysis-id")
    callback_data = kb["inline_keyboard"][0][0]["callback_data"]
    assert parse_detailed_analysis_callback(callback_data) == "my-analysis-id"


def test_keyboard_callback_parser_rejects_malformed_data():
    assert parse_detailed_analysis_callback("garbage") is None
    assert parse_detailed_analysis_callback("") is None
    assert parse_detailed_analysis_callback("wrong_prefix:123") is None
    assert parse_detailed_analysis_callback("detailed_analysis:") is None


def test_detailed_report_intent_recognizes_persian_phrases():
    assert is_detailed_report_request("\u062a\u062d\u0644\u06cc\u0644 \u06a9\u0627\u0645\u0644 \u0644\u0637\u0641\u0627")
    assert is_detailed_report_request("\u062c\u0632\u0626\u06cc\u0627\u062a")
    assert not is_detailed_report_request("\u0633\u0644\u0627\u0645")
    assert not is_detailed_report_request("")


def test_translate_reason_never_leaks_english():
    known = "No valid, active HTF POI found for this direction."
    unknown = "Some brand new reason string the translator has never seen before."
    assert _ENGLISH_PROSE_RE.findall(translate_reason(known)) == []
    assert _ENGLISH_PROSE_RE.findall(translate_reason(unknown)) == []
    assert _ENGLISH_PROSE_RE.findall(translate_reason(None)) == []


def test_translate_reason_preserves_numbers_from_dynamic_templates():
    text = "R:R to TP1 (0.8) is below the minimum (1.0)."
    translated = translate_reason(text)
    assert "0.8" in translated
    assert "1.0" in translated
