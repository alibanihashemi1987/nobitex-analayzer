from __future__ import annotations

from app.config.scoring_config import get_scoring_config
from app.domain.enums import ExecutionMode
from app.services.backtest_service import run_backtest, summarize_backtest
from tests.fixtures.sample_candles import uptrend_candles


def test_backtest_runs_dual_direction_at_every_step():
    cfg = get_scoring_config()
    candles = uptrend_candles(n=100)
    steps = run_backtest(candles, cfg, ExecutionMode.COMMITMENT, "moderate", min_candles_per_step=60)

    assert len(steps) == len(candles) - 60 + 1
    for step in steps:
        # Every single step must carry BOTH directions' full result, never
        # a BUY-only / LONG-first shortcut (MANDATORY_ARCHITECTURE_CHANGE section 21).
        assert step.result.long_analysis is not None
        assert step.result.short_analysis is not None
        assert step.result.final_decision is not None


def test_backtest_is_reproducible():
    cfg = get_scoring_config()
    candles = uptrend_candles(n=80)
    steps_a = run_backtest(candles, cfg, ExecutionMode.COMMITMENT, "moderate", min_candles_per_step=60)
    steps_b = run_backtest(candles, cfg, ExecutionMode.COMMITMENT, "moderate", min_candles_per_step=60)

    for a, b in zip(steps_a, steps_b, strict=True):
        assert a.result.long_analysis.score == b.result.long_analysis.score
        assert a.result.short_analysis.score == b.result.short_analysis.score
        assert a.result.final_decision == b.result.final_decision


def test_backtest_summary_reports_both_directions_not_buy_only():
    cfg = get_scoring_config()
    candles = uptrend_candles(n=100)
    steps = run_backtest(candles, cfg, ExecutionMode.COMMITMENT, "moderate", min_candles_per_step=60)
    report = summarize_backtest(steps)

    # Section 23: must expose LONG and SHORT opportunity counts separately,
    # plus WAIT/CONFLICT periods -- never only "BUY signals".
    assert hasattr(report, "long_opportunities")
    assert hasattr(report, "short_opportunities")
    assert hasattr(report, "wait_periods")
    assert hasattr(report, "conflict_periods")
    assert report.wait_periods + report.buy_decisions + report.sell_decisions + report.conflict_periods == len(steps)
