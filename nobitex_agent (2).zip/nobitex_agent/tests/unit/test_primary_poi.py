from __future__ import annotations

from datetime import UTC, datetime

from app.domain.context import POIContext
from app.domain.enums import Direction, MitigationState, StructureEvent
from app.domain.models import FVG, OrderBlock, OTEZone
from app.strategy.scoring.primary_poi import primary_poi_strength_points, select_primary_poi

_NOW = datetime.now(UTC)


def _empty_poi_context(**overrides) -> POIContext:
    base = dict(
        fvgs=(), order_blocks=(), breaker_blocks=(),
        mitigation_blocks=(), volume_imbalances=(), ote_zone=None,
    )
    base.update(overrides)
    return POIContext(**base)


def test_order_block_outranks_fvg():
    ob = OrderBlock(
        direction=Direction.BULLISH, zone_upper=100, zone_lower=98,
        origin_candle_index=1, origin_time=_NOW, structure_event=StructureEvent.BOS,
        strength_score=0.8, active=True, mitigation_state=MitigationState.ACTIVE,
    )
    fvg = FVG(
        direction=Direction.BULLISH, upper=101, lower=99, size=2,
        created_time=_NOW, created_candle_index=2,
        mitigation_state=MitigationState.ACTIVE, active=True,
    )
    ctx = _empty_poi_context(order_blocks=(ob,), fvgs=(fvg,))
    result = select_primary_poi(Direction.BULLISH, ctx)
    assert result is not None
    assert result.poi_type == "ORDER_BLOCK"


def test_fvg_outranks_ote():
    fvg = FVG(
        direction=Direction.BULLISH, upper=101, lower=99, size=2,
        created_time=_NOW, created_candle_index=2,
        mitigation_state=MitigationState.ACTIVE, active=True,
    )
    ote = OTEZone(
        direction=Direction.BULLISH, fib_618=99, fib_705=98.5, fib_79=98,
        leg_start=95, leg_end=105, in_zone=True,
    )
    ctx = _empty_poi_context(fvgs=(fvg,), ote_zone=ote)
    result = select_primary_poi(Direction.BULLISH, ctx)
    assert result.poi_type == "FVG"


def test_invalidated_order_block_is_excluded():
    ob = OrderBlock(
        direction=Direction.BULLISH, zone_upper=100, zone_lower=98,
        origin_candle_index=1, origin_time=_NOW, structure_event=StructureEvent.BOS,
        strength_score=0.8, active=True, mitigation_state=MitigationState.INVALIDATED,
    )
    ctx = _empty_poi_context(order_blocks=(ob,))
    result = select_primary_poi(Direction.BULLISH, ctx)
    assert result is None


def test_wrong_direction_poi_is_excluded():
    ob = OrderBlock(
        direction=Direction.BEARISH, zone_upper=100, zone_lower=98,
        origin_candle_index=1, origin_time=_NOW, structure_event=StructureEvent.BOS,
        strength_score=0.8, active=True, mitigation_state=MitigationState.ACTIVE,
    )
    ctx = _empty_poi_context(order_blocks=(ob,))
    result = select_primary_poi(Direction.BULLISH, ctx)
    assert result is None


def test_no_poi_returns_none_and_zero_strength():
    ctx = _empty_poi_context()
    result = select_primary_poi(Direction.BULLISH, ctx)
    assert result is None
    assert primary_poi_strength_points(result) == 0.0
