from __future__ import annotations

from app.indicators.swings import detect_swings
from app.strategy.smc.structure import detect_structure_breaks
from tests.fixtures.sample_candles import make_series


def test_detect_swings_finds_a_high_and_a_low():
    ohlcs = [
        (100, 101, 99, 100),
        (100, 102, 99.5, 101),
        (101, 105, 100.5, 104),  # swing high candidate at idx 2
        (104, 104.5, 101, 102),
        (102, 102.5, 98, 99),  # swing low candidate at idx 4
        (99, 100, 98.5, 99.5),
        (99.5, 100.5, 99, 100),
    ]
    candles = make_series(ohlcs)
    swings = detect_swings(candles, lookback=2)
    directions_at_index = {s.index: s.direction.value for s in swings}
    assert directions_at_index.get(2) == "BEARISH"
    assert directions_at_index.get(4) == "BULLISH"


def test_bos_detected_after_pullback_and_breakout():
    # Rally to a swing high (idx2), pull back to a swing low (idx4), then
    # rally again and close beyond the swing high -> a structural break
    # in the BULLISH direction must be detected.
    ohlcs = [
        (100, 101, 99, 100),    # 0
        (100, 102, 99.5, 101),  # 1
        (101, 105, 100.5, 104),  # 2: swing high (high=105)
        (104, 104.5, 101, 102),  # 3
        (102, 102.5, 98, 99),   # 4: swing low
        (99, 100, 98.5, 99.5),  # 5
        (99.5, 100.5, 99, 100),  # 6
        (100, 101, 99.5, 100.5),  # 7
        (100.5, 103, 100, 102),  # 8
        (102, 104, 101.5, 103),  # 9
        (103, 106, 102.5, 105.5),  # 10: close 105.5 > swing high price 105 -> break
    ]
    candles = make_series(ohlcs)
    breaks = detect_structure_breaks(candles, swing_lookback=2)
    assert any(b.direction.value == "BULLISH" for b in breaks)
