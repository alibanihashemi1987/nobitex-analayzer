from __future__ import annotations

from datetime import UTC, datetime

from app.config.scoring_config import get_scoring_config
from app.database.serialization import (
    directional_analysis_from_dict,
    directional_analysis_to_dict,
    market_overview_from_dict,
    market_overview_to_dict,
)
from app.domain.context import build_market_context
from app.strategy.directional.evaluate_long import evaluate_long
from app.strategy.directional.evaluate_short import evaluate_short
from tests.fixtures.sample_candles import uptrend_candles


def _real_context():
    cfg = get_scoring_config()
    candles = uptrend_candles(n=250)
    ctx = build_market_context(
        symbol="BTCIRT", timestamp=datetime.now(UTC),
        candles_by_role={"HTF": candles, "MTF": candles, "LTF": candles, "EXECUTION": candles},
        role_to_timeframe={"HTF": "4H", "MTF": "1H", "LTF": "15M", "EXECUTION": "5M"},
        divergence_min_swing_distance=cfg.divergence.min_swing_distance,
        divergence_min_price_separation_pct=cfg.divergence.min_price_separation_pct,
        ma20_slope_lookback=cfg.ma20_slope_lookback,
        ob_atr_multiplier=cfg.order_block.strong_move_atr_multiplier,
        ob_atr_period=cfg.order_block.atr_period,
        fvg_invalidation_pct=cfg.fvg.invalidation_pct,
        premium_discount_equilibrium_buffer=cfg.premium_discount.buffer,
        orderbook_raw={"bids": [["99", "5"], ["98", "3"]], "asks": [["101", "4"], ["102", "2"]]},
        entry_hint=candles[-1].close,
    )
    return ctx, cfg


def test_directional_analysis_round_trip_preserves_score_and_factors():
    ctx, cfg = _real_context()
    original = evaluate_long(ctx, cfg, "moderate")

    d = directional_analysis_to_dict(original)
    restored = directional_analysis_from_dict(d)

    assert restored.direction == original.direction
    assert restored.status == original.status
    assert restored.score == original.score
    assert restored.score_breakdown.structure == original.score_breakdown.structure
    assert restored.score_breakdown.total == original.score_breakdown.total
    assert len(restored.score_breakdown.factors) == len(original.score_breakdown.factors)
    for a, b in zip(original.score_breakdown.factors, restored.score_breakdown.factors, strict=True):
        assert a.factor_id == b.factor_id
        assert a.awarded_points == b.awarded_points
        assert a.evidence == b.evidence
    assert restored.market_risk == original.market_risk
    assert restored.htf_alignment == original.htf_alignment
    assert restored.execution_eligibility == original.execution_eligibility
    assert restored.rejection_reasons == original.rejection_reasons
    assert restored.hard_gate_failures == original.hard_gate_failures


def test_directional_analysis_round_trip_preserves_poi_and_risk():
    ctx, cfg = _real_context()
    short_result = evaluate_short(ctx, cfg, "moderate")

    d = directional_analysis_to_dict(short_result)
    restored = directional_analysis_from_dict(d)

    if short_result.primary_poi is not None:
        assert restored.primary_poi is not None
        assert restored.primary_poi.poi_type == short_result.primary_poi.poi_type
        assert restored.primary_poi.zone_high == short_result.primary_poi.zone_high
    else:
        assert restored.primary_poi is None

    if short_result.risk is not None:
        assert restored.risk is not None
        assert restored.risk.entry == short_result.risk.entry
        assert restored.risk.risk_reward_tp1 == short_result.risk.risk_reward_tp1
    else:
        assert restored.risk is None


def test_market_overview_round_trip():
    from app.services.analysis_service import _build_market_overview

    ctx, _ = _real_context()
    original = _build_market_overview(ctx)
    d = market_overview_to_dict(original)
    restored = market_overview_from_dict(d)

    assert restored.htf.timeframe == original.htf.timeframe
    assert restored.htf.trend == original.htf.trend
    assert restored.price_above_ma200 == original.price_above_ma200
    assert restored.ma20_above_ma200 == original.ma20_above_ma200


def test_market_overview_none_round_trips_to_none():
    assert market_overview_to_dict(None) is None
    assert market_overview_from_dict(None) is None
