from __future__ import annotations

from app.config.scoring_config import CategoryWeights, get_scoring_config
from app.domain.context import LiquidityContext, MarketContext, OrderBookContext, POIContext, StructureState, TimeframeSnapshot, IndicatorContext
from app.domain.enums import DataValidity, Direction
from app.domain.models import MovingAverageResult, CrossType
from app.strategy.scoring.hard_gates import (
    gate_1_data_validity,
    gate_2_htf_structure_confirmed,
    gate_3_valid_htf_poi,
    gate_4_premium_discount_direction,
    gate_5_valid_risk_setup,
)


def test_category_weights_must_sum_to_100():
    try:
        CategoryWeights(structure=20, poi=25, liquidity=15, momentum=10, mtf=10, orderbook=10, execution=5, premium_discount=4)
        assert False, "should have raised"
    except ValueError:
        pass


def test_default_scoring_config_loads_and_validates():
    cfg = get_scoring_config()
    total = (
        cfg.categories.structure + cfg.categories.poi + cfg.categories.liquidity + cfg.categories.momentum
        + cfg.categories.mtf + cfg.categories.orderbook + cfg.categories.execution + cfg.categories.premium_discount
    )
    assert total == 100


def _empty_context(data_validity=DataValidity.VALID, num_swings=0) -> MarketContext:
    empty_ma = MovingAverageResult(ma20=None, ma200=None, price_vs_ma200=None, cross_type=CrossType.NONE)
    from app.domain.models import RSIResult, MFIResult
    indicators = IndicatorContext(ma=empty_ma, ma20_slope_pct=None, rsi=RSIResult(value=None), mfi=MFIResult(value=None, overbought=False, oversold=False), atr=None, premium_discount=None)
    structure = StructureState(swings=tuple(range(num_swings)), breaks=(), trend=None)  # placeholder swings just for length check
    pois = POIContext(fvgs=(), order_blocks=(), breaker_blocks=(), mitigation_blocks=(), volume_imbalances=(), ote_zone=None)
    liquidity = LiquidityContext(sweeps=(), turtle_soups=())
    snap = TimeframeSnapshot(role="HTF", timeframe="4H", candles=(), structure=structure, pois=pois, liquidity=liquidity, indicators=indicators)
    return MarketContext(symbol="BTCIRT", timestamp=None, timeframes={"HTF": snap}, orderbook=None, data_validity=data_validity)


def test_gate_1_fails_on_invalid_data():
    ctx = _empty_context(data_validity=DataValidity.INSUFFICIENT_DATA)
    result = gate_1_data_validity(ctx)
    assert result.passed is False


def test_gate_1_passes_on_valid_data():
    ctx = _empty_context(data_validity=DataValidity.VALID)
    assert gate_1_data_validity(ctx).passed is True


def test_gate_2_fails_with_too_few_swings():
    ctx = _empty_context(num_swings=1)
    assert gate_2_htf_structure_confirmed(ctx).passed is False


def test_gate_2_passes_with_enough_swings():
    ctx = _empty_context(num_swings=3)
    assert gate_2_htf_structure_confirmed(ctx).passed is True


def test_gate_3_fails_without_poi():
    assert gate_3_valid_htf_poi(None).passed is False


def test_gate_4_fails_when_pd_gate_failed_flag_set():
    result = gate_4_premium_discount_direction(True, Direction.BULLISH)
    assert result.passed is False
    assert "Premium" in result.reason


def test_gate_5_fails_without_risk():
    assert gate_5_valid_risk_setup(None, 1.0).passed is False
