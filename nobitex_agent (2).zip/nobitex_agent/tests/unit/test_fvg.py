from __future__ import annotations

from app.strategy.ict.fvg import detect_fvgs
from tests.fixtures.sample_candles import make_series


def test_bullish_fvg_detected():
    ohlcs = [
        (100, 101, 99, 100),      # idx 0: high=101
        (100, 102, 100, 101),     # idx 1
        (104.5, 106, 104, 105),   # idx 2: low=104 > idx0.high=101 -> bullish FVG
    ]
    candles = make_series(ohlcs)
    fvgs = detect_fvgs(candles)
    assert len(fvgs) == 1
    fvg = fvgs[0]
    assert fvg.direction.value == "BULLISH"
    assert fvg.lower == 101  # high of candle 0
    assert fvg.upper == 104  # low of candle 2


def test_bearish_fvg_detected():
    ohlcs = [
        (100, 101, 99, 100),   # idx 0: low=99
        (99, 99.5, 97, 98),    # idx 1
        (95, 96, 94, 95),      # idx 2: high=96 < idx0.low=99 -> bearish FVG
    ]
    candles = make_series(ohlcs)
    fvgs = detect_fvgs(candles)
    assert len(fvgs) == 1
    assert fvgs[0].direction.value == "BEARISH"


def test_fvg_mitigation_marks_inactive_past_threshold():
    ohlcs = [
        (100, 101, 99, 100),
        (100, 102, 100, 101),
        (104.5, 106, 104, 105),  # bullish FVG [101, 104]
        (104, 104.5, 101.4, 102),  # penetrates > 50% of gap -> mitigated
    ]
    candles = make_series(ohlcs)
    fvgs = detect_fvgs(candles, invalidation_pct=0.5)
    assert fvgs[0].active is False
    assert fvgs[0].mitigation_state.value == "MITIGATED"


def test_no_fvg_without_gap():
    ohlcs = [
        (100, 101, 99, 100),
        (100, 101.5, 99.5, 101),
        (101, 101.8, 100, 101.2),
    ]
    candles = make_series(ohlcs)
    assert detect_fvgs(candles) == []
