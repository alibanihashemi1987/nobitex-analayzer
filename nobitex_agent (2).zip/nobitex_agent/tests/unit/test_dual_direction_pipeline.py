from __future__ import annotations

from datetime import UTC, datetime

from app.config.scoring_config import get_scoring_config
from app.domain.context import StructureState, build_market_context
from app.domain.enums import Direction, HTFAlignmentStrength, StructureEvent, TechnicalStatus
from app.domain.models import StructureBreak, SwingPoint
from app.strategy.directional.evaluate_long import evaluate_long
from app.strategy.directional.evaluate_short import evaluate_short
from app.strategy.directional.resolver import resolve_final_decision
from app.strategy.scoring.htf_alignment import classify_htf_alignment
from tests.fixtures.sample_candles import uptrend_candles

_NOW = datetime(2026, 1, 1, tzinfo=UTC)


def _swing(price: float) -> SwingPoint:
    return SwingPoint(index=0, time=_NOW, price=price, direction=Direction.BULLISH, confirmed=True)


def _break(event: StructureEvent, direction: Direction, idx: int) -> StructureBreak:
    return StructureBreak(event=event, direction=direction, time=_NOW, broken_swing=_swing(100), breaking_candle_index=idx)


def test_htf_alignment_neutral_when_no_trend():
    state = StructureState(swings=(), breaks=(), trend=None)
    assert classify_htf_alignment(Direction.BULLISH, state) == HTFAlignmentStrength.NEUTRAL


def test_htf_alignment_opposite_when_trend_disagrees():
    breaks = (_break(StructureEvent.CHOCH, Direction.BEARISH, 0),)
    state = StructureState(swings=(), breaks=breaks, trend=Direction.BEARISH)
    assert classify_htf_alignment(Direction.BULLISH, state) == HTFAlignmentStrength.OPPOSITE


def test_htf_alignment_weak_right_after_choch():
    breaks = (_break(StructureEvent.CHOCH, Direction.BULLISH, 0),)
    state = StructureState(swings=(), breaks=breaks, trend=Direction.BULLISH)
    assert classify_htf_alignment(Direction.BULLISH, state) == HTFAlignmentStrength.WEAK


def test_htf_alignment_strong_after_three_bos():
    breaks = (
        _break(StructureEvent.CHOCH, Direction.BULLISH, 0),
        _break(StructureEvent.BOS, Direction.BULLISH, 1),
        _break(StructureEvent.BOS, Direction.BULLISH, 2),
        _break(StructureEvent.BOS, Direction.BULLISH, 3),
    )
    state = StructureState(swings=(), breaks=breaks, trend=Direction.BULLISH)
    assert classify_htf_alignment(Direction.BULLISH, state) == HTFAlignmentStrength.STRONG


def test_full_dual_direction_pipeline_produces_valid_scores_and_a_final_decision():
    """End-to-end sanity check exercising every scoring category (A-H) via
    both evaluate_long and evaluate_short on the same MarketContext, then
    the resolver. Asserts internal invariants rather than a specific
    decision (the exact decision depends on many interacting factors and
    is covered more precisely by test_resolver.py's crafted scenarios)."""
    cfg = get_scoring_config()
    candles = uptrend_candles(n=250)

    ctx = build_market_context(
        symbol="BTCIRT",
        timestamp=datetime.now(UTC),
        candles_by_role={"HTF": candles, "MTF": candles, "LTF": candles, "EXECUTION": candles},
        role_to_timeframe={"HTF": "4H", "MTF": "1H", "LTF": "15M", "EXECUTION": "5M"},
        divergence_min_swing_distance=cfg.divergence.min_swing_distance,
        divergence_min_price_separation_pct=cfg.divergence.min_price_separation_pct,
        ma20_slope_lookback=cfg.ma20_slope_lookback,
        ob_atr_multiplier=cfg.order_block.strong_move_atr_multiplier,
        ob_atr_period=cfg.order_block.atr_period,
        fvg_invalidation_pct=cfg.fvg.invalidation_pct,
        premium_discount_equilibrium_buffer=cfg.premium_discount.buffer,
        orderbook_raw={"bids": [["99", "5"], ["98", "3"]], "asks": [["101", "4"], ["102", "2"]]},
        entry_hint=candles[-1].close,
    )

    long_r = evaluate_long(ctx, cfg, "moderate")
    short_r = evaluate_short(ctx, cfg, "moderate")

    # Every category score must respect its configured maximum.
    assert 0 <= long_r.score_breakdown.structure <= cfg.categories.structure
    assert 0 <= long_r.score_breakdown.poi <= cfg.categories.poi
    assert 0 <= long_r.score_breakdown.liquidity <= cfg.categories.liquidity
    assert 0 <= long_r.score_breakdown.momentum <= cfg.categories.momentum
    assert 0 <= long_r.score_breakdown.mtf <= cfg.categories.mtf
    assert 0 <= long_r.score_breakdown.orderbook <= cfg.categories.orderbook
    assert 0 <= long_r.score_breakdown.execution <= cfg.categories.execution
    assert 0 <= long_r.score_breakdown.premium_discount <= cfg.categories.premium_discount
    assert 0 <= long_r.score <= 100
    assert 0 <= short_r.score <= 100

    # LONG never depends on SHORT and vice versa: re-evaluating LONG alone
    # (without ever computing short_r first) must give the identical result.
    long_r_again = evaluate_long(ctx, cfg, "moderate")
    assert long_r_again.score == long_r.score
    assert long_r_again.status == long_r.status

    result = resolve_final_decision(long_r, short_r, __import__("app.domain.enums", fromlist=["ExecutionMode"]).ExecutionMode.COMMITMENT, cfg.decision, "BTCIRT", datetime.now(UTC))
    assert result.final_decision is not None
    # WAIT/CONFLICT must always carry a non-empty explanation.
    assert len(result.final_reason) > 0
    if long_r.status != TechnicalStatus.READY and short_r.status != TechnicalStatus.READY:
        assert result.final_decision.value == "WAIT"
