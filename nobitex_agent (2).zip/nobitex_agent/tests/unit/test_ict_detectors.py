from __future__ import annotations

from app.strategy.ict.breaker_block import detect_breaker_blocks
from app.strategy.ict.order_block import detect_order_blocks
from app.strategy.liquidity.liquidity import detect_liquidity_sweeps
from app.strategy.smc.structure import detect_structure_breaks
from tests.fixtures.sample_candles import make_series

_PULLBACK_AND_IMPULSE = [
    (100, 101, 99, 100),       # 0
    (100, 102, 99.5, 101),     # 1
    (101, 105, 100.5, 104),    # 2: swing high (105)
    (104, 104.5, 101, 102),    # 3
    (102, 102.5, 98, 99),      # 4: swing low, last bearish candle before break -> OB origin
    (99, 100, 98.5, 99.5),     # 5
    (99.5, 100.5, 99, 100),    # 6
    (100, 101, 99.5, 100.5),   # 7
    (100.5, 108, 100, 107),    # 8: strong impulse candle -> breaks structure bullish
    (107, 109, 106, 108),      # 9
    (108, 110, 107, 109),      # 10
]


def test_order_block_detected_on_strong_impulse():
    candles = make_series(_PULLBACK_AND_IMPULSE)
    breaks = detect_structure_breaks(candles, swing_lookback=2)
    obs = detect_order_blocks(candles, breaks, atr_multiplier=1.0, atr_period=3)
    assert len(obs) == 1
    assert obs[0].direction.value == "BULLISH"
    assert obs[0].origin_candle_index == 4  # last bearish candle before the break


def test_order_block_requires_atr_warmup():
    """With too few candles for the configured ATR period, no OB should be
    fabricated — the detector must skip rather than guess."""
    candles = make_series(_PULLBACK_AND_IMPULSE)
    breaks = detect_structure_breaks(candles, swing_lookback=2)
    obs = detect_order_blocks(candles, breaks, atr_multiplier=1.0, atr_period=14)
    assert obs == []


def test_breaker_block_forms_after_ob_invalidation():
    # Extend with candles that close back below the OB zone_lower to invalidate it.
    extended = _PULLBACK_AND_IMPULSE + [
        (109, 109.5, 95, 96),   # sharp reversal, closes well below OB zone_lower (98)
        (96, 97, 94, 95),
    ]
    candles = make_series(extended)
    breaks = detect_structure_breaks(candles, swing_lookback=2)
    obs = detect_order_blocks(candles, breaks, atr_multiplier=1.0, atr_period=3)
    breakers = detect_breaker_blocks(candles, obs)
    assert len(breakers) == 1
    assert breakers[0].new_direction.value == "BEARISH"


def test_liquidity_sweep_detects_wick_below_swing_low_with_reversal():
    ohlcs = _PULLBACK_AND_IMPULSE + [
        (109, 110, 96.5, 97),   # wick trades below swing low (98) then...
        (97, 100, 96, 99.6),
        (99.6, 101.5, 99, 101),  # ...closes back above 98 within confirmation window
    ]
    candles = make_series(ohlcs)
    sweeps = detect_liquidity_sweeps(candles, swing_lookback=2, confirmation_candles=3)
    bullish_sweeps = [s for s in sweeps if s.direction.value == "BULLISH"]
    assert any(s.reversal_confirmed for s in bullish_sweeps)
