from __future__ import annotations

import pytest

from app.core.exceptions import InvalidSetupError
from app.domain.enums import Direction
from app.risk.risk_engine import calculate_risk_levels


def test_long_setup_basic():
    risk = calculate_risk_levels(
        direction=Direction.BULLISH, entry=100.0, invalidation_level=95.0, atr_buffer=1.0
    )
    assert risk.stop_loss == 94.0
    assert risk.tp1 == 106.0  # entry + 1R (risk=6)
    assert risk.risk_reward_tp1 == 1.0
    assert risk.risk_reward_tp2 == 2.0
    assert risk.risk_reward_tp3 == 3.0


def test_short_setup_basic():
    risk = calculate_risk_levels(
        direction=Direction.BEARISH, entry=100.0, invalidation_level=105.0, atr_buffer=1.0
    )
    assert risk.stop_loss == 106.0
    assert risk.tp1 == 94.0
    assert risk.risk_reward_tp1 == 1.0


def test_invalid_setup_raises_when_sl_wrong_side():
    with pytest.raises(InvalidSetupError):
        calculate_risk_levels(
            direction=Direction.BULLISH, entry=100.0, invalidation_level=101.0, atr_buffer=1.0
        )


def test_opposing_level_caps_target():
    risk = calculate_risk_levels(
        direction=Direction.BULLISH,
        entry=100.0,
        invalidation_level=95.0,
        atr_buffer=1.0,
        opposing_levels=[103.0],  # closer than 1R target of 106
    )
    assert risk.tp1 == 103.0
