from __future__ import annotations

import os

from app.config.settings import Settings


def test_default_nobitex_base_url_is_apiv2():
    """Nobitex's real API base URL is apiv2.nobitex.ir (confirmed against
    official documentation examples and Nobitex support directly) --
    the older api.nobitex.ir hostname no longer resolves. See
    CONFIGURATION.md."""
    prior = os.environ.pop("NOBITEX_BASE_URL", None)
    try:
        settings = Settings()
        assert settings.nobitex_base_url == "https://apiv2.nobitex.ir"
    finally:
        if prior is not None:
            os.environ["NOBITEX_BASE_URL"] = prior


def test_nobitex_base_url_still_overridable_via_env():
    prior = os.environ.get("NOBITEX_BASE_URL")
    os.environ["NOBITEX_BASE_URL"] = "https://testnetapiv2.nobitex.ir"
    try:
        settings = Settings()
        assert settings.nobitex_base_url == "https://testnetapiv2.nobitex.ir"
    finally:
        if prior is not None:
            os.environ["NOBITEX_BASE_URL"] = prior
        else:
            os.environ.pop("NOBITEX_BASE_URL", None)
