from __future__ import annotations

from app.indicators.ma import compute_moving_averages, sma
from app.indicators.mfi import compute_mfi_series
from app.indicators.rsi import compute_rsi_series
from tests.fixtures.sample_candles import uptrend_candles


def test_sma_basic():
    values = [1, 2, 3, 4, 5]
    result = sma(values, 2)
    assert result[0] is None
    assert result[1] == 1.5
    assert result[4] == 4.5


def test_ma200_requires_enough_candles():
    candles = uptrend_candles(n=50)
    result = compute_moving_averages(candles)
    assert result.ma200 is None
    assert result.ma20 is not None


def test_ma200_bullish_bias_in_uptrend():
    candles = uptrend_candles(n=250)
    result = compute_moving_averages(candles)
    assert result.ma200 is not None
    assert result.price_vs_ma200.value == "BULLISH"


def test_rsi_series_bounded_0_100():
    candles = uptrend_candles(n=60)
    closes = [c.close for c in candles]
    series = compute_rsi_series(closes, period=14)
    for v in series:
        if v is not None:
            assert 0.0 <= v <= 100.0


def test_rsi_strong_uptrend_is_high():
    candles = uptrend_candles(n=60)
    closes = [c.close for c in candles]
    series = compute_rsi_series(closes, period=14)
    assert series[-1] is not None
    assert series[-1] > 60  # persistent uptrend -> elevated RSI


def test_mfi_series_bounded_0_100():
    candles = uptrend_candles(n=60)
    series = compute_mfi_series(candles, period=10)
    for v in series:
        if v is not None:
            assert 0.0 <= v <= 100.0
