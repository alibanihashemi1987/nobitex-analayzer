from __future__ import annotations

from datetime import UTC, datetime

from app.config.scoring_config import DecisionConfig
from app.domain.directional import DirectionalAnalysis
from app.domain.enums import (
    ExecutionEligibility,
    ExecutionMode,
    FinalDecision,
    HTFAlignmentStrength,
    MarketRiskLevel,
    TechnicalStatus,
)
from app.domain.events import ScoreBreakdown
from app.strategy.directional.resolver import resolve_final_decision

_DECISION_CFG = DecisionConfig(minimum_directional_score_difference=8)
_NOW = datetime.now(UTC)


def _breakdown(total: float) -> ScoreBreakdown:
    return ScoreBreakdown(
        structure=0, poi=0, liquidity=0, momentum=0, mtf=0, orderbook=0,
        execution=0, premium_discount=0, total=total, factors=(),
    )


def _analysis(
    direction: str,
    score: float,
    status: TechnicalStatus = TechnicalStatus.READY,
    market_risk: MarketRiskLevel = MarketRiskLevel.MEDIUM,
    htf_alignment: HTFAlignmentStrength = HTFAlignmentStrength.NEUTRAL,
    hard_gates_passed: bool = True,
) -> DirectionalAnalysis:
    return DirectionalAnalysis(
        direction=direction,
        status=status,
        execution_eligibility=ExecutionEligibility.UNKNOWN,
        execution_ineligibility_reason=None,
        score_breakdown=_breakdown(score),
        execution_quality=4.0,
        market_risk=market_risk,
        htf_alignment=htf_alignment,
        hard_gates_passed=hard_gates_passed,
        hard_gate_failures=(),
        primary_poi=None,
        risk=None,
        rejection_reasons=(),
    )


def test_both_not_ready_returns_wait():
    long_a = _analysis("LONG", 72, status=TechnicalStatus.NOT_READY)
    short_a = _analysis("SHORT", 69, status=TechnicalStatus.NOT_READY)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.COMMITMENT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.WAIT
    assert "LONG was evaluated but did not qualify" in result.final_reason
    assert "SHORT was evaluated but did not qualify" in result.final_reason


def test_long_ready_short_not_ready_yields_buy_in_commitment_mode():
    long_a = _analysis("LONG", 88, status=TechnicalStatus.READY)
    short_a = _analysis("SHORT", 64, status=TechnicalStatus.NOT_READY)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.COMMITMENT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.BUY
    assert result.directional_winner == "LONG"


def test_short_ready_long_not_ready_yields_sell_in_commitment_mode():
    long_a = _analysis("LONG", 67, status=TechnicalStatus.NOT_READY)
    short_a = _analysis("SHORT", 91, status=TechnicalStatus.READY)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.COMMITMENT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.SELL
    assert result.directional_winner == "SHORT"


def test_short_ready_in_spot_mode_yields_wait_but_preserves_technical_status():
    long_a = _analysis("LONG", 72, status=TechnicalStatus.NOT_READY)
    short_a = _analysis("SHORT", 91, status=TechnicalStatus.READY)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.SPOT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.WAIT
    # The technical SHORT analysis must NOT be discarded or downgraded.
    assert result.short_analysis.status == TechnicalStatus.READY
    assert result.short_analysis.execution_eligibility == ExecutionEligibility.NOT_ELIGIBLE
    assert "SPOT" in result.final_reason


def test_long_ready_in_spot_mode_is_eligible_and_executes():
    long_a = _analysis("LONG", 88, status=TechnicalStatus.READY)
    short_a = _analysis("SHORT", 60, status=TechnicalStatus.NOT_READY)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.SPOT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.BUY
    assert result.long_analysis.execution_eligibility == ExecutionEligibility.ELIGIBLE


def test_both_ready_large_score_gap_picks_higher_score():
    long_a = _analysis("LONG", 93, status=TechnicalStatus.READY)
    short_a = _analysis("SHORT", 78, status=TechnicalStatus.READY)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.COMMITMENT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.BUY
    assert result.directional_winner == "LONG"
    assert result.score_difference == 15


def test_both_ready_small_gap_no_htf_signal_is_conflict():
    long_a = _analysis("LONG", 84, status=TechnicalStatus.READY, htf_alignment=HTFAlignmentStrength.NEUTRAL)
    short_a = _analysis("SHORT", 81, status=TechnicalStatus.READY, htf_alignment=HTFAlignmentStrength.NEUTRAL)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.COMMITMENT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.CONFLICT
    assert result.directional_winner is None


def test_both_ready_equal_strong_alignment_does_not_force_a_decision():
    long_a = _analysis("LONG", 84, status=TechnicalStatus.READY, htf_alignment=HTFAlignmentStrength.STRONG)
    short_a = _analysis("SHORT", 82, status=TechnicalStatus.READY, htf_alignment=HTFAlignmentStrength.STRONG)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.COMMITMENT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.CONFLICT


def test_both_ready_small_gap_htf_tie_break_selects_stronger_alignment():
    long_a = _analysis("LONG", 83, status=TechnicalStatus.READY, htf_alignment=HTFAlignmentStrength.STRONG)
    short_a = _analysis("SHORT", 81, status=TechnicalStatus.READY, htf_alignment=HTFAlignmentStrength.OPPOSITE)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.COMMITMENT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.BUY
    assert result.directional_winner == "LONG"
    assert result.htf_tie_break_used is True


def test_htf_tie_break_never_applies_with_critical_risk():
    long_a = _analysis("LONG", 83, status=TechnicalStatus.READY,
                        htf_alignment=HTFAlignmentStrength.STRONG, market_risk=MarketRiskLevel.CRITICAL)
    short_a = _analysis("SHORT", 81, status=TechnicalStatus.READY, htf_alignment=HTFAlignmentStrength.OPPOSITE)
    result = resolve_final_decision(long_a, short_a, ExecutionMode.COMMITMENT, _DECISION_CFG, "BTCIRT", _NOW)
    assert result.final_decision == FinalDecision.CONFLICT
