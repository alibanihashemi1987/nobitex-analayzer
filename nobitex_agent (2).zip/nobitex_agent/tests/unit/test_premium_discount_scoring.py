from __future__ import annotations

from app.domain.enums import Direction, ZoneType
from app.domain.models import PremiumDiscountZone
from app.strategy.scoring.category_premium_discount import score_premium_discount


def _zone(current_zone: ZoneType) -> PremiumDiscountZone:
    return PremiumDiscountZone(
        range_high=110, range_low=90, equilibrium=100,
        current_zone=current_zone, current_price=95,
    )


def test_long_in_discount_scores_full_no_gate_failure():
    points, factors, gate_failed = score_premium_discount(Direction.BULLISH, _zone(ZoneType.DISCOUNT))
    assert points == 5.0
    assert gate_failed is False


def test_long_in_premium_scores_zero_and_fails_gate():
    points, factors, gate_failed = score_premium_discount(Direction.BULLISH, _zone(ZoneType.PREMIUM))
    assert points == 0.0
    assert gate_failed is True


def test_long_in_equilibrium_buffer_gets_reduced_score_no_gate_failure():
    points, factors, gate_failed = score_premium_discount(Direction.BULLISH, _zone(ZoneType.EQUILIBRIUM))
    assert points == 2.0
    assert gate_failed is False


def test_short_in_premium_scores_full():
    points, factors, gate_failed = score_premium_discount(Direction.BEARISH, _zone(ZoneType.PREMIUM))
    assert points == 5.0
    assert gate_failed is False


def test_short_in_discount_fails_gate():
    points, factors, gate_failed = score_premium_discount(Direction.BEARISH, _zone(ZoneType.DISCOUNT))
    assert points == 0.0
    assert gate_failed is True


def test_missing_zone_data_does_not_fail_gate():
    points, factors, gate_failed = score_premium_discount(Direction.BULLISH, None)
    assert points == 0.0
    assert gate_failed is False
