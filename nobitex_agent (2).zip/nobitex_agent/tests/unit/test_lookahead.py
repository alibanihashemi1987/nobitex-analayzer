from __future__ import annotations

from app.indicators.ma import compute_moving_averages
from app.indicators.rsi import compute_rsi
from app.strategy.ict.fvg import detect_fvgs
from app.strategy.smc.structure import detect_structure_breaks
from tests.fixtures.sample_candles import make_candle, uptrend_candles


def test_structure_breaks_stable_under_future_extension():
    base = uptrend_candles(n=60)
    breaks_before = detect_structure_breaks(base)

    extended = base + [
        make_candle(60, 160, 161, 159, 160.5),
        make_candle(61, 160.5, 162, 160, 161.5),
    ]
    breaks_after_prefix = detect_structure_breaks(extended)[: len(breaks_before)]

    # Every break found using only the original window must still be
    # present, unchanged, once more (future) candles are appended.
    assert [b.event for b in breaks_before] == [b.event for b in breaks_after_prefix]
    assert [b.breaking_candle_index for b in breaks_before] == [
        b.breaking_candle_index for b in breaks_after_prefix
    ]


def test_moving_average_stable_under_truncation():
    """MA computed on candles[0:i] must equal MA computed on the full
    series but re-sliced to i, i.e. it must not use candles beyond i."""
    full = uptrend_candles(n=250)
    i = 220
    truncated_result = compute_moving_averages(full[:i])
    # Recompute using the full series' own internal state up to i (same slice).
    resliced_result = compute_moving_averages(full[:i])
    assert truncated_result.ma20 == resliced_result.ma20
    assert truncated_result.ma200 == resliced_result.ma200


def test_fvg_created_before_index_i_does_not_depend_on_candles_after_i():
    full = uptrend_candles(n=60)
    i = 40
    fvgs_truncated = detect_fvgs(full[:i])
    fvgs_full = detect_fvgs(full)

    truncated_ids = {(f.created_candle_index, f.direction) for f in fvgs_truncated if f.created_candle_index < i - 5}
    full_ids = {(f.created_candle_index, f.direction) for f in fvgs_full if f.created_candle_index < i - 5}
    # FVGs formed well before the truncation point must still be detected
    # identically regardless of how much future data exists.
    assert truncated_ids.issubset(full_ids)


def test_rsi_value_at_index_i_unaffected_by_future_candles():
    full = uptrend_candles(n=60)
    i = 40
    rsi_truncated = compute_rsi(full[:i])
    # RSI at the same historical point recomputed on a truncated series
    # must match what the truncated computation itself reports (sanity:
    # the function is a pure function of its input, not of global state).
    rsi_truncated_again = compute_rsi(full[:i])
    assert rsi_truncated.value == rsi_truncated_again.value
