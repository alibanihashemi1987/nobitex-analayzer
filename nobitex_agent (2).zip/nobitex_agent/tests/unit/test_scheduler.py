from __future__ import annotations

import asyncio

from app.config.scoring_config import get_scoring_config
from app.config.settings import Settings
from app.monitoring.health_service import HealthService
from app.runtime.monitoring_controller import MonitoringController
from app.scheduler.scheduler import _resolve_symbols, build_scheduler


class _FakeWatchlistRow:
    def __init__(self, symbol):
        self.symbol = symbol


class FakeDatabaseForScheduler:
    def __init__(self, watchlist_symbols=()):
        self._watchlist = [_FakeWatchlistRow(s) for s in watchlist_symbols]
        self.get_watchlist_calls = 0
        self.increment_calls: list[tuple[str, str]] = []

    async def get_watchlist(self, enabled_only: bool = False):
        self.get_watchlist_calls += 1
        return self._watchlist

    async def increment_daily_counter(self, field: str, date_str: str) -> None:
        self.increment_calls.append((field, date_str))


def _settings(default_symbol="BTCIRT"):
    return Settings(
        nobitex_base_url="https://apiv2.nobitex.ir", nobitex_api_token=None,
        bale_bot_token=None, bale_chat_id=None,
        database_url="sqlite+aiosqlite:///:memory:", log_level="INFO",
        default_symbol=default_symbol, default_risk_profile="moderate",
        execution_mode="SPOT", scan_interval_seconds=300, alert_cooldown_seconds=1800,
        candle_count=500,
    )


def test_resolve_symbols_returns_enabled_watchlist():
    db = FakeDatabaseForScheduler(watchlist_symbols=["BTCUSDT", "ETHUSDT"])
    result = asyncio.run(_resolve_symbols(db, _settings()))
    assert result == ["BTCUSDT", "ETHUSDT"]


def test_resolve_symbols_falls_back_to_default_when_watchlist_empty():
    db = FakeDatabaseForScheduler(watchlist_symbols=[])
    result = asyncio.run(_resolve_symbols(db, _settings(default_symbol="ETHIRT")))
    assert result == ["ETHIRT"]


def _extract_scan_job(scheduler):
    """The offline apscheduler shim's add_job just records (func, trigger,
    kwargs) -- pull the registered coroutine function back out so it can
    be invoked directly in a test, without needing a real scheduler loop."""
    func, _trigger, _kwargs = scheduler._jobs[0]
    return func


def test_scan_job_skips_entirely_when_monitoring_paused():
    db = FakeDatabaseForScheduler(watchlist_symbols=["BTCUSDT"])
    monitoring = MonitoringController(initially_active=False)  # paused
    scheduler = build_scheduler(
        _settings(), get_scoring_config(), client=object(), db=db, bale=None,
        monitoring_controller=monitoring,
    )
    scan_job = _extract_scan_job(scheduler)

    asyncio.run(scan_job())

    # Paused means the job must return before touching the watchlist at all.
    assert db.get_watchlist_calls == 0


def test_scan_job_records_error_on_analysis_failure_without_crashing():
    db = FakeDatabaseForScheduler(watchlist_symbols=["BTCUSDT"])
    monitoring = MonitoringController(initially_active=True)
    health = HealthService()
    # `client=object()` has none of NobitexClient's methods, so
    # run_dual_analysis will raise inside the job -- verifying the job
    # catches it, records a scan_errors counter, and reports failure via
    # HealthService rather than crashing the scheduler.
    scheduler = build_scheduler(
        _settings(), get_scoring_config(), client=object(), db=db, bale=None,
        monitoring_controller=monitoring, health=health,
    )
    scan_job = _extract_scan_job(scheduler)

    asyncio.run(scan_job())  # must not raise

    assert "scan_errors" in [c[0] for c in db.increment_calls]
    assert health.last_error is not None
    assert health.last_scan_time is not None
