from __future__ import annotations

from app.watchlist.logic import (
    WatchlistItem,
    filter_by_market_type,
    infer_market_type,
    reorder,
    search_symbols,
    sort_watchlist,
    validate_symbol_format,
)

_AVAILABLE = [
    {"symbol": "BTCIRT", "base": "BTC", "quote": "IRT", "market_type": "RIAL"},
    {"symbol": "BTCUSDT", "base": "BTC", "quote": "USDT", "market_type": "TETHER"},
    {"symbol": "ETHIRT", "base": "ETH", "quote": "IRT", "market_type": "RIAL"},
    {"symbol": "ETHUSDT", "base": "ETH", "quote": "USDT", "market_type": "TETHER"},
]


def test_validate_symbol_format_accepts_valid_symbols():
    assert validate_symbol_format("BTCIRT")
    assert validate_symbol_format("ETHUSDT")


def test_validate_symbol_format_rejects_invalid():
    assert not validate_symbol_format("btcirt")  # lowercase
    assert not validate_symbol_format("BTC/IRT")  # slash
    assert not validate_symbol_format("")
    assert not validate_symbol_format("XYZ")  # no recognized quote


def test_infer_market_type():
    assert infer_market_type("BTCUSDT") == "TETHER"
    assert infer_market_type("BTCIRT") == "RIAL"
    assert infer_market_type("UNKNOWN") is None


def test_search_symbols_matches_symbol_or_base():
    result = search_symbols(_AVAILABLE, "btc")
    symbols = {s["symbol"] for s in result}
    assert symbols == {"BTCIRT", "BTCUSDT"}


def test_search_symbols_empty_query_returns_all():
    assert search_symbols(_AVAILABLE, "") == _AVAILABLE


def test_search_symbols_no_match_returns_empty():
    assert search_symbols(_AVAILABLE, "DOGE") == []


def test_filter_by_market_type():
    rial = filter_by_market_type(_AVAILABLE, "RIAL")
    assert all(s["market_type"] == "RIAL" for s in rial)
    assert len(rial) == 2


def test_filter_by_invalid_market_type_returns_all():
    assert filter_by_market_type(_AVAILABLE, "GOLD") == _AVAILABLE


def test_sort_watchlist_orders_by_display_order():
    items = [
        WatchlistItem("ETHIRT", "RIAL", True, 2),
        WatchlistItem("BTCIRT", "RIAL", True, 0),
        WatchlistItem("BTCUSDT", "TETHER", True, 1),
    ]
    sorted_items = sort_watchlist(items)
    assert [i.symbol for i in sorted_items] == ["BTCIRT", "BTCUSDT", "ETHIRT"]


def test_reorder_applies_new_order():
    current = [
        WatchlistItem("BTCIRT", "RIAL", True, 0),
        WatchlistItem("ETHIRT", "RIAL", True, 1),
        WatchlistItem("BTCUSDT", "TETHER", True, 2),
    ]
    result = reorder(["BTCUSDT", "BTCIRT", "ETHIRT"], current)
    assert [i.symbol for i in result] == ["BTCUSDT", "BTCIRT", "ETHIRT"]
    assert [i.display_order for i in result] == [0, 1, 2]


def test_reorder_preserves_omitted_symbols_at_end():
    current = [
        WatchlistItem("BTCIRT", "RIAL", True, 0),
        WatchlistItem("ETHIRT", "RIAL", True, 1),
    ]
    # Caller only supplied one symbol -- ETHIRT must not be dropped.
    result = reorder(["ETHIRT"], current)
    assert [i.symbol for i in result] == ["ETHIRT", "BTCIRT"]
