from __future__ import annotations

import re

from app.monitoring.health_service import HealthService, ServiceHealth, build_status_snapshot
from app.monitoring.status_formatter import format_status_text

_ENGLISH_PROSE_RE = re.compile(r"[A-Za-z]+(?:\s+[A-Za-z]+){3,}")


def _snapshot(**overrides):
    health = HealthService()
    health.set_monitoring_active(overrides.pop("monitoring_active", True))
    if overrides.pop("scan_succeeded", True):
        health.record_scan_success()
    defaults = dict(
        nobitex=ServiceHealth(True), bale=ServiceHealth(True), database=ServiceHealth(True),
        enabled_symbol_count=5, scan_interval_seconds=300, timeframes=("4H", "1H", "15M", "5M"),
        alerts_today=1, analyses_today=10,
    )
    defaults.update(overrides)
    return build_status_snapshot(health, **defaults)


def test_healthy_snapshot_is_not_degraded():
    snap = _snapshot()
    assert snap.degraded is False


def test_snapshot_degraded_when_nobitex_down():
    snap = _snapshot(nobitex=ServiceHealth(False, "no connection"))
    assert snap.degraded is True


def test_health_service_tracks_monitoring_toggle():
    h = HealthService()
    assert h.is_monitoring_active() is False
    h.set_monitoring_active(True)
    assert h.is_monitoring_active() is True


def test_health_service_records_scan_success_and_failure():
    h = HealthService()
    h.record_scan_success()
    assert h.last_error is None
    assert h.last_scan_time is not None

    h.record_scan_failure("connection timeout")
    assert h.last_error == "connection timeout"


def test_next_scan_time_offsets_by_interval():
    h = HealthService()
    h.record_scan_success()
    next_time = h.next_scan_time(300)
    assert next_time is not None
    assert (next_time - h.last_scan_time).total_seconds() == 300


def test_format_status_text_has_no_english_prose():
    snap = _snapshot()
    text = format_status_text(snap)
    assert _ENGLISH_PROSE_RE.findall(text) == []


def test_format_status_text_shows_degraded_block_when_unhealthy():
    snap = _snapshot(nobitex=ServiceHealth(False))
    text = format_status_text(snap)
    assert "\u0648\u0636\u0639\u06cc\u062a \u0633\u06cc\u0633\u062a\u0645" in text  # "وضعیت سیستم" degraded header


def test_format_status_text_omits_degraded_block_when_healthy():
    snap = _snapshot()
    text = format_status_text(snap)
    assert "\u0648\u0636\u0639\u06cc\u062a \u0633\u06cc\u0633\u062a\u0645" not in text
