from __future__ import annotations

from app.data.nobitex.client import _parse_pair_key


def test_parses_rial_pair():
    result = _parse_pair_key("btc-rls")
    assert result == {"symbol": "BTCIRT", "base": "BTC", "quote": "IRT", "market_type": "RIAL"}


def test_parses_irr_alias_as_rial():
    result = _parse_pair_key("eth-irr")
    assert result["market_type"] == "RIAL"
    assert result["symbol"] == "ETHIRT"


def test_parses_tether_pair():
    result = _parse_pair_key("eth-usdt")
    assert result == {"symbol": "ETHUSDT", "base": "ETH", "quote": "USDT", "market_type": "TETHER"}


def test_uppercases_base_currency():
    result = _parse_pair_key("doge-usdt")
    assert result["base"] == "DOGE"
    assert result["symbol"] == "DOGEUSDT"


def test_unknown_quote_currency_returns_none():
    assert _parse_pair_key("btc-eur") is None


def test_malformed_key_without_separator_returns_none():
    assert _parse_pair_key("btcusdt") is None


def test_empty_string_returns_none():
    assert _parse_pair_key("") is None


def test_missing_base_or_quote_returns_none():
    assert _parse_pair_key("-usdt") is None
    assert _parse_pair_key("btc-") is None
