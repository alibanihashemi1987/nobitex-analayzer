from __future__ import annotations

from datetime import UTC, datetime, timedelta

from app.domain.enums import CandleState
from app.domain.models import Candle


def make_candle(
    i: int,
    open_: float,
    high: float,
    low: float,
    close: float,
    volume: float = 100.0,
    symbol: str = "BTCIRT",
    timeframe: str = "1H",
    state: CandleState = CandleState.CLOSED,
) -> Candle:
    base = datetime(2026, 1, 1, tzinfo=UTC)
    return Candle(
        symbol=symbol,
        timeframe=timeframe,
        open_time=base + timedelta(hours=i),
        close_time=base + timedelta(hours=i + 1),
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=volume,
        state=state,
    )


def make_series(ohlcs: list[tuple[float, float, float, float]], **kwargs) -> list[Candle]:
    return [make_candle(i, *ohlc, **kwargs) for i, ohlc in enumerate(ohlcs)]


def uptrend_candles(n: int = 60, start: float = 100.0, step: float = 1.0) -> list[Candle]:
    ohlcs = []
    price = start
    for _ in range(n):
        o = price
        c = price + step
        h = c + 0.5
        low = o - 0.5
        ohlcs.append((o, h, low, c))
        price = c
    return make_series(ohlcs)
