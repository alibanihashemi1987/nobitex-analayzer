# Nobitex Dual-Side LONG/SHORT Market Analysis Agent

A deterministic, non-repainting, dual-direction (LONG **and** SHORT,
evaluated independently every cycle) market-structure and ICT/SMC
analysis agent for Nobitex markets. Produces a fully auditable
100-point confluence score per direction, risk-managed setups
(Entry/SL/TP1-3), a BUY/SELL/WAIT/CONFLICT final decision, performance
tracking, and Bale Messenger alerts.

This is a **dual-side market analysis engine, not a buy-signal
generator** — see `STRATEGY.md` and the three specs it implements
(`MANDATORY_ARCHITECTURE_CHANGE.md`, `ADDITIONAL_ARCHITECTURE_REQUIREMENTS.md`,
`REPLACEMENT_MODULE.md`, bundled at the repo root for reference).

Alerts and reports go out in Persian over Bale (`REPORTING.md`), and the
agent now ships a Persian RTL Setup Wizard, Dashboard, and Bale Control
Center — see `SETUP_AND_UI.md`.

## Quickstart

**macOS, no command-line knowledge needed:** double-click
`Install_and_Run.command` in the project folder — it installs
everything and opens the Setup Wizard in your browser automatically.
See `MAC_INSTALL_GUIDE_FA.md` (Persian, step-by-step) for the first-run
Gatekeeper security prompt and what to expect.

**Manual / any OS:**

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest                 # run the full test suite
python main.py          # first run: opens the Setup Wizard at
                         # http://127.0.0.1:8765 -- no .env editing needed;
                         # subsequent runs: starts the 24/7 scheduler directly
python main.py analyze BTCIRT   # one-off manual dual-direction analysis
```

No `.env` file is required for a normal first run — the Setup Wizard
collects Nobitex/Bale credentials and trading configuration through the
browser and stores them securely (`SETUP_AND_UI.md` section 1). `.env`
(see `.env.example`) remains available as a power-user/headless-Docker
override that bypasses the wizard entirely when both Nobitex and Bale
credentials are set there.

Or with Docker:

```bash
docker compose up --build -d
# then open http://127.0.0.1:8765 to complete the Setup Wizard
```

## Project layout

```
app/
  config/       settings.py (operational config) + scoring_config.yaml/.py
                (every STRATEGY numeric constant — weights, thresholds,
                timeframe-role mapping — see CONFIGURATION.md)
  core/         logging, exception hierarchy
  domain/
    models.py     dataclass models for candles/detector outputs (dependency-free)
    enums.py      every StrEnum used across the engine
    events.py     ScoreFactor / ScoreBreakdown / EventRegistry (auditability)
    context.py    MarketContext + build_market_context() (single-snapshot cache)
    directional.py  DirectionalAnalysis / MarketAnalysisResult
  data/         Nobitex API client, closed-candle & timeframe helpers
  indicators/   MA20/MA200(+slope), RSI14, MFI10, ATR14, swings, divergence
  strategy/
    smc/          BOS / CHoCH structure engine
    ict/           FVG, Order Block, Breaker Block, Mitigation Block, Volume Imbalance
    liquidity/     Liquidity sweeps, Turtle Soup
    fibonacci/     OTE zone, Premium/Discount (with Equilibrium Buffer)
    scoring/       the 8-category (A-H) deterministic confluence engine,
                   Hard Gates, Primary POI selection, HTF alignment,
                   Market Risk classification
    directional/   evaluate_long, evaluate_short, resolve_final_decision
  risk/          Entry/SL/TP1-3 + R:R calculation
  orderbook/     order-book wall & liquidity-proximity analysis
  database/      SQLite persistence (AnalysisRecord for every cycle,
                 SignalRecord for taken trades + outcomes)
  tracking/      signal outcome evaluation & performance reports
  charts/        candlestick chart rendering with Entry/SL/TP overlays
  notifications/bale/  Bale Messenger bot client (send_message/send_photo
                 support an optional inline-keyboard reply_markup)
  reporting/     Persian Bale report generation (Summary + Detailed),
                 localization, formatting, inline-keyboard callback,
                 and the Bale Agent Control Center router -- see
                 REPORTING.md and SETUP_AND_UI.md. Presentation-only,
                 never touches the scoring/decision engine.
  security/      CredentialStore (OS keyring + encrypted-file fallback)
                 and CredentialManager -- see SETUP_AND_UI.md section 1.
  watchlist/     dynamic symbol discovery + persistent watchlist CRUD
  monitoring/    HealthService, status snapshot, Persian status formatting
  runtime/       MonitoringController (thread-safe pause/resume) and
                 the shared RuntimeConfigAccessor
  web/           Flask Persian RTL web UI: Setup Wizard, Dashboard,
                 Settings, Live Analysis, Report History, JSON API --
                 see SETUP_AND_UI.md
  scheduler/     24/7 periodic dual-direction market scan
  services/
    analysis_service.py   live orchestration (the only network I/O)
    backtest_service.py   dual-direction historical backtester
    signal_service.py     Persian Bale reports, persistence, alerts
    replay_service.py     lookahead-bias regression harness (detector level)
tests/unit/     dependency-free unit tests for every pure-logic module
scripts/run_tests_offline.py   runs tests/unit without requiring pytest
```

## Design principles

1. **Dual-side, never single-hypothesis.** LONG and SHORT are evaluated
   completely independently every cycle; `WAIT` means neither qualified,
   not "LONG failed" (`MANDATORY_ARCHITECTURE_CHANGE.md`).
2. **One immutable snapshot per cycle.** `MarketContext` is computed
   once and shared, read-only, by both evaluators — no duplicate
   calculation, no risk of LONG and SHORT seeing different data
   (`ADDITIONAL_ARCHITECTURE_REQUIREMENTS.md`).
3. **No lookahead bias.** Every indicator/detector is a pure function of
   the CLOSED candles passed to it; `only_closed()` is the one chokepoint
   that filters out the forming candle. The backtester rebuilds the
   context from `candles[:i]` at every historical step.
4. **Deterministic, centralized, auditable scoring.** The 100-point
   confluence score is split into 8 fixed-max categories with no hidden
   or invented points; every awarded point traces to a `ScoreFactor`
   with human-readable evidence (`REPLACEMENT_MODULE.md`).
5. **Technical validity ≠ execution eligibility.** A technically READY
   SHORT under SPOT mode is still fully reported — never hidden — even
   though the final decision is WAIT because SPOT can't execute it.
6. **Everything is typed.** Detectors and the scoring engine return
   dataclasses, never raw dicts. The entire non-I/O core
   (`app/domain`, `app/indicators`, `app/strategy`) is dependency-free
   (stdlib `dataclasses` only) so it's testable without installing
   anything.
7. **Fail loud, not silent.** Malformed API responses, invalid setups,
   and missing config all raise typed exceptions
   (`app/core/exceptions.py`) rather than producing silently wrong output.

## Known limitations / what's left for a networked environment

This was built in a sandboxed environment with **no internet access**,
so the following could not be exercised against the real world:

- Live Nobitex API response shapes (`/market/udf/history`,
  `/v2/orderbook/{symbol}`, and now the market-symbol-discovery endpoint
  used by `fetch_all_market_symbols`) — re-verify field names against
  current API docs before going live.
- Live Bale Bot API calls (`sendMessage` / `sendPhoto`).
- The dependency-heavy infra modules (`httpx`, `sqlalchemy`, `tenacity`,
  `structlog`, `apscheduler`, `mplfinance`) were exercised through
  lightweight offline stand-ins (`scripts/offline_shims/`), not the real
  packages — `Flask` and `cryptography`, by contrast, ARE genuinely
  installed in this environment, so the web UI and credential storage
  were tested for real, including against a real background asyncio
  event loop thread. `scripts/run_tests_offline.py` runs all 160 tests
  this way; see TESTING.md for exactly what's real vs. stood-in.
- Multi-timeframe backtesting currently uses one candle series for all
  four timeframe roles (see STRATEGY.md's "Known limitations").
- Database migrations beyond `Base.metadata.create_all` (no Alembic
  migration history yet — see `migrations/`).
- No inbound Bale webhook/long-polling server (see REPORTING.md and
  SETUP_AND_UI.md section 4) — the Bale Control Center's command
  routing/handler logic is complete and tested, but nothing currently
  calls it from a real incoming Bale update.
- **The web UI has no authentication** — see SETUP_AND_UI.md's security
  note before binding it to anything other than loopback.
- Nobitex's real auth model (single bearer token vs. the spec's "API
  Key + API Secret" pair) — see SETUP_AND_UI.md section 5.

See `DEPLOYMENT.md` for the pre-launch verification checklist.
