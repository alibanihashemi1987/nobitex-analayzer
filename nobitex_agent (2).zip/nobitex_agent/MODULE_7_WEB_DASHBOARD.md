# MODULE 7: PERSIAN RTL WEB DASHBOARD & USER INTERFACE LAYER

## OBJECTIVE

Extend the existing Nobitex AI Trading Analytics Agent by adding a complete Persian RTL Web Dashboard layer.

The Web Dashboard must not replace or modify the existing Trading Engine, Analysis Engine, Scoring Engine, Risk Manager, Database Layer, or Bale Notification System.

The goal is to provide a professional user interface for controlling, monitoring, configuring, and reviewing the Agent through a browser.

The final architecture must become:

```text
                    User Browser
                         |
          Persian RTL Web Dashboard
                         |
                    FastAPI Backend
                         |
        ---------------------------------
        |              |                |
 Trading Engine   SQLite Database   Bale Bot
        |
     Nobitex API
```

---

# 1. TECHNOLOGY REQUIREMENTS

## Backend

Use:

- FastAPI
- Python 3.12+
- Existing project services must be reused
- REST API architecture
- Async endpoints where required

The dashboard must communicate with the existing Agent core without duplicating analysis logic.

## Frontend

Use:

- React
- TypeScript
- Tailwind CSS
- Native RTL support
- Persian language interface
- Responsive design

The UI must work correctly on:

- Desktop
- Tablet
- Mobile browser

---

# 2. LANGUAGE & RTL REQUIREMENTS

The entire dashboard interface must be Persian RTL.

Requirements:

- Right-to-left layout
- Persian fonts
- Persian date formatting
- Persian labels
- Persian error messages
- Persian notifications
- Persian navigation and menus

Example:

Instead of:

`Market Scanner Running`

Display:

`اسکنر بازار فعال است`

No user-facing English UI text should remain unless it is an unavoidable technical identifier such as a symbol, API field, or code-level diagnostic.

---

# 3. MAIN DASHBOARD PAGE

Create a main monitoring dashboard.

Display:

## Agent Status

Example:

```text
وضعیت Agent:

🟢 فعال

آخرین اسکن:
13:45:20

تعداد نمادهای فعال:
25
```

## System Connections

Show:

```text
اتصالات:

نوبیتکس:
🟢 متصل

بله:
🟢 متصل

پایگاه داده:
🟢 فعال
```

## Market Overview

Display:

- Total scanned symbols
- Active alerts
- Last analysis time
- Current market bias

Example:

```text
وضعیت کلی بازار:

BTC:
نزولی

ETH:
خنثی

SOL:
صعودی
```

---

# 4. SYMBOL WATCHLIST MANAGEMENT

Create a complete symbol management module.

The user must be able to:

- Fetch all available Nobitex symbols
- Search symbols
- Add/remove symbols
- Create and edit custom watchlists
- Enable/disable symbols for automatic scanning
- Separate Rial and Tether markets
- Display Commitment Trading symbols where supported

Support:

## Rial Markets

Example:

```text
BTC/IRT
ETH/IRT
```

## Tether Markets

Example:

```text
BTC/USDT
ETH/USDT
```

## Commitment Trading

Support separate Long and Short analysis where the underlying Nobitex market/API supports it.

Example UI:

```text
لیست منتخب تحلیل:

☑ BTC/IRT
☑ BTC/USDT
☑ ETH/IRT
☐ DOGE/USDT

[افزودن]
[حذف]
[ویرایش]
```

The watchlist must persist in the database and survive application restarts.

---

# 5. ANALYSIS REPORT INTERFACE

Reports must be divided into two levels.

## Level 1: Summary Report

The summary report is the default view.

It must show both LONG and SHORT evaluation independently.

Example:

```text
BTC/USDT

روند:
🔴 نزولی

بررسی LONG:
WAIT
امتیاز: 62/100

بررسی SHORT:
WAIT
امتیاز: 74/100

نتیجه نهایی:
منتظر تأیید ورود
```

The report must never imply that only one direction was evaluated.

If the final Resolver result is WAIT, the report must clearly show:

- LONG was evaluated
- SHORT was evaluated
- Why LONG is WAIT
- Why SHORT is WAIT
- What condition would activate either direction

## Level 2: Detailed Report

The detailed report is displayed only when requested by the user.

Include:

- Market structure
- Multi-timeframe analysis
- MA20
- MA200
- RSI14
- MFI10
- ICT/SMC zones
- POI detection
- Premium/Discount analysis
- Liquidity
- Order Book analysis
- LONG scoring breakdown
- SHORT scoring breakdown
- Resolver decision
- Risk calculation
- Entry
- Stop Loss
- TP1
- TP2
- TP3
- Risk-to-Reward ratios
- Execution eligibility
- WAIT reasons

---

# 6. LIVE ANALYSIS PAGE

Create a dedicated analysis page.

Display:

## Market Structure

Example:

```text
4H:
نزولی

1H:
نزولی

15M:
خنثی
```

## Direction Evaluation

Both directions must always be visible.

Example:

```text
بررسی LONG:

امتیاز:
58/100

وضعیت:
WAIT


بررسی SHORT:

امتیاز:
81/100

وضعیت:
READY
```

The UI must distinguish between:

- READY
- WAIT
- CONFLICT
- NOT READY
- NOT EXECUTABLE

Do not collapse technical unavailability and analytical weakness into the same status.

---

# 7. CHART VISUALIZATION

Integrate interactive chart display.

Charts must support:

- Candlestick chart
- Multiple timeframes
- FVG zones
- Order Blocks
- Breaker Blocks
- Mitigation Blocks
- Liquidity zones
- Swing High / Swing Low
- Entry line
- Stop Loss
- Take Profit levels
- Premium / Discount zones

Prefer:

- TradingView Lightweight Charts

If the existing project already generates mplfinance charts, preserve that functionality and expose the generated charts in the dashboard as an additional option.

---

# 8. SETTINGS PANEL

Create graphical configuration management.

The user must be able to manage settings without manually editing `.env` for normal configuration tasks.

## API Settings

Fields:

```text
Nobitex API Key

Bale Bot Token

Bale Chat ID
```

Secrets must be masked in the UI.

Provide:

```text
[ذخیره]
[آزمون اتصال]
```

## Risk Profile

Options:

```text
محافظه‌کارانه

متعادل

تهاجمی
```

## Scanner Settings

Example:

```text
فاصله اسکن:

5 دقیقه

15 دقیقه

1 ساعت
```

## Timeframe Selection

Example:

```text
☑ 4H
☑ 1H
☑ 15M
☑ 5M
```

---

# 9. REPORT HISTORY

Create historical report management.

Store and display:

- Symbol
- Direction
- LONG score
- SHORT score
- Final decision
- Entry
- SL
- TP1
- TP2
- TP3
- Result
- Date
- Time
- Timeframes
- Risk profile

Example:

```text
BTC/USDT

SHORT

امتیاز:
86

نتیجه:
TP1 فعال شد ✅
```

Allow filtering by:

- Symbol
- Date
- Direction
- Final status
- Result

---

# 10. DATABASE EXTENSION

Extend SQLite schema only if required by the existing architecture.

Add or extend tables for:

## user_settings

Store:

- User preferences
- Selected symbols
- Watchlists
- Risk profile
- Dashboard settings
- Scanner settings

## analysis_reports

Store:

- Symbol
- Summary report
- Detailed report
- LONG analysis
- SHORT analysis
- Final Resolver decision
- Timestamp

Do not create duplicate storage mechanisms if equivalent existing models already exist.

---

# 11. BALE INTEGRATION

The dashboard must expose Bale integration status.

Display:

```text
وضعیت بله:
🟢 متصل
```

Provide a button:

```text
[ارسال پیام آزمایشی]
```

The test must send a safe test message to the configured Bale destination.

The dashboard must also show recent notification events and failures.

Do not alter the existing Bale notification logic unless required to expose it through the dashboard.

---

# 12. AGENT CONTROL

Provide dashboard controls for:

```text
🟢 شروع پایش

⏸ توقف پایش

🔄 اجرای اسکن فوری

📊 تحلیل فوری نماد
```

The user must be able to manually trigger an analysis without stopping the automatic scanner.

The automatic scanner must continue independently when enabled.

---

# 13. REAL-TIME STATUS

The dashboard should show the Agent's current state:

```text
🟢 در حال پایش

آخرین اسکن:
13:45:20

اسکن بعدی:
13:50:00
```

If the Agent encounters an error:

```text
🔴 خطا

ارتباط با نوبیتکس قطع شده است.
```

The UI must not falsely report the Agent as running when the scanner process has actually stopped.

---

# 14. RESPONSIVE DESIGN

The dashboard must be fully responsive.

Desktop:

- Sidebar navigation
- Multi-column dashboard
- Large charts

Tablet:

- Collapsible sidebar
- Responsive cards

Mobile:

- Bottom or collapsible navigation
- Stacked cards
- Horizontally scrollable data tables where necessary
- Touch-friendly controls

---

# 15. PERSIAN UX DESIGN

The interface should feel like a professional Persian financial/trading terminal.

Use:

- Clean typography
- Clear hierarchy
- Compact information cards
- Professional tables
- Clear status badges
- Consistent iconography
- Proper Persian number formatting where appropriate

Do not use excessive decorative elements.

Prioritize readability and operational clarity.

---

# 16. SECURITY REQUIREMENTS

Implement:

- Secure API credential storage
- Environment variable compatibility
- Session management where authentication is required
- Input validation
- CSRF protection where applicable
- Secure secret handling

Never expose:

- API keys
- Bale tokens
- Private credentials

Never place secrets in frontend source code.

---

# 17. BACKWARD COMPATIBILITY

The new Web Dashboard must:

- Work with the existing Agent
- Not replace the Trading Engine
- Not modify trading logic unnecessarily
- Not duplicate scoring calculations
- Not duplicate indicator calculations
- Reuse existing services
- Reuse existing Pydantic/domain models where possible
- Maintain Bale Bot functionality
- Maintain CLI functionality
- Maintain automatic background scanning
- Maintain existing database behavior

The Agent must continue working without the dashboard.

The dashboard is a presentation, configuration, monitoring, and control layer.

---

# 18. API ARCHITECTURE

Create clean API endpoints for the dashboard.

At minimum support:

```text
GET    /api/status
GET    /api/symbols
GET    /api/watchlist
POST   /api/watchlist
PUT    /api/watchlist/{symbol}
DELETE /api/watchlist/{symbol}

GET    /api/analysis/{symbol}
POST   /api/analysis/{symbol}/run

GET    /api/reports
GET    /api/reports/{id}

GET    /api/settings
PUT    /api/settings

POST   /api/bale/test

POST   /api/scanner/start
POST   /api/scanner/stop
POST   /api/scanner/scan-now
```

Adapt endpoint names to the existing architecture if equivalent routes already exist.

Do not create duplicate endpoints unnecessarily.

---

# 19. FRONTEND ROUTES

Create logical frontend routes such as:

```text
/
    داشبورد

/analysis
    تحلیل بازار

/symbols
    نمادها و لیست منتخب

/reports
    تاریخچه گزارش‌ها

/settings
    تنظیمات

/system
    وضعیت سیستم
```

All visible route labels must be Persian.

---

# 20. ERROR HANDLING

Errors must be translated into understandable Persian UI messages.

Example:

Technical error:

```text
ConnectionError
```

User-facing message:

```text
ارتباط با نوبیتکس برقرار نشد.
لطفاً اتصال اینترنت و تنظیمات API را بررسی کنید.
```

Technical details may remain available in a developer diagnostics section.

---

# 21. DEVELOPMENT MODE

Provide a local development command.

The final project should support running:

```bash
python main.py
```

for the existing Agent where currently supported.

And a Web Dashboard development/start command such as:

```bash
uvicorn app.web.main:app --reload
```

or the project's equivalent architecture.

The exact command must be documented in the project README.

---

# 22. PRODUCTION DEPLOYMENT

The Web Dashboard must support:

## Local macOS / Windows / Linux

The user can run the Agent and dashboard locally.

## Linux VPS / Docker

The same codebase must support:

- Agent
- FastAPI
- Frontend
- SQLite or PostgreSQL where configured
- Bale Bot
- Nobitex API

without requiring architectural rewrites.

Update Docker configuration only where necessary.

---

# 23. IMPLEMENTATION RULE

IMPORTANT:

Do not rewrite the existing project from scratch.

Before implementation:

1. Inspect the existing project structure.
2. Identify the current Trading Engine.
3. Identify the existing Analysis Engine.
4. Identify the current Scoring Engine.
5. Identify the existing Risk Manager.
6. Identify the current Bale client.
7. Identify existing Pydantic/domain models.
8. Identify existing database models.
9. Identify existing configuration management.
10. Reuse existing components.

Then implement the Web Dashboard as an additional application layer.

---

# 24. ACCEPTANCE CRITERIA

The implementation is considered complete only when:

- The Web Dashboard opens successfully in a browser.
- The complete UI is Persian and RTL.
- Existing Agent scanning still works.
- Existing Bale notifications still work.
- Nobitex connectivity is displayed.
- Bale connectivity can be tested from the UI.
- User can view all available symbols.
- User can create and edit a selected/watchlist.
- User can enable/disable symbols for scanning.
- User can view both LONG and SHORT analysis.
- User can view summary reports.
- User can request detailed reports.
- User can view historical reports.
- User can configure risk profile.
- User can configure timeframes.
- User can start/stop monitoring.
- User can trigger an immediate scan.
- Charts are visible in the dashboard.
- API credentials are not exposed.
- The dashboard does not duplicate trading calculations.
- The existing CLI/Agent remains functional.
- Local execution works.
- Docker/VPS deployment remains possible.

---

# FINAL PRODUCT

The final product must become a Persian RTL AI Trading Terminal for Nobitex.

It must provide:

✅ Automated market scanning  
✅ ICT/SMC analysis  
✅ Independent LONG/SHORT evaluation  
✅ Structured scoring  
✅ Risk management  
✅ Bale alerts  
✅ Persian RTL Web Dashboard  
✅ Symbol and watchlist management  
✅ Real-time monitoring  
✅ Summary and detailed reports  
✅ Report history  
✅ Interactive charts  
✅ Configuration management  
✅ Agent control  
✅ Connection monitoring  
✅ Local execution  
✅ VPS/Docker deployment

The Web Dashboard is an additional control and visualization layer above the existing Trading Agent.

Do not remove or weaken the existing analytical functionality while implementing this module.
