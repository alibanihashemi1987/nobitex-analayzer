# ADDITIONAL MODULE: FIRST-RUN SETUP & CREDENTIAL MANAGEMENT

Extend the existing application with a proper First-Run Setup Wizard.

Do NOT redesign or rewrite the existing trading engine. Integrate this module into the current architecture.

## 1. FIRST-RUN DETECTION

On application startup:

- Detect whether the application has already been configured.
- If not configured, launch the First-Run Setup Wizard.
- If already configured, skip the wizard and start the normal application.
- The user must NOT be required to enter API credentials through the terminal.

The terminal must only be used for:
- application startup
- logs
- debugging
- developer diagnostics

The normal user configuration flow must use the application's Persian RTL interface.

## 2. SETUP WIZARD

The wizard must be Persian and RTL.

Recommended steps:

### Step 1: Nobitex Connection

Fields:

- API Key
- API Secret

Provide:

- Test Connection
- Continue

If authentication fails, show a Persian error message without crashing.

### Step 2: Bale Connection

Field:

- Bale Bot Token

Provide:

- Test Connection
- Continue

### Step 3: Trading Configuration

Allow the user to configure:

- Trading mode:
  - SPOT
  - COMMITMENT

- Risk profile:
  - Conservative
  - Moderate
  - Aggressive

- Monitoring interval

- Enabled timeframes:
  - 4H
  - 1H
  - 15M
  - 5M

### Step 4: Symbol Selection

Load all supported Nobitex symbols dynamically.

The user must be able to create a personal watchlist.

The watchlist must support both:

- Rial pairs
- Tether pairs

Examples:

- BTC/IRT
- BTC/USDT
- ETH/IRT
- ETH/USDT

The user must be able to:

- search symbols
- add symbols
- remove symbols
- reorder symbols
- enable/disable symbols
- save the watchlist

The watchlist must be persisted.

### Step 5: Monitoring Configuration

Allow:

- Auto Monitoring ON/OFF
- Scheduled Reports ON/OFF
- Event Alerts ON/OFF
- Alert Cooldown
- Candle-close reports

## 3. SECURE CREDENTIAL STORAGE

Never store API credentials as plaintext in SQLite.

Use the operating system's secure credential mechanism where possible:

- macOS Keychain
- Windows Credential Manager / secure credential storage
- Linux Secret Service / Keyring

If an abstraction is required, implement a `CredentialStore` interface.

Example:

```python
class CredentialStore(Protocol):
    async def save(self, key: str, value: str) -> None:
        ...

    async def get(self, key: str) -> str | None:
        ...

    async def delete(self, key: str) -> None:
        ...
```

SQLite may store configuration metadata, but sensitive credentials must be stored securely.

## 4. RECONFIGURATION

The user must be able to modify credentials later from Settings.

Do not require deleting configuration files manually.

Provide:

- Change Nobitex credentials
- Change Bale token
- Test connection
- Reset configuration

## 5. STARTUP BEHAVIOR

After successful first-run configuration:

```text
Setup Wizard
     ↓
Validate configuration
     ↓
Save configuration
     ↓
Initialize services
     ↓
Start Auto Monitor if enabled
     ↓
Open Dashboard
```

On subsequent application launches:

```text
Application Start
     ↓
Load configuration
     ↓
Validate credentials
     ↓
Initialize services
     ↓
Start Monitor
```

Do not show the setup wizard again unless configuration is missing or the user explicitly requests reconfiguration.

## 6. ERROR HANDLING

Never expose raw Python exceptions to the user.

Convert technical errors into Persian user-facing messages.

Example:

```text
⚠️ اتصال به نوبیتکس برقرار نشد

احتمالاً API Key یا API Secret صحیح نیست.

[🔐 اصلاح تنظیمات]
[🔄 تلاش مجدد]
```

Keep the original exception in the application log for debugging.

## ACCEPTANCE CRITERIA

- No API credential input through terminal.
- First launch opens Persian RTL Setup Wizard.
- Credentials are securely stored.
- Subsequent launches skip setup.
- User can reconfigure credentials.
- Connection tests are available.
- Setup failure does not crash the application.
- Existing trading logic remains unchanged.