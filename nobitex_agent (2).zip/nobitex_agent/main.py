"""Nobitex Dual-Side LONG/SHORT Market Analysis Agent -- entrypoint.

Usage:
    python main.py                        # run 24/7: web UI (Setup Wizard /
                                            # Dashboard / Settings) + scheduler
    python main.py analyze SYMBOL          # one manual dual-direction analysis;
                                            # prints the English report and sends
                                            # the Persian Bale Summary Report
    python main.py report ANALYSIS_ID      # (re)send the Persian Detailed Report
                                            # for a previously-generated analysis_id

On first launch (no completed Setup Wizard yet), `python main.py` starts
the web UI immediately at http://127.0.0.1:8765 and waits there -- no
credential is ever requested through the terminal (FIRST-RUN_SETUP_&_
CREDENTIAL_MANAGEMENT section 1). Once the wizard is completed from a
browser, the scheduler starts automatically with no restart needed.
"""

from __future__ import annotations

import asyncio
import sys
import threading
from dataclasses import replace
from pathlib import Path

from app.config.scoring_config import get_scoring_config
from app.config.settings import get_settings
from app.core.logging import configure_logging, get_logger
from app.data.nobitex.client import NobitexClient
from app.database.db import Database
from app.domain.enums import ExecutionMode
from app.monitoring.health_service import HealthService
from app.notifications.bale.client import BaleClient
from app.runtime.monitoring_controller import MonitoringController
from app.scheduler.scheduler import build_scheduler
from app.security.credential_manager import CredentialManager
from app.services.analysis_service import run_dual_analysis
from app.services.signal_service import (
    format_market_analysis_report,
    handle_detailed_report_request,
    process_and_alert,
    send_summary_report,
)
from app.web.app_factory import create_app
from app.web.async_bridge import AsyncBridge

logger = get_logger(__name__)

_DATA_DIR = "./data"


def _ensure_data_dir() -> Path:
    """Create the data directory (SQLite DB, encrypted credential store,
    web UI secret key all live here) before anything tries to open a
    file inside it. Previously this was left to the install script's
    `mkdir -p data` step — if that step didn't run for any reason (a
    macOS folder-permission restriction on the project's location, e.g.
    inside ~/Documents, is one realistic cause), every subsequent file
    open failed with a bare `[Errno 2] No such file or directory` and no
    clear explanation. Doing it here, defensively, at the start of every
    entrypoint removes that dependency entirely."""
    path = Path(_DATA_DIR)
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(
            f"\n\u274C \u0627\u06cc\u062c\u0627\u062f \u067e\u0648\u0634\u0647 \u062f\u0627\u062f\u0647 "
            f"({path.resolve()}) \u0645\u0645\u06a9\u0646 \u0646\u0634\u062f.\n"
            "\u0627\u06af\u0631 \u067e\u0631\u0648\u0698\u0647 \u062f\u0627\u062e\u0644 \u067e\u0648\u0634\u0647 "
            "Documents \u06cc\u0627 Desktop \u0627\u0633\u062a\u060c \u0622\u0646 \u0631\u0627 \u0628\u0647 "
            "\u06cc\u06a9 \u067e\u0648\u0634\u0647 \u062f\u06cc\u06af\u0631 (\u0645\u062b\u0644\u0627\u064b "
            "\u0645\u0633\u062a\u0642\u06cc\u0645 \u062f\u0631 \u067e\u0648\u0634\u0647 \u062e\u0627\u0646\u06af\u06cc "
            "\u06a9\u0627\u0631\u0628\u0631\u06cc \u062e\u0648\u062f) \u0645\u0646\u062a\u0642\u0644 \u06a9\u0646\u06cc\u062f "
            "\u0648 \u062f\u0648\u0628\u0627\u0631\u0647 \u0627\u062c\u0631\u0627 \u06a9\u0646\u06cc\u062f.\n"
            f"\u062c\u0632\u0626\u06cc\u0627\u062a \u0641\u0646\u06cc: {exc}\n"
        )
        raise
    return path


async def run_manual_analysis(symbol: str) -> None:
    settings = get_settings()
    scoring_config = get_scoring_config()
    configure_logging(settings.log_level)
    _ensure_data_dir()
    db = Database(settings.database_url)
    await db.init_models()

    async with NobitexClient(settings.nobitex_base_url, settings.nobitex_api_token) as client:
        result = await run_dual_analysis(
            client, scoring_config, symbol,
            ExecutionMode(settings.execution_mode), settings.default_risk_profile,
            candle_count=settings.candle_count,
        )
        print(format_market_analysis_report(result))
        print(f"\nanalysis_id: {result.analysis_id}")

        bale = None
        if settings.bale_bot_token and settings.bale_chat_id:
            bale = BaleClient(settings.bale_bot_token, settings.bale_chat_id)
        try:
            # A user-requested analysis always gets a Bale Summary Report,
            # regardless of decision (BUY/SELL/WAIT/CONFLICT) -- unlike the
            # scheduler's cooldown-gated, BUY/SELL-only auto-alert.
            await send_summary_report(result, db, bale, settings.default_risk_profile)
            # process_and_alert additionally persists a tradeable Signal
            # and applies the cooldown when the decision is BUY/SELL; it's
            # a no-op duplicate-send-safe call for WAIT/CONFLICT (only
            # persists the AnalysisRecord again, which is idempotent by
            # analysis_id).
            await process_and_alert(
                result, db, bale, settings.alert_cooldown_seconds,
                timeframe=scoring_config.mtf_timeframes.execution,
                risk_profile=settings.default_risk_profile,
            )
        finally:
            if bale:
                await bale.aclose()

    await db.dispose()


async def run_detailed_report(analysis_id: str) -> None:
    """Manually trigger the Detailed Report for a previously-generated
    analysis_id -- mirrors what the Bale inline-keyboard callback (or a
    Persian "تحلیل کامل" text request) would do. Useful for testing the
    reporting pipeline without needing a live inbound Bale webhook."""
    settings = get_settings()
    configure_logging(settings.log_level)
    _ensure_data_dir()
    db = Database(settings.database_url)
    await db.init_models()

    bale = None
    if settings.bale_bot_token and settings.bale_chat_id:
        bale = BaleClient(settings.bale_bot_token, settings.bale_chat_id)
    try:
        report = await handle_detailed_report_request(analysis_id, db, bale, settings.default_risk_profile)
        print(report)
    finally:
        if bale:
            await bale.aclose()
        await db.dispose()


async def run_forever() -> None:
    """Startup sequence (FIRST-RUN_SETUP_&_CREDENTIAL_MANAGEMENT section 5):

        Load configuration -> start web UI (always, so Setup/Settings are
        reachable) -> if not configured, wait for the Setup Wizard to be
        completed via the browser -> build effective Nobitex/Bale clients
        from whatever credentials were saved -> start the scheduler.

    No credential is ever entered through the terminal; the only things
    printed here are the web UI's local URL and structured logs.
    """
    settings = get_settings()
    scoring_config = get_scoring_config()
    configure_logging(settings.log_level)
    _ensure_data_dir()

    db = Database(settings.database_url)
    await db.init_models()

    credential_manager = CredentialManager(data_dir=_DATA_DIR)
    monitoring_controller = MonitoringController(initially_active=False)
    health = HealthService()

    # The web UI runs on the SAME event loop as everything else (via
    # AsyncBridge), on its own thread -- see app/web/async_bridge.py's
    # docstring for why this is one Database instance, not two.
    loop = asyncio.get_running_loop()
    bridge = AsyncBridge(loop)
    web_app = create_app(
        bridge, db, credential_manager, monitoring_controller, health,
        settings.nobitex_base_url, scoring_config=scoring_config, data_dir=_DATA_DIR,
    )
    web_thread = threading.Thread(
        target=lambda: web_app.run(
            host=settings.web_ui_host, port=settings.web_ui_port, threaded=True, use_reloader=False
        ),
        daemon=True,
    )
    web_thread.start()
    web_ui_url = f"http://{settings.web_ui_host}:{settings.web_ui_port}"
    if settings.web_ui_host not in ("127.0.0.1", "localhost"):
        logger.warning(
            "web_ui_bound_non_loopback",
            host=settings.web_ui_host,
            detail=(
                "The web UI has no authentication. Binding to a non-loopback "
                "address exposes credential-configuration screens to anyone "
                "who can reach this host/port — ensure a firewall, VPN, or "
                "authenticating reverse proxy is in front of it."
            ),
        )
    logger.info("web_ui_started", url=web_ui_url)
    print(f"\n\U0001F310 \u0631\u0627\u0647\u200c\u0627\u0646\u062f\u0627\u0632\u06cc \u0648 \u062f\u0627\u0634\u0628\u0648\u0631\u062f \u062f\u0631: {web_ui_url}\n")

    # Auto-open the browser for a loopback-bound web UI, so a
    # non-technical user who just double-clicked a launcher script never
    # has to manually type a URL. Never done for a non-loopback host
    # (that's a server/Docker deployment with no local display anyway).
    # Wrapped defensively -- a headless environment with no display
    # server must never crash startup over this.
    if settings.web_ui_host in ("127.0.0.1", "localhost"):
        def _open_browser_soon() -> None:
            import time
            import webbrowser
            time.sleep(1.5)  # give the Flask thread a moment to start listening
            try:
                webbrowser.open(web_ui_url)
            except Exception:
                logger.info("browser_auto_open_skipped")
        threading.Thread(target=_open_browser_soon, daemon=True).start()

    runtime_cfg = await db.get_runtime_config()
    if not runtime_cfg.setup_completed:
        logger.info("waiting_for_first_run_setup", url=web_ui_url)
        while True:
            await asyncio.sleep(2)
            runtime_cfg = await db.get_runtime_config()
            if runtime_cfg.setup_completed:
                break
        logger.info("first_run_setup_completed")

    # Env-var credentials (Settings/.env) take priority as a power-user /
    # headless-Docker override; otherwise use whatever the Setup Wizard
    # saved via CredentialManager. Building the clients only AFTER setup
    # completes (rather than at process start) means the first run never
    # needs a restart to pick up freshly-entered credentials. A LATER
    # change of credentials via Settings while already running does
    # still require a restart to take effect -- a documented limitation,
    # see DEPLOYMENT.md.
    nobitex_token = settings.nobitex_api_token
    if not nobitex_token:
        nobitex_token, _ = await credential_manager.get_nobitex_credentials()

    bale_bot_token, bale_chat_id = settings.bale_bot_token, settings.bale_chat_id
    if not (bale_bot_token and bale_chat_id):
        bale_bot_token, bale_chat_id = await credential_manager.get_bale_credentials()

    client = NobitexClient(settings.nobitex_base_url, nobitex_token)
    bale = BaleClient(bale_bot_token, bale_chat_id) if (bale_bot_token and bale_chat_id) else None
    if bale is None:
        logger.warning("bale_not_configured", detail="Alerts will not be sent via Bale.")

    # RuntimeConfigRecord (settable from the web UI / Bale Control
    # Center) drives risk profile / execution mode / scan interval /
    # cooldown going forward -- the .env Settings values are only the
    # seed defaults RuntimeConfigRecord starts with.
    effective_settings = replace(
        settings,
        default_risk_profile=runtime_cfg.risk_profile,
        execution_mode=runtime_cfg.execution_mode,
        scan_interval_seconds=runtime_cfg.scan_interval_seconds,
        alert_cooldown_seconds=runtime_cfg.alert_cooldown_seconds,
    )

    if runtime_cfg.auto_monitoring_enabled:
        await monitoring_controller.start()

    logger.info(
        "starting_agent", execution_mode=effective_settings.execution_mode,
        risk_profile=effective_settings.default_risk_profile,
    )

    scheduler = build_scheduler(
        effective_settings, scoring_config, client, db, bale,
        symbols=None,  # dynamic: pulled from the enabled watchlist every cycle
        monitoring_controller=monitoring_controller, health=health,
    )
    scheduler.start()

    try:
        while True:
            await asyncio.sleep(3600)
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        scheduler.shutdown(wait=False)
        await client.aclose()
        if bale:
            await bale.aclose()
        await db.dispose()


def main() -> None:
    if len(sys.argv) >= 3 and sys.argv[1] == "analyze":
        asyncio.run(run_manual_analysis(sys.argv[2]))
    elif len(sys.argv) >= 3 and sys.argv[1] == "report":
        asyncio.run(run_detailed_report(sys.argv[2]))
    else:
        asyncio.run(run_forever())


if __name__ == "__main__":
    main()
