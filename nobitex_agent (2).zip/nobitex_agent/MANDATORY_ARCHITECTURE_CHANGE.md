# MANDATORY ARCHITECTURE CHANGE
# DUAL-SIDE LONG/SHORT ANALYSIS ENGINE

The existing decision architecture must be refactored so that LONG and SHORT are evaluated independently before any final trading decision is made.

The system must NEVER interpret:

```text
WAIT
```

as:

```text
LONG/BUY conditions failed
```

WAIT must mean:

```text
Neither the LONG scenario nor the SHORT scenario
currently satisfies all required execution conditions.
```

---

# 1. INDEPENDENT DIRECTIONAL ANALYSIS

For every analysis cycle and every backtest candle, the system MUST independently evaluate two complete scenarios:

```text
LONG SCENARIO
SHORT SCENARIO
```

Each scenario must have its own:

- Market Structure analysis
- POI analysis
- Liquidity analysis
- Momentum analysis
- Multi-Timeframe analysis
- Order Book analysis
- Premium/Discount analysis
- Execution Quality
- Hard Gates
- Confluence Score
- Market Risk
- Entry
- Stop Loss
- Take Profit levels
- Rejection reasons
- Final readiness state

The LONG evaluator must NEVER depend on the result of the SHORT evaluator.

The SHORT evaluator must NEVER depend on the result of the LONG evaluator.

---

# 2. REQUIRED INTERNAL DATA MODEL

Implement separate directional result models.

Example:

```python
class DirectionalAnalysis(BaseModel):
    direction: Literal["LONG", "SHORT"]

    score: float
    max_score: float = 100.0

    status: Literal[
        "READY",
        "NOT_READY",
        "INVALID"
    ]

    hard_gates_passed: bool

    hard_gate_results: list[HardGateResult]

    score_breakdown: ScoreBreakdown

    execution_quality: float

    market_risk: Literal[
        "LOW",
        "MEDIUM",
        "HIGH",
        "CRITICAL"
    ]

    primary_poi: Optional[POIEvent]

    entry: Optional[float]
    stop_loss: Optional[float]

    tp1: Optional[float]
    tp2: Optional[float]
    tp3: Optional[float]

    risk_reward_tp1: Optional[float]
    risk_reward_tp2: Optional[float]
    risk_reward_tp3: Optional[float]

    rejection_reasons: list[str]

    evidence: list[MarketEvent]
```

Then create a combined result:

```python
class MarketAnalysisResult(BaseModel):
    symbol: str
    timestamp: datetime

    long_analysis: DirectionalAnalysis
    short_analysis: DirectionalAnalysis

    final_decision: Literal[
        "BUY",
        "SELL",
        "WAIT",
        "CONFLICT"
    ]

    execution_mode: Literal[
        "SPOT",
        "COMMITMENT"
    ]

    final_reason: str
```

---

# 3. LONG EVALUATOR

Create a dedicated function:

```python
def evaluate_long(
    market_context: MarketContext,
    config: TradingConfig
) -> DirectionalAnalysis:
    ...
```

This function must evaluate:

```text
LONG Structure
LONG POI
LONG Liquidity
LONG Momentum
LONG MTF
LONG Order Book
LONG Premium/Discount
LONG Execution
LONG Risk
```

It must return a complete `DirectionalAnalysis`.

It must NEVER return a generic global WAIT.

It must explicitly state why the LONG scenario is READY or NOT_READY.

---

# 4. SHORT EVALUATOR

Create a separate function:

```python
def evaluate_short(
    market_context: MarketContext,
    config: TradingConfig
) -> DirectionalAnalysis:
    ...
```

This function must independently evaluate:

```text
SHORT Structure
SHORT POI
SHORT Liquidity
SHORT Momentum
SHORT MTF
SHORT Order Book
SHORT Premium/Discount
SHORT Execution
SHORT Risk
```

It must return a complete `DirectionalAnalysis`.

It must NEVER return a generic global WAIT.

It must explicitly state why the SHORT scenario is READY or NOT_READY.

---

# 5. FINAL DIRECTION RESOLVER

After both scenarios have been evaluated, run a separate resolver:

```python
def resolve_final_decision(
    long_analysis: DirectionalAnalysis,
    short_analysis: DirectionalAnalysis,
    execution_mode: ExecutionMode,
    config: TradingConfig
) -> FinalDecision:
    ...
```

The resolver must NOT perform the technical analysis itself.

Its only responsibility is to compare the two completed directional analyses and determine the final state.

---

# 6. FINAL DECISION LOGIC

## CASE A: LONG READY, SHORT NOT READY

Example:

```text
LONG  = 88/100 READY
SHORT = 64/100 NOT_READY
```

Result:

```text
BUY
```

provided that the selected execution mode allows LONG execution.

---

# 7. CASE B: SHORT READY, LONG NOT READY

Example:

```text
LONG  = 67/100 NOT_READY
SHORT = 91/100 READY
```

Result:

```text
SELL
```

provided that the selected execution mode allows SHORT execution.

---

# 8. CASE C: BOTH NOT READY

Example:

```text
LONG  = 72/100 NOT_READY
SHORT = 69/100 NOT_READY
```

Result:

```text
WAIT
```

The report MUST explicitly state:

```text
LONG was evaluated but did not qualify.
SHORT was evaluated but did not qualify.
No executable directional setup currently exists.
```

This is the ONLY situation in which WAIT should represent the absence of an executable setup.

---

# 9. CASE D: BOTH READY

Example:

```text
LONG  = 84/100 READY
SHORT = 82/100 READY
```

The system must NOT automatically select LONG simply because it is first.

The result must be:

```text
CONFLICT
```

unless the configured score difference is large enough to establish a clear directional winner.

Add:

```yaml
decision:
  minimum_directional_score_difference: 8
```

If:

```text
abs(long_score - short_score) < 8
```

and both are READY:

```text
CONFLICT
```

If the difference is >= 8:

```text
higher_score_direction = final direction
```

Example:

```text
LONG  = 93
SHORT = 78
Difference = 15
```

Result:

```text
BUY
```

---

# 10. CASE E: BOTH READY BUT OPPOSITE STRUCTURAL CONTEXT

If both scenarios technically pass their local conditions but the higher-level market structure creates a genuine directional conflict, the resolver must prefer:

```text
CONFLICT
```

over forcing a trade.

The system must prioritize structural clarity over score maximization.

---

# 11. SPOT VS COMMITMENT EXECUTION MODE

The execution mode MUST NOT change the underlying technical analysis.

The system must always evaluate both LONG and SHORT.

Execution mode is applied ONLY after the directional analysis is complete.

Supported modes:

```text
SPOT
COMMITMENT
```

---

# 12. SPOT MODE

In SPOT mode:

```text
LONG = executable
SHORT = technically analyzable but not executable
```

Therefore, if:

```text
LONG  = 72 NOT_READY
SHORT = 91 READY
```

the technical analysis must still report:

```text
SHORT: READY, 91/100
```

But the final execution decision becomes:

```text
WAIT
```

because SHORT cannot be executed in SPOT mode.

The report must explicitly distinguish:

```text
Technical Direction:
SHORT

Technical Status:
READY

Execution Availability:
NOT AVAILABLE IN SPOT MODE

Final Decision:
WAIT
```

Do NOT hide or discard the valid SHORT analysis.

---

# 13. COMMITMENT MODE

In COMMITMENT mode:

```text
LONG = executable
SHORT = executable
```

Therefore:

```text
LONG  = 74 NOT_READY
SHORT = 88 READY
```

results in:

```text
SELL
```

---

# 14. IMPORTANT PRINCIPLE

Never do this:

```python
if long_score < threshold:
    return WAIT
```

This is architecturally forbidden.

Instead:

```python
long_result = evaluate_long(...)
short_result = evaluate_short(...)

final_result = resolve_final_decision(
    long_result,
    short_result,
    execution_mode,
    config
)
```

The final decision can only be made after BOTH directional evaluations are complete.

---

# 15. REPORT STRUCTURE

The report must always contain:

```text
1. MARKET CONTEXT

2. LONG ANALYSIS

3. SHORT ANALYSIS

4. DIRECTION COMPARISON

5. EXECUTION MODE

6. FINAL DECISION

7. FINAL REASON
```

---

# 16. LONG REPORT

Example:

```text
🟢 LONG SCENARIO

Score: 72/100
Status: NOT READY

Structure:        17/20
POI:              20/25
Liquidity:        11/15
Momentum:          8/10
MTF:               7/10
Order Book:        5/10
Execution:         2/5
Premium/Discount:  2/5

Execution Quality: 2/5
Market Risk: HIGH

Blocking Conditions:
❌ Execution Quality below minimum
❌ No valid LTF confirmation

Result:
LONG NOT READY
```

---

# 17. SHORT REPORT

Example:

```text
🔴 SHORT SCENARIO

Score: 81/100
Status: READY

Structure:        18/20
POI:              22/25
Liquidity:        13/15
Momentum:          9/10
MTF:               9/10
Order Book:        7/10
Execution:         3/5
Premium/Discount:  5/5

Execution Quality: 3/5
Market Risk: MEDIUM

Entry: 105,200
SL:    106,100
TP1:   103,850
TP2:   102,500
TP3:   100,800

Result:
SHORT READY
```

---

# 18. DIRECTION COMPARISON

Always show both sides:

```text
━━━━━━━━━━━━━━━━━━━━
⚖️ DIRECTION COMPARISON
━━━━━━━━━━━━━━━━━━━━

LONG
72/100
NOT READY

SHORT
81/100
READY

Difference:
9 points

Directional Winner:
SHORT
```

---

# 19. FINAL DECISION

Example:

```text
━━━━━━━━━━━━━━━━━━━━
🎯 FINAL DECISION
━━━━━━━━━━━━━━━━━━━━

SELL

Reason:
SHORT passed all mandatory gates,
exceeded the configured risk threshold,
and outperformed LONG by the required
directional score margin.

Execution Mode:
COMMITMENT

Market Risk:
MEDIUM

Execution Quality:
3/5
```

---

# 20. WAIT REPORT

If both sides fail:

```text
━━━━━━━━━━━━━━━━━━━━
⏸ FINAL DECISION
━━━━━━━━━━━━━━━━━━━━

WAIT

LONG:
72/100 — NOT READY

Reasons:
❌ LTF confirmation missing
❌ Execution Quality 2/5

SHORT:
69/100 — NOT READY

Reasons:
❌ No valid bearish POI
❌ Score below threshold

Conclusion:
No executable LONG or SHORT setup
is currently available.
```

The system must NEVER write:

```text
BUY conditions failed.
```

unless it is specifically describing the LONG scenario.

---

# 21. BACKTESTING REQUIREMENT

The Backtester MUST use exactly the same dual-direction analysis architecture as live analysis.

For EVERY historical evaluation point:

```python
long_result = evaluate_long(...)
short_result = evaluate_short(...)

decision = resolve_final_decision(...)
```

The Backtester must NOT use a simplified BUY-only or LONG-first algorithm.

---

# 22. BACKTEST RESULT SCHEMA

Each historical evaluation must store:

```text
timestamp

long_score
long_status
long_entry
long_sl
long_tp1
long_tp2
long_tp3
long_rejection_reasons

short_score
short_status
short_entry
short_sl
short_tp1
short_tp2
short_tp3
short_rejection_reasons

final_decision
execution_mode
final_reason
```

This allows historical analysis of both directions even when no trade occurred.

---

# 23. BACKTEST PERFORMANCE REPORT

The Backtester must separately calculate:

```text
LONG opportunities
SHORT opportunities
LONG executed trades
SHORT executed trades
LONG win rate
SHORT win rate
LONG average R:R
SHORT average R:R
LONG TP1 rate
SHORT TP1 rate
LONG SL rate
SHORT SL rate
WAIT periods
CONFLICT periods
```

Do NOT report only:

```text
BUY signals
```

---

# 24. IMPORTANT DISTINCTION

The system must distinguish these states:

```text
NOT_READY
```

means:

```text
This direction was analyzed,
but its conditions are currently insufficient.
```

Whereas:

```text
NOT_EXECUTABLE
```

means:

```text
The technical setup is valid,
but the selected execution mode does not support it.
```

And:

```text
WAIT
```

means:

```text
After evaluating BOTH directions,
there is currently no executable directional trade.
```

And:

```text
CONFLICT
```

means:

```text
Both directions are sufficiently valid,
but there is not enough directional separation
to justify selecting one.
```

---

# 25. FINAL REQUIRED BEHAVIOR

For every market state, the agent MUST answer these questions in order:

```text
1. What is the LONG setup?
2. Is LONG valid?
3. What is the LONG score?
4. Why did LONG gain/lose points?

5. What is the SHORT setup?
6. Is SHORT valid?
7. What is the SHORT score?
8. Why did SHORT gain/lose points?

9. Which direction, if any, has sufficient edge?
10. Is that direction executable under the selected mode?
11. What is the final decision?
12. Why?
```

The final output must therefore never be based on a single directional hypothesis.

The system is a:

```text
DUAL-SIDE MARKET ANALYSIS ENGINE
```

not a:

```text
BUY SIGNAL GENERATOR
```

and not a:

```text
BUY / WAIT CLASSIFIER
```

This architecture is mandatory for both Live Analysis and Backtesting.
