"""Async Nobitex API client.

Wraps the two endpoints this system needs:
  - GET /market/udf/history   (OHLCV candles)
  - GET /v2/orderbook/{symbol} (order book)

Design notes:
- All network calls go through a shared httpx.AsyncClient with an explicit
  timeout.
- Retries use exponential backoff (tenacity) ONLY for transient errors
  (timeouts, 5xx, connection errors) — never for 4xx client errors.
- Responses are validated before being converted into domain Candle
  objects; malformed responses raise NobitexAPIError rather than silently
  producing bad data.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.core.exceptions import NobitexAPIError, NobitexRateLimitError
from app.core.logging import get_logger
from app.domain.enums import CandleState
from app.domain.models import Candle

logger = get_logger(__name__)

# Nobitex udf resolution mapping: our timeframe strings -> udf `resolution` param.
_RESOLUTION_MAP = {
    "1M": "1",
    "5M": "5",
    "15M": "15",
    "30M": "30",
    "1H": "60",
    "4H": "240",
    "1D": "D",
}

_RETRYABLE_EXC = (httpx.TimeoutException, httpx.ConnectError, httpx.RemoteProtocolError)


class NobitexClient:
    def __init__(self, base_url: str, api_token: str | None = None, timeout: float = 10.0) -> None:
        self._base_url = base_url.rstrip("/")
        headers = {"Authorization": f"Token {api_token}"} if api_token else {}
        self._client = httpx.AsyncClient(base_url=self._base_url, headers=headers, timeout=timeout)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "NobitexClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    @retry(
        retry=retry_if_exception_type(_RETRYABLE_EXC),
        stop=stop_after_attempt(4),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=8),
        reraise=True,
    )
    async def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        try:
            resp = await self._client.get(path, params=params)
        except _RETRYABLE_EXC as exc:
            logger.warning("nobitex_transient_error", path=path, error=str(exc))
            raise

        if resp.status_code == 429:
            raise NobitexRateLimitError(f"Rate limited on {path}")
        if resp.status_code >= 500:
            raise NobitexAPIError(f"Nobitex server error {resp.status_code} on {path}")
        if resp.status_code >= 400:
            raise NobitexAPIError(f"Nobitex client error {resp.status_code} on {path}: {resp.text}")

        try:
            return resp.json()
        except ValueError as exc:
            raise NobitexAPIError(f"Malformed JSON from {path}") from exc

    async def fetch_candles(
        self, symbol: str, timeframe: str, count: int = 500
    ) -> list[Candle]:
        resolution = _RESOLUTION_MAP.get(timeframe)
        if resolution is None:
            raise NobitexAPIError(f"Unsupported timeframe: {timeframe!r}")

        to_ts = int(datetime.now(UTC).timestamp())
        # Rough seconds-per-candle to compute a `from` far enough back.
        seconds_per_candle = {
            "1M": 60, "5M": 300, "15M": 900, "30M": 1800,
            "1H": 3600, "4H": 14400, "1D": 86400,
        }[timeframe]
        from_ts = to_ts - seconds_per_candle * (count + 5)

        data = await self._get(
            "/market/udf/history",
            params={
                "symbol": symbol,
                "resolution": resolution,
                "from": from_ts,
                "to": to_ts,
            },
        )
        return self._parse_candles(data, symbol, timeframe, to_ts)

    def _parse_candles(
        self, data: dict[str, Any], symbol: str, timeframe: str, now_ts: int
    ) -> list[Candle]:
        required_keys = {"t", "o", "h", "l", "c", "v", "s"}
        if not required_keys.issubset(data.keys()):
            raise NobitexAPIError(f"Missing keys in candle response: {data.keys()}")
        if data.get("s") not in ("ok", "no_data"):
            raise NobitexAPIError(f"Nobitex reported status={data.get('s')}")
        if data.get("s") == "no_data":
            return []

        times, opens, highs, lows, closes, volumes = (
            data["t"], data["o"], data["h"], data["l"], data["c"], data["v"]
        )
        lengths = {len(times), len(opens), len(highs), len(lows), len(closes), len(volumes)}
        if len(lengths) != 1:
            raise NobitexAPIError("Mismatched array lengths in candle response")

        seconds_per_candle = {
            "1M": 60, "5M": 300, "15M": 900, "30M": 1800,
            "1H": 3600, "4H": 14400, "1D": 86400,
        }[timeframe]

        candles: list[Candle] = []
        for i in range(len(times)):
            open_time = datetime.fromtimestamp(int(times[i]), tz=UTC)
            close_ts = int(times[i]) + seconds_per_candle
            close_time = datetime.fromtimestamp(close_ts, tz=UTC)
            state = CandleState.CLOSED if close_ts <= now_ts else CandleState.OPEN
            try:
                candles.append(
                    Candle(
                        symbol=symbol,
                        timeframe=timeframe,
                        open_time=open_time,
                        close_time=close_time,
                        open=float(opens[i]),
                        high=float(highs[i]),
                        low=float(lows[i]),
                        close=float(closes[i]),
                        volume=float(volumes[i]),
                        state=state,
                    )
                )
            except (ValueError, TypeError) as exc:
                raise NobitexAPIError(f"Malformed candle at index {i}: {exc}") from exc

        candles.sort(key=lambda c: c.open_time)
        return candles

    async def fetch_orderbook(self, symbol: str) -> dict[str, Any]:
        data = await self._get(f"/v2/orderbook/{symbol}")
        if "bids" not in data or "asks" not in data:
            raise NobitexAPIError("Malformed orderbook response: missing bids/asks")
        return data

    async def test_connection(self) -> bool:
        """Lightweight authenticated call used by the Setup Wizard's
        "Test Connection" button. NOT VERIFIED AGAINST A LIVE RESPONSE —
        implemented against Nobitex's documented authenticated profile
        endpoint. Raises `NobitexAPIError` (invalid credentials, 4xx) or
        a transient network error on failure; callers (the setup wizard)
        catch and translate to a Persian message rather than propagating
        a raw exception to the user."""
        await self._get("/users/profile")
        return True

    async def fetch_all_market_symbols(self) -> list[dict[str, str]]:
        """Discover every tradeable symbol dynamically (ADDITIONAL_MODULE:
        DYNAMIC_NOBITEX_SYMBOL_&_WATCHLIST_MANAGER section 1 — "Do not
        hard-code the list of available Nobitex symbols").

        NOT VERIFIED AGAINST A LIVE RESPONSE (no network access during
        development — see README.md). Implemented against Nobitex's
        documented all-pairs market summary endpoint, which returns
        stats for every pair keyed by "{base}-{quote}" (e.g. "btc-rls",
        "eth-usdt"). Re-verify the exact key format and any pairs that
        should be excluded (e.g. delisted/inactive) against current
        Nobitex API docs before relying on this in production — see
        DEPLOYMENT.md's verification checklist.

        Returns a list of dicts: {"symbol": "BTCUSDT", "base": "BTC",
        "quote": "USDT", "market_type": "TETHER" | "RIAL"}.
        """
        data = await self._get("/market/stats")
        stats = data.get("stats")
        if not isinstance(stats, dict):
            raise NobitexAPIError("Malformed market stats response: missing 'stats' object")

        symbols: list[dict[str, str]] = []
        for pair_key in stats:
            parsed = _parse_pair_key(pair_key)
            if parsed is not None:
                symbols.append(parsed)
        return symbols


def _parse_pair_key(pair_key: str) -> dict[str, str] | None:
    """'btc-rls' -> {'symbol': 'BTCIRT', 'base': 'BTC', 'quote': 'IRT',
    'market_type': 'RIAL'}; 'eth-usdt' -> TETHER. Returns None for a key
    that doesn't match the expected "{base}-{quote}" shape rather than
    raising — a single unexpected pair should never break discovery of
    every other symbol."""
    if "-" not in pair_key:
        return None
    base, _, quote = pair_key.partition("-")
    if not base or not quote:
        return None
    base_u, quote_u = base.upper(), quote.upper()

    if quote_u in ("RLS", "IRR"):
        return {"symbol": f"{base_u}IRT", "base": base_u, "quote": "IRT", "market_type": "RIAL"}
    if quote_u == "USDT":
        return {"symbol": f"{base_u}USDT", "base": base_u, "quote": "USDT", "market_type": "TETHER"}
    return None
