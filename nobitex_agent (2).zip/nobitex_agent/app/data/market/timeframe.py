"""Timeframe-hierarchy and closed-candle helpers.

The single rule enforced here: NOTHING downstream (indicators, detectors,
confluence, risk) may ever see the currently-forming (OPEN) candle. This
module is the one chokepoint that guarantees that.
"""

from __future__ import annotations

from dataclasses import dataclass

from app.domain.enums import CandleState, TimeframeRole
from app.domain.models import Candle


def only_closed(candles: list[Candle]) -> list[Candle]:
    """Return only CLOSED candles, preserving order. This is the sole
    function that should be called before passing candles into any
    indicator or detector."""
    return [c for c in candles if c.state == CandleState.CLOSED]


@dataclass(frozen=True)
class TimeframeHierarchy:
    htf: str
    mtf: str
    ltf: str
    execution: str

    def role_of(self, timeframe: str) -> TimeframeRole | None:
        mapping = {
            self.htf: TimeframeRole.HTF,
            self.mtf: TimeframeRole.MTF,
            self.ltf: TimeframeRole.LTF,
            self.execution: TimeframeRole.EXECUTION,
        }
        return mapping.get(timeframe)

    def all_timeframes(self) -> list[str]:
        # De-duplicate while preserving HTF->execution order.
        seen: list[str] = []
        for tf in (self.htf, self.mtf, self.ltf, self.execution):
            if tf not in seen:
                seen.append(tf)
        return seen
