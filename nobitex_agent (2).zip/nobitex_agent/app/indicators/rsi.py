"""RSI (Wilder's smoothing), default period 14, with divergence detection."""

from __future__ import annotations

from app.domain.models import Candle, RSIResult, SwingPoint
from app.indicators.divergence import detect_divergences
from app.indicators.swings import detect_swings


def compute_rsi_series(closes: list[float], period: int = 14) -> list[float | None]:
    n = len(closes)
    result: list[float | None] = [None] * n
    if n <= period:
        return result

    gains = [0.0] * n
    losses = [0.0] * n
    for i in range(1, n):
        change = closes[i] - closes[i - 1]
        gains[i] = max(change, 0.0)
        losses[i] = max(-change, 0.0)

    avg_gain = sum(gains[1 : period + 1]) / period
    avg_loss = sum(losses[1 : period + 1]) / period
    result[period] = _rsi_from_avgs(avg_gain, avg_loss)

    for i in range(period + 1, n):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
        result[i] = _rsi_from_avgs(avg_gain, avg_loss)

    return result


def _rsi_from_avgs(avg_gain: float, avg_loss: float) -> float:
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))


def compute_rsi(
    closed_candles: list[Candle],
    period: int = 14,
    min_swing_distance: int = 5,
    min_price_separation_pct: float = 0.1,
    swing_lookback: int = 2,
) -> RSIResult:
    closes = [c.close for c in closed_candles]
    series = compute_rsi_series(closes, period)
    value = series[-1] if series else None

    price_swings: list[SwingPoint] = detect_swings(closed_candles, lookback=swing_lookback)
    osc_by_index = {i: v for i, v in enumerate(series) if v is not None}

    divergences = detect_divergences(
        price_swings,
        osc_by_index,
        min_swing_distance=min_swing_distance,
        min_price_separation_pct=min_price_separation_pct,
    )

    return RSIResult(value=value, divergences=divergences)
