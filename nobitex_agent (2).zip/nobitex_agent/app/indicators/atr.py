"""Average True Range (Wilder), used to define measurable 'strong move' and
stop-loss buffers elsewhere in the system."""

from __future__ import annotations

from app.domain.models import Candle


def compute_atr_series(candles: list[Candle], period: int = 14) -> list[float | None]:
    n = len(candles)
    result: list[float | None] = [None] * n
    if n < 2:
        return result

    true_ranges: list[float] = [0.0] * n
    for i in range(1, n):
        c, prev = candles[i], candles[i - 1]
        true_ranges[i] = max(
            c.high - c.low,
            abs(c.high - prev.close),
            abs(c.low - prev.close),
        )

    if n <= period:
        return result

    avg = sum(true_ranges[1 : period + 1]) / period
    result[period] = avg
    for i in range(period + 1, n):
        avg = (avg * (period - 1) + true_ranges[i]) / period
        result[i] = avg

    return result
