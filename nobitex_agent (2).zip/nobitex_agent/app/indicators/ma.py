"""Simple Moving Average (MA20 / MA200) and cross classification.

Deterministic rules:
- Price > MA200 -> Bullish macro bias; Price < MA200 -> Bearish macro bias.
- A "Fresh Cross" is a Golden/Death cross whose crossover candle is one of
  the last `fresh_window` CLOSED candles. Anything older is
  "Existing Alignment" (the MAs are still crossed, but it is not a new
  trigger).
"""

from __future__ import annotations

from app.domain.enums import CrossType, Direction
from app.domain.models import Candle, MovingAverageResult


def sma(values: list[float], period: int) -> list[float | None]:
    """Simple moving average; None where insufficient data exists."""
    result: list[float | None] = [None] * len(values)
    running_sum = 0.0
    for i, v in enumerate(values):
        running_sum += v
        if i >= period:
            running_sum -= values[i - period]
        if i >= period - 1:
            result[i] = running_sum / period
    return result


def _classify_cross(
    ma20_series: list[float | None],
    ma200_series: list[float | None],
    fresh_window: int = 3,
) -> CrossType:
    n = len(ma20_series)
    last_idx = n - 1
    if ma20_series[last_idx] is None or ma200_series[last_idx] is None:
        return CrossType.NONE

    currently_golden = ma20_series[last_idx] > ma200_series[last_idx]  # type: ignore[operator]

    # Search backward for the most recent crossover point within the series.
    cross_index: int | None = None
    cross_is_golden: bool | None = None
    for i in range(last_idx, 0, -1):
        a_prev, b_prev = ma20_series[i - 1], ma200_series[i - 1]
        a_cur, b_cur = ma20_series[i], ma200_series[i]
        if None in (a_prev, b_prev, a_cur, b_cur):
            continue
        prev_golden = a_prev > b_prev  # type: ignore[operator]
        cur_golden = a_cur > b_cur  # type: ignore[operator]
        if prev_golden != cur_golden:
            cross_index = i
            cross_is_golden = cur_golden
            break

    if cross_index is None:
        return CrossType.NONE

    is_fresh = (last_idx - cross_index) < fresh_window

    if cross_is_golden:
        return CrossType.GOLDEN_FRESH if is_fresh else CrossType.GOLDEN_EXISTING
    return CrossType.DEATH_FRESH if is_fresh else CrossType.DEATH_EXISTING


def compute_moving_averages(
    closed_candles: list[Candle], fresh_window: int = 3
) -> MovingAverageResult:
    """Compute MA20/MA200 and cross state using only CLOSED candles."""
    closes = [c.close for c in closed_candles]
    ma20_series = sma(closes, 20)
    ma200_series = sma(closes, 200)

    ma20 = ma20_series[-1] if ma20_series else None
    ma200 = ma200_series[-1] if ma200_series else None

    price_vs_ma200: Direction | None = None
    if ma200 is not None and closed_candles:
        last_close = closed_candles[-1].close
        price_vs_ma200 = Direction.BULLISH if last_close > ma200 else Direction.BEARISH

    cross_type = (
        _classify_cross(ma20_series, ma200_series, fresh_window)
        if len(closed_candles) >= 200
        else CrossType.NONE
    )

    return MovingAverageResult(
        ma20=ma20,
        ma200=ma200,
        price_vs_ma200=price_vs_ma200,
        cross_type=cross_type,
    )
