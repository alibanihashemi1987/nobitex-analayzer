"""Causal (non-repainting) swing-point detection.

A swing high/low at index i is only CONFIRMED once `lookback` candles to
its left AND `lookback` candles to its right are all closed and available.
This means a swing point becomes known `lookback` candles *after* it
occurred — this delay is intentional and is what prevents lookahead bias.

Callers must never treat the most recent `lookback` candles as containing
confirmed swings.
"""

from __future__ import annotations

from app.domain.enums import Direction
from app.domain.models import Candle, SwingPoint


def detect_swings(candles: list[Candle], lookback: int = 2) -> list[SwingPoint]:
    """Detect confirmed swing highs/lows using a symmetric fractal rule.

    A candle at index i is a swing HIGH if its high is strictly greater
    than the high of every candle in [i-lookback, i+lookback] \\ {i}.
    Symmetric rule for swing LOW using lows.

    Only CLOSED candles are considered. The function is purely a function
    of the candles passed in (no external state), so re-running it on the
    same historical slice always yields the same result (deterministic,
    non-repainting).
    """
    swings: list[SwingPoint] = []
    n = len(candles)
    for i in range(lookback, n - lookback):
        window = candles[i - lookback : i + lookback + 1]
        if any(c.state.value != "CLOSED" for c in window):
            continue
        center = candles[i]

        is_high = all(
            center.high > candles[j].high for j in range(i - lookback, i + lookback + 1) if j != i
        )
        is_low = all(
            center.low < candles[j].low for j in range(i - lookback, i + lookback + 1) if j != i
        )

        if is_high:
            swings.append(
                SwingPoint(
                    index=i,
                    time=center.open_time,
                    price=center.high,
                    direction=Direction.BEARISH,
                    confirmed=True,
                )
            )
        if is_low:
            swings.append(
                SwingPoint(
                    index=i,
                    time=center.open_time,
                    price=center.low,
                    direction=Direction.BULLISH,
                    confirmed=True,
                )
            )
    swings.sort(key=lambda s: s.index)
    return swings


def swing_highs(swings: list[SwingPoint]) -> list[SwingPoint]:
    return [s for s in swings if s.direction == Direction.BEARISH]


def swing_lows(swings: list[SwingPoint]) -> list[SwingPoint]:
    return [s for s in swings if s.direction == Direction.BULLISH]
