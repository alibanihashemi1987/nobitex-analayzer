"""Money Flow Index, default period 10, with divergence detection."""

from __future__ import annotations

from app.domain.models import Candle, MFIResult, SwingPoint
from app.indicators.divergence import detect_divergences
from app.indicators.swings import detect_swings

OVERSOLD_THRESHOLD = 30.0
OVERBOUGHT_THRESHOLD = 70.0


def _typical_price(c: Candle) -> float:
    return (c.high + c.low + c.close) / 3.0


def compute_mfi_series(candles: list[Candle], period: int = 10) -> list[float | None]:
    n = len(candles)
    result: list[float | None] = [None] * n
    if n <= period:
        return result

    typical_prices = [_typical_price(c) for c in candles]
    raw_money_flow = [typical_prices[i] * candles[i].volume for i in range(n)]

    for i in range(period, n):
        positive_flow = 0.0
        negative_flow = 0.0
        for j in range(i - period + 1, i + 1):
            if j == 0:
                continue
            if typical_prices[j] > typical_prices[j - 1]:
                positive_flow += raw_money_flow[j]
            elif typical_prices[j] < typical_prices[j - 1]:
                negative_flow += raw_money_flow[j]
        if negative_flow == 0:
            result[i] = 100.0
        else:
            money_ratio = positive_flow / negative_flow
            result[i] = 100.0 - (100.0 / (1.0 + money_ratio))

    return result


def compute_mfi(
    closed_candles: list[Candle],
    period: int = 10,
    min_swing_distance: int = 5,
    min_price_separation_pct: float = 0.1,
    swing_lookback: int = 2,
) -> MFIResult:
    series = compute_mfi_series(closed_candles, period)
    value = series[-1] if series else None

    overbought = value is not None and value > OVERBOUGHT_THRESHOLD
    oversold = value is not None and value < OVERSOLD_THRESHOLD

    price_swings: list[SwingPoint] = detect_swings(closed_candles, lookback=swing_lookback)
    osc_by_index = {i: v for i, v in enumerate(series) if v is not None}

    divergences = detect_divergences(
        price_swings,
        osc_by_index,
        min_swing_distance=min_swing_distance,
        min_price_separation_pct=min_price_separation_pct,
    )

    return MFIResult(value=value, overbought=overbought, oversold=oversold, divergences=divergences)
