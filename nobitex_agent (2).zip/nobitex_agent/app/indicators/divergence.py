"""Regular and hidden divergence detection between price and an oscillator.

Definitions used (documented deterministically, see STRATEGY.md):

- Regular Bullish:  price makes a LOWER low, oscillator makes a HIGHER low.
- Regular Bearish:  price makes a HIGHER high, oscillator makes a LOWER high.
- Hidden Bullish:   price makes a HIGHER low, oscillator makes a LOWER low.
- Hidden Bearish:   price makes a LOWER high, oscillator makes a HIGHER high.

Only CONFIRMED swing points (see app.indicators.swings) are compared, and
only the two most recent same-type swings are checked, to avoid noisy
signals. Two additional configurable filters suppress noise further:

- `min_swing_distance`: minimum candle-index gap between the two swings.
- `min_price_separation_pct`: minimum % difference between the two swing
  prices, so near-identical swings don't spuriously trigger.
"""

from __future__ import annotations

from app.domain.enums import DivergenceType
from app.domain.models import SwingPoint


def _pct_diff(a: float, b: float) -> float:
    if b == 0:
        return 0.0
    return abs(a - b) / abs(b) * 100.0


def detect_divergences(
    price_swings: list[SwingPoint],
    oscillator_values_by_index: dict[int, float],
    min_swing_distance: int = 5,
    min_price_separation_pct: float = 0.1,
) -> list[DivergenceType]:
    """Compare the two most recent confirmed swing highs and swing lows.

    `oscillator_values_by_index` maps candle index -> oscillator value at
    that index (must already be computed using only closed candles).
    """
    results: list[DivergenceType] = []

    highs = [s for s in price_swings if s.direction.value == "BEARISH"]
    lows = [s for s in price_swings if s.direction.value == "BULLISH"]

    results.extend(_check_pair(lows, oscillator_values_by_index, min_swing_distance,
                                min_price_separation_pct, is_low=True))
    results.extend(_check_pair(highs, oscillator_values_by_index, min_swing_distance,
                                min_price_separation_pct, is_low=False))
    return results


def _check_pair(
    swings: list[SwingPoint],
    osc_by_index: dict[int, float],
    min_distance: int,
    min_sep_pct: float,
    is_low: bool,
) -> list[DivergenceType]:
    if len(swings) < 2:
        return []
    prev, cur = swings[-2], swings[-1]

    if (cur.index - prev.index) < min_distance:
        return []
    if _pct_diff(cur.price, prev.price) < min_sep_pct:
        return []
    if prev.index not in osc_by_index or cur.index not in osc_by_index:
        return []

    prev_osc, cur_osc = osc_by_index[prev.index], osc_by_index[cur.index]
    out: list[DivergenceType] = []

    if is_low:
        if cur.price < prev.price and cur_osc > prev_osc:
            out.append(DivergenceType.REGULAR_BULLISH)
        elif cur.price > prev.price and cur_osc < prev_osc:
            out.append(DivergenceType.HIDDEN_BULLISH)
    else:
        if cur.price > prev.price and cur_osc < prev_osc:
            out.append(DivergenceType.REGULAR_BEARISH)
        elif cur.price < prev.price and cur_osc > prev_osc:
            out.append(DivergenceType.HIDDEN_BEARISH)

    return out
