"""Typed domain models.

Every detector in the system returns one of these structured models -
never a raw dict - so downstream consumers (confluence engine, charts,
persistence) have a single, explicit contract to rely on.

Implemented with stdlib `dataclasses` (frozen, slotted) rather than
Pydantic: this layer is pure logic with no I/O, so it has zero external
dependencies and can be imported/tested in any Python 3.12+ environment
without an internet connection or a package install step. Validation
that Pydantic would give for free is done explicitly in `__post_init__`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from app.domain.enums import (
    CandleState,
    CrossType,
    Direction,
    DivergenceType,
    MitigationState,
    SignalDecision,
    SignalStatus,
    StructureEvent,
    ZoneType,
)


@dataclass(frozen=True, slots=True)
class Candle:
    """A single OHLCV candle, timezone-aware (UTC) and explicitly stateful."""

    symbol: str
    timeframe: str
    open_time: datetime  # tz-aware, UTC
    close_time: datetime  # tz-aware, UTC
    open: float
    high: float
    low: float
    close: float
    volume: float
    state: CandleState

    def __post_init__(self) -> None:
        if self.high < max(self.open, self.close, self.low):
            raise ValueError("high must be >= open/close/low")
        if self.low > min(self.open, self.close, self.high):
            raise ValueError("low must be <= open/close/high")


@dataclass(frozen=True, slots=True)
class SwingPoint:
    index: int  # index within the closed-candle series it was computed on
    time: datetime
    price: float
    direction: Direction  # BULLISH = swing low (origin of upmove), BEARISH = swing high
    confirmed: bool  # True only once enough future-closed candles confirm it


@dataclass(frozen=True, slots=True)
class StructureBreak:
    event: StructureEvent
    direction: Direction
    time: datetime
    broken_swing: SwingPoint
    breaking_candle_index: int


@dataclass(frozen=True, slots=True)
class FVG:
    direction: Direction
    upper: float
    lower: float
    size: float
    created_time: datetime
    created_candle_index: int
    mitigation_state: MitigationState
    mitigation_pct: float = 0.0
    active: bool = True


@dataclass(frozen=True, slots=True)
class OrderBlock:
    direction: Direction
    zone_upper: float
    zone_lower: float
    origin_candle_index: int
    origin_time: datetime
    structure_event: StructureEvent
    strength_score: float  # 0-1, based on measurable move-strength rule
    active: bool = True
    mitigation_state: MitigationState = MitigationState.ACTIVE


@dataclass(frozen=True, slots=True)
class BreakerBlock:
    original_ob: OrderBlock
    invalidation_time: datetime
    invalidation_candle_index: int
    new_direction: Direction  # opposite of original_ob.direction
    retested: bool = False
    retest_time: datetime | None = None


@dataclass(frozen=True, slots=True)
class MitigationBlock:
    direction: Direction
    zone_upper: float
    zone_lower: float
    origin_candle_index: int
    origin_time: datetime
    mitigation_state: MitigationState


@dataclass(frozen=True, slots=True)
class LiquiditySweep:
    direction: Direction  # BULLISH sweep = swept sell-side liquidity (low) then reversed up
    swept_level: float
    swept_swing: SwingPoint
    sweep_candle_index: int
    sweep_time: datetime
    reversal_confirmed: bool


@dataclass(frozen=True, slots=True)
class TurtleSoup:
    direction: Direction
    failed_breakout_level: float
    candle_index: int
    time: datetime


@dataclass(frozen=True, slots=True)
class OTEZone:
    direction: Direction
    fib_618: float
    fib_705: float
    fib_79: float
    leg_start: float
    leg_end: float
    in_zone: bool


@dataclass(frozen=True, slots=True)
class VolumeImbalance:
    direction: Direction
    upper: float
    lower: float
    candle_index: int
    time: datetime


@dataclass(frozen=True, slots=True)
class PremiumDiscountZone:
    range_high: float
    range_low: float
    equilibrium: float
    current_zone: ZoneType
    current_price: float


@dataclass(frozen=True, slots=True)
class MovingAverageResult:
    ma20: float | None
    ma200: float | None
    price_vs_ma200: Direction | None
    cross_type: CrossType


@dataclass(frozen=True, slots=True)
class MFIResult:
    value: float | None
    overbought: bool
    oversold: bool
    divergences: list[DivergenceType] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class RSIResult:
    value: float | None
    divergences: list[DivergenceType] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class OrderBookAnalysis:
    bid_volume: float
    ask_volume: float
    imbalance_ratio: float  # (bid - ask) / (bid + ask), range [-1, 1]
    liquidity_near_entry: float
    liquidity_near_sl: float
    liquidity_near_tp: float
    walls_bid: list[tuple[float, float]] = field(default_factory=list)  # (price, volume)
    walls_ask: list[tuple[float, float]] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class ConfluenceBreakdown:
    component_scores: dict[str, float]  # e.g. {"fvg": 8.0, "ob": 12.0, ...}
    total_score: float  # 0-100
    decision: SignalDecision


@dataclass(frozen=True, slots=True)
class RiskLevels:
    entry: float
    stop_loss: float
    tp1: float
    tp2: float
    tp3: float
    risk_reward_tp1: float
    risk_reward_tp2: float
    risk_reward_tp3: float


@dataclass(slots=True)
class Signal:
    """A fully generated, persisted trading setup. Mutable (status changes
    over its lifetime as TP/SL outcomes are tracked), unlike the immutable
    detector outputs above."""

    symbol: str
    timeframe: str
    decision: SignalDecision
    risk: RiskLevels
    confluence: ConfluenceBreakdown
    created_at: datetime
    id: str | None = None
    status: SignalStatus = SignalStatus.OPEN
    outcome_time: datetime | None = None
    time_to_target_seconds: int | None = None
    time_to_stop_seconds: int | None = None
    poi_type: str | None = None  # e.g. "OrderBlock", "FVG"
    risk_profile: str = "moderate"
