"""Immutable `MarketContext` snapshot and its builder.

Per ADDITIONAL_ARCHITECTURE_REQUIREMENTS sections 1-4: every shared
calculation (structure, swings, BOS/CHoCH, FVGs, Order Blocks, Breaker
Blocks, Mitigation Blocks, liquidity sweeps, indicators, order book) is
computed EXACTLY ONCE per analysis cycle and stored here. The LONG and
SHORT evaluators both read from the SAME `MarketContext` instance — they
never independently recompute these values, and they never mutate it.

`build_market_context()` must be called exactly once per cycle; the
resulting object is then passed unchanged to `evaluate_long`,
`evaluate_short`, and `resolve_final_decision`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Mapping

from app.domain.enums import DataValidity, Direction
from app.domain.models import (
    FVG,
    BreakerBlock,
    Candle,
    MFIResult,
    MitigationBlock,
    MovingAverageResult,
    OrderBlock,
    OrderBookAnalysis,
    OTEZone,
    PremiumDiscountZone,
    RSIResult,
    StructureBreak,
    SwingPoint,
    TurtleSoup,
    VolumeImbalance,
)
from app.data.market.timeframe import only_closed
from app.indicators.atr import compute_atr_series
from app.indicators.ma import compute_moving_averages
from app.indicators.mfi import compute_mfi
from app.indicators.rsi import compute_rsi
from app.indicators.swings import detect_swings
from app.orderbook.analyzer import analyze_orderbook
from app.strategy.fibonacci.ote import detect_ote_zone
from app.strategy.fibonacci.premium_discount import detect_premium_discount
from app.strategy.ict.breaker_block import detect_breaker_blocks
from app.strategy.ict.fvg import detect_fvgs
from app.strategy.ict.mitigation_block import detect_mitigation_blocks
from app.strategy.ict.order_block import detect_order_blocks
from app.strategy.ict.volume_imbalance import detect_volume_imbalances
from app.strategy.liquidity.liquidity import detect_liquidity_sweeps
from app.strategy.liquidity.turtle_soup import detect_turtle_soups
from app.strategy.smc.structure import current_trend, detect_structure_breaks

MIN_CANDLES_FOR_VALIDITY = 50


@dataclass(frozen=True, slots=True)
class StructureState:
    swings: tuple[SwingPoint, ...]
    breaks: tuple[StructureBreak, ...]
    trend: Direction | None


@dataclass(frozen=True, slots=True)
class POIContext:
    fvgs: tuple[FVG, ...]
    order_blocks: tuple[OrderBlock, ...]
    breaker_blocks: tuple[BreakerBlock, ...]
    mitigation_blocks: tuple[MitigationBlock, ...]
    volume_imbalances: tuple[VolumeImbalance, ...]
    ote_zone: OTEZone | None


@dataclass(frozen=True, slots=True)
class LiquidityContext:
    sweeps: tuple
    turtle_soups: tuple[TurtleSoup, ...]


@dataclass(frozen=True, slots=True)
class IndicatorContext:
    ma: MovingAverageResult
    ma20_slope_pct: float | None
    rsi: RSIResult
    mfi: MFIResult
    atr: float | None
    premium_discount: PremiumDiscountZone | None


@dataclass(frozen=True, slots=True)
class OrderBookContext:
    raw: Mapping | None
    analysis: OrderBookAnalysis | None
    spread_pct: float | None


@dataclass(frozen=True, slots=True)
class TimeframeSnapshot:
    role: str
    timeframe: str
    candles: tuple[Candle, ...]  # CLOSED only, chronological
    structure: StructureState
    pois: POIContext
    liquidity: LiquidityContext
    indicators: IndicatorContext


@dataclass(frozen=True, slots=True)
class MarketContext:
    """A single, immutable snapshot of market truth for one analysis
    cycle. Never mutated after construction. LONG and SHORT evaluators
    read from this — they must never call any of the `build_*` /
    `detect_*` functions themselves on raw candles."""

    symbol: str
    timestamp: datetime
    timeframes: Mapping[str, TimeframeSnapshot]  # keyed by role: HTF/MTF/LTF/EXECUTION
    orderbook: OrderBookContext | None
    data_validity: DataValidity
    data_validity_reason: str | None = None


def _build_timeframe_snapshot(
    role: str,
    timeframe: str,
    raw_candles: list[Candle],
    divergence_min_swing_distance: int,
    divergence_min_price_separation_pct: float,
    ma20_slope_lookback: int,
    ob_atr_multiplier: float,
    ob_atr_period: int,
    fvg_invalidation_pct: float,
    premium_discount_range_period: int = 50,
    premium_discount_equilibrium_band_pct: float = 0.05,
) -> TimeframeSnapshot:
    closed = only_closed(raw_candles)

    swings = detect_swings(closed)
    breaks = detect_structure_breaks(closed)
    trend = current_trend(breaks)
    structure = StructureState(swings=tuple(swings), breaks=tuple(breaks), trend=trend)

    fvgs = tuple(detect_fvgs(closed, invalidation_pct=fvg_invalidation_pct))
    order_blocks = tuple(
        detect_order_blocks(closed, breaks, atr_multiplier=ob_atr_multiplier, atr_period=ob_atr_period)
    )
    breaker_blocks = tuple(detect_breaker_blocks(closed, list(order_blocks)))
    mitigation_blocks = tuple(
        detect_mitigation_blocks(closed, breaks, atr_multiplier=ob_atr_multiplier, atr_period=ob_atr_period)
    )
    volume_imbalances = tuple(detect_volume_imbalances(closed))
    ote_zone = detect_ote_zone(closed)
    pois = POIContext(
        fvgs=fvgs,
        order_blocks=order_blocks,
        breaker_blocks=breaker_blocks,
        mitigation_blocks=mitigation_blocks,
        volume_imbalances=volume_imbalances,
        ote_zone=ote_zone,
    )

    sweeps = tuple(detect_liquidity_sweeps(closed))
    turtle_soups = tuple(detect_turtle_soups(closed))
    liquidity = LiquidityContext(sweeps=sweeps, turtle_soups=turtle_soups)

    ma_result = compute_moving_averages(closed)
    ma20_slope = _compute_ma20_slope(closed, ma20_slope_lookback)
    rsi_result = compute_rsi(
        closed,
        min_swing_distance=divergence_min_swing_distance,
        min_price_separation_pct=divergence_min_price_separation_pct,
    )
    mfi_result = compute_mfi(
        closed,
        min_swing_distance=divergence_min_swing_distance,
        min_price_separation_pct=divergence_min_price_separation_pct,
    )
    atr_series = compute_atr_series(closed, ob_atr_period)
    atr = atr_series[-1] if atr_series else None
    pd_zone = detect_premium_discount(
        closed,
        range_period=premium_discount_range_period,
        equilibrium_band_pct=premium_discount_equilibrium_band_pct,
    )
    indicators = IndicatorContext(
        ma=ma_result, ma20_slope_pct=ma20_slope, rsi=rsi_result, mfi=mfi_result,
        atr=atr, premium_discount=pd_zone,
    )

    return TimeframeSnapshot(
        role=role, timeframe=timeframe, candles=tuple(closed),
        structure=structure, pois=pois, liquidity=liquidity, indicators=indicators,
    )


def _compute_ma20_slope(closed_candles: list[Candle], lookback: int) -> float | None:
    """slope = (MA20[current] - MA20[N]) / MA20[N], per section 13.A3."""
    from app.indicators.ma import sma

    closes = [c.close for c in closed_candles]
    ma20_series = sma(closes, 20)
    if len(ma20_series) <= lookback:
        return None
    current = ma20_series[-1]
    past = ma20_series[-1 - lookback]
    if current is None or past is None or past == 0:
        return None
    return (current - past) / past


def build_market_context(
    symbol: str,
    timestamp: datetime,
    candles_by_role: Mapping[str, list[Candle]],
    role_to_timeframe: Mapping[str, str],
    divergence_min_swing_distance: int = 5,
    divergence_min_price_separation_pct: float = 0.1,
    ma20_slope_lookback: int = 3,
    ob_atr_multiplier: float = 1.5,
    ob_atr_period: int = 14,
    fvg_invalidation_pct: float = 0.5,
    premium_discount_equilibrium_buffer: float = 0.02,
    premium_discount_range_period: int = 50,
    orderbook_raw: Mapping | None = None,
    entry_hint: float | None = None,
) -> MarketContext:
    """Build a single immutable MarketContext. Call exactly once per
    analysis cycle (or once per historical timestamp during backtesting)
    — see ADDITIONAL_ARCHITECTURE_REQUIREMENTS section 3.

    `candles_by_role` must map role name ("HTF"/"MTF"/"LTF"/"EXECUTION")
    to the RAW candle list for that timeframe (including the currently
    forming candle if present — this function is what filters to
    CLOSED-only, exactly once, per role).
    """
    validity = DataValidity.VALID
    validity_reason: str | None = None

    if not candles_by_role:
        validity = DataValidity.INSUFFICIENT_DATA
        validity_reason = "No candle data supplied for any timeframe role."

    snapshots: dict[str, TimeframeSnapshot] = {}
    for role, raw_candles in candles_by_role.items():
        timeframe = role_to_timeframe.get(role, "")
        closed_count = len(only_closed(raw_candles))
        if closed_count < MIN_CANDLES_FOR_VALIDITY and validity == DataValidity.VALID:
            validity = DataValidity.INSUFFICIENT_DATA
            validity_reason = (
                f"Only {closed_count} closed candles for role={role} "
                f"({timeframe}); minimum is {MIN_CANDLES_FOR_VALIDITY}."
            )
        snapshots[role] = _build_timeframe_snapshot(
            role=role,
            timeframe=timeframe,
            raw_candles=raw_candles,
            divergence_min_swing_distance=divergence_min_swing_distance,
            divergence_min_price_separation_pct=divergence_min_price_separation_pct,
            ma20_slope_lookback=ma20_slope_lookback,
            ob_atr_multiplier=ob_atr_multiplier,
            ob_atr_period=ob_atr_period,
            fvg_invalidation_pct=fvg_invalidation_pct,
            premium_discount_range_period=premium_discount_range_period,
            premium_discount_equilibrium_band_pct=premium_discount_equilibrium_buffer,
        )

    orderbook_ctx: OrderBookContext | None = None
    if orderbook_raw is not None:
        bids = orderbook_raw.get("bids", [])
        asks = orderbook_raw.get("asks", [])
        spread_pct = None
        if bids and asks:
            try:
                best_bid = max(float(p) for p, _ in bids)
                best_ask = min(float(p) for p, _ in asks)
                mid = (best_bid + best_ask) / 2
                spread_pct = ((best_ask - best_bid) / mid) * 100 if mid else None
            except (ValueError, TypeError):
                spread_pct = None

        analysis = None
        if entry_hint is not None:
            # A neutral placeholder analysis (SL/TP unknown at context-build
            # time); directional evaluators re-run analyze_orderbook with
            # their own concrete SL/TP once those are calculated.
            analysis = analyze_orderbook(
                orderbook_raw, entry=entry_hint, stop_loss=entry_hint, take_profit=entry_hint
            )
        orderbook_ctx = OrderBookContext(raw=orderbook_raw, analysis=analysis, spread_pct=spread_pct)

    return MarketContext(
        symbol=symbol,
        timestamp=timestamp,
        timeframes=snapshots,
        orderbook=orderbook_ctx,
        data_validity=validity,
        data_validity_reason=validity_reason,
    )
