"""Directional analysis result models (MANDATORY_ARCHITECTURE_CHANGE
section 2, ADDITIONAL_ARCHITECTURE_REQUIREMENTS section 5).

Extended for BALE_REPORTING_ENGINE_REFACTOR: `MarketAnalysisResult` now
carries an `analysis_id` (so a report can be regenerated on demand
without recomputation) and an optional `market_overview` snapshot (the
per-timeframe trend summary the Bale reports need). Both are additive,
default-valued fields — nothing about the existing scoring/resolver
contract changed.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime

from app.domain.enums import (
    Direction,
    ExecutionEligibility,
    ExecutionMode,
    FinalDecision,
    HTFAlignmentStrength,
    MarketRiskLevel,
    TechnicalStatus,
)
from app.domain.events import POIEvent, ScoreBreakdown
from app.domain.models import RiskLevels


@dataclass(frozen=True, slots=True)
class DirectionalAnalysis:
    direction: str  # "LONG" or "SHORT"

    status: TechnicalStatus
    execution_eligibility: ExecutionEligibility
    execution_ineligibility_reason: str | None

    score_breakdown: ScoreBreakdown
    execution_quality: float  # 0-5
    market_risk: MarketRiskLevel
    htf_alignment: HTFAlignmentStrength

    hard_gates_passed: bool
    hard_gate_failures: tuple[str, ...]

    primary_poi: POIEvent | None
    risk: RiskLevels | None

    rejection_reasons: tuple[str, ...] = ()
    early_ltf_entry: bool = False

    @property
    def score(self) -> float:
        return self.score_breakdown.total


@dataclass(frozen=True, slots=True)
class TimeframeOverview:
    """One line of the report's multi-timeframe status section."""

    role: str  # "HTF" / "MTF" / "LTF" / "EXECUTION"
    timeframe: str  # e.g. "4H"
    trend: Direction | None  # None = neutral/undetermined


@dataclass(frozen=True, slots=True)
class MarketOverview:
    """A small, report-oriented summary derived from `MarketContext` at
    analysis time. This is intentionally NOT the full `MarketContext`
    (which is not persisted) — just enough to render the "market
    overview" / multi-timeframe section of a report without needing the
    original candle data again."""

    htf: TimeframeOverview
    mtf: TimeframeOverview
    ltf: TimeframeOverview
    execution: TimeframeOverview
    price_above_ma200: Direction | None
    ma20_above_ma200: bool | None


@dataclass(frozen=True, slots=True)
class MarketAnalysisResult:
    symbol: str
    timestamp: datetime

    long_analysis: DirectionalAnalysis
    short_analysis: DirectionalAnalysis

    final_decision: FinalDecision
    execution_mode: ExecutionMode
    final_reason: str

    directional_winner: str | None = None  # "LONG" / "SHORT" / None
    score_difference: float | None = None
    htf_tie_break_used: bool = False

    analysis_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    market_overview: MarketOverview | None = None
