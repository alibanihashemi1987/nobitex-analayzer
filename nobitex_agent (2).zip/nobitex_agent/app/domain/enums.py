from __future__ import annotations

from enum import StrEnum


class CandleState(StrEnum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"


class Direction(StrEnum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"


class SignalDecision(StrEnum):
    BUY = "BUY"
    SELL = "SELL"
    WAIT = "WAIT"


class StructureEvent(StrEnum):
    BOS = "BOS"
    CHOCH = "CHOCH"


class MitigationState(StrEnum):
    ACTIVE = "ACTIVE"
    PARTIALLY_MITIGATED = "PARTIALLY_MITIGATED"
    MITIGATED = "MITIGATED"
    INVALIDATED = "INVALIDATED"


class DivergenceType(StrEnum):
    REGULAR_BULLISH = "REGULAR_BULLISH"
    REGULAR_BEARISH = "REGULAR_BEARISH"
    HIDDEN_BULLISH = "HIDDEN_BULLISH"
    HIDDEN_BEARISH = "HIDDEN_BEARISH"


class ZoneType(StrEnum):
    PREMIUM = "PREMIUM"
    DISCOUNT = "DISCOUNT"
    EQUILIBRIUM = "EQUILIBRIUM"


class CrossType(StrEnum):
    GOLDEN_FRESH = "GOLDEN_FRESH"
    DEATH_FRESH = "DEATH_FRESH"
    GOLDEN_EXISTING = "GOLDEN_EXISTING"
    DEATH_EXISTING = "DEATH_EXISTING"
    NONE = "NONE"


class SignalStatus(StrEnum):
    OPEN = "OPEN"
    TP1_HIT = "TP1_HIT"
    TP2_HIT = "TP2_HIT"
    TP3_HIT = "TP3_HIT"
    SL_HIT = "SL_HIT"
    EXPIRED = "EXPIRED"
    INVALIDATED = "INVALIDATED"


class TimeframeRole(StrEnum):
    HTF = "HTF"
    MTF = "MTF"
    LTF = "LTF"
    EXECUTION = "EXECUTION"


class TechnicalStatus(StrEnum):
    """Whether a directional (LONG/SHORT) scenario is technically valid,
    independent of whether the current execution mode can trade it."""

    READY = "READY"
    NOT_READY = "NOT_READY"
    INVALID = "INVALID"


class ExecutionEligibility(StrEnum):
    """Whether the CURRENT execution mode (SPOT/COMMITMENT) can actually
    take this direction. Deliberately separate from TechnicalStatus —
    a technically READY setup can still be NOT_ELIGIBLE (e.g. a READY
    SHORT under SPOT mode, which cannot short)."""

    ELIGIBLE = "ELIGIBLE"
    NOT_ELIGIBLE = "NOT_ELIGIBLE"
    UNKNOWN = "UNKNOWN"


class MarketRiskLevel(StrEnum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class ExecutionMode(StrEnum):
    SPOT = "SPOT"
    COMMITMENT = "COMMITMENT"


class FinalDecision(StrEnum):
    BUY = "BUY"
    SELL = "SELL"
    WAIT = "WAIT"
    CONFLICT = "CONFLICT"


class HTFAlignmentStrength(StrEnum):
    STRONG = "STRONG"
    MODERATE = "MODERATE"
    WEAK = "WEAK"
    NEUTRAL = "NEUTRAL"
    OPPOSITE = "OPPOSITE"


class SignalStrength(StrEnum):
    """Informational-only classification of a confluence score (section 28)."""

    VERY_WEAK = "VERY_WEAK"
    WEAK = "WEAK"
    MODERATE = "MODERATE"
    GOOD = "GOOD"
    STRONG = "STRONG"
    EXCEPTIONAL = "EXCEPTIONAL"


class RiskProfileName(StrEnum):
    CONSERVATIVE = "conservative"
    MODERATE = "moderate"
    AGGRESSIVE = "aggressive"


class DataValidity(StrEnum):
    """Gate 1 (Data Validity). Only VALID passes; every other value is a
    hard-gate failure that forces WAIT regardless of score."""

    VALID = "VALID"
    STALE = "STALE"
    PARTIAL = "PARTIAL"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    API_ERROR = "API_ERROR"
    DATA_GAP = "DATA_GAP"


class POIType(StrEnum):
    LIQUIDITY_SWEEP_STRUCTURAL_SHIFT = "LIQUIDITY_SWEEP_STRUCTURAL_SHIFT"
    ORDER_BLOCK = "ORDER_BLOCK"
    BREAKER_BLOCK = "BREAKER_BLOCK"
    FVG = "FVG"
    OTE = "OTE"
    MITIGATION_BLOCK = "MITIGATION_BLOCK"
    VOLUME_IMBALANCE = "VOLUME_IMBALANCE"
    DYNAMIC_MA = "DYNAMIC_MA"
