"""Structured evidence models for the deterministic scoring engine.

Mirrors the Pydantic models specified in REPLACEMENT_MODULE section 24,
implemented with stdlib dataclasses (see app/domain/models.py's module
docstring for why: this keeps the entire analytical core dependency-free
and testable without a package install step).

Every awarded scoring point must trace back to a `ScoreFactor`, which in
turn references the `event_id`(s) that justified it. This is what makes
the engine auditable (section 40): "why did this setup receive 83
points" is always answerable by walking `ScoreBreakdown.factors`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True, slots=True)
class MarketEvent:
    event_id: str
    event_type: str
    symbol: str
    timeframe: str
    timestamp: datetime
    direction: str | None
    candle_indices: tuple[int, ...]
    evidence: dict = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class POIEvent:
    event_id: str
    poi_type: str
    symbol: str
    timeframe: str
    direction: str
    zone_high: float
    zone_low: float
    created_at: datetime
    mitigation_status: str
    structural_event_id: str | None = None


@dataclass(frozen=True, slots=True)
class ScoreFactor:
    factor_id: str
    category: str
    name: str
    awarded_points: float
    maximum_points: float
    evidence: str
    event_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.awarded_points < 0 or self.awarded_points > self.maximum_points:
            raise ValueError(
                f"factor {self.factor_id}: awarded_points {self.awarded_points} "
                f"out of range [0, {self.maximum_points}]"
            )


@dataclass(frozen=True, slots=True)
class ScoreBreakdown:
    structure: float
    poi: float
    liquidity: float
    momentum: float
    mtf: float
    orderbook: float
    execution: float
    premium_discount: float
    total: float
    factors: tuple[ScoreFactor, ...] = ()

    def __post_init__(self) -> None:
        if not (0 <= self.total <= 100):
            raise ValueError(f"total score {self.total} out of range [0, 100]")


class EventRegistry:
    """Deterministic anti-double-counting registry (section 25).

    Scoped to a single analysis cycle (one instance per `MarketContext`
    build). Before awarding a `ScoreFactor` for a given underlying
    event, the scoring engine checks `already_counted` — if the same
    event was already used to justify a factor in the SAME category
    hierarchy path (e.g. the sweep that made a candidate the Primary
    POI must not also independently score full points as the C1
    Liquidity Sweep factor), it must not be counted twice.
    """

    def __init__(self) -> None:
        self._events: dict[str, MarketEvent] = {}
        self._consumed_by: dict[str, set[str]] = {}  # event_id -> set of factor_ids

    def register(self, event: MarketEvent) -> MarketEvent:
        self._events[event.event_id] = event
        self._consumed_by.setdefault(event.event_id, set())
        return event

    def already_counted(self, event_id: str, factor_id: str) -> bool:
        """True if `event_id` has already been consumed by any factor
        OTHER than `factor_id` within a mutually-exclusive group. Callers
        pass their own factor_id so re-checking the same factor is safe
        (idempotent), but a different factor claiming the same event is
        flagged."""
        consumers = self._consumed_by.get(event_id, set())
        return bool(consumers - {factor_id})

    def consume(self, event_id: str, factor_id: str) -> None:
        self._consumed_by.setdefault(event_id, set()).add(factor_id)

    def get(self, event_id: str) -> MarketEvent | None:
        return self._events.get(event_id)

    def all_events(self) -> list[MarketEvent]:
        return list(self._events.values())
