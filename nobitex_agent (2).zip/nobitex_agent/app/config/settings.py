"""Centralized, typed application configuration.

All environment-specific values (secrets, connection strings, operational
knobs like scan interval) MUST be read from here. No module outside this
file should call `os.environ` directly. The app fails fast (at startup)
if required configuration is missing or malformed.

Scoring weights, thresholds, timeframe-role mapping, and every other
STRATEGY constant live in `app/config/scoring_config.yaml` /
`scoring_config.py` instead — see REPLACEMENT_MODULE section 42 ("Do not
scatter numerical constants across Python files"). This module and that
one are deliberately kept separate: this one is "where do I connect and
how often do I run", that one is "what does a good trade look like".

Implemented with stdlib `dataclasses` + `os.environ` (no pydantic-settings
dependency) so this module has zero external dependencies beyond the
standard library. A minimal `.env` loader is included since python-dotenv
is not assumed to be installed.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

_ALLOWED_LOG_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}


def _load_dotenv(path: str = ".env") -> None:
    """Minimal .env loader: KEY=VALUE per line, '#' comments, no nesting.
    Does not override variables already present in the real environment.
    """
    p = Path(path)
    if not p.exists():
        return
    for raw_line in p.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def _get_str(key: str, default: str | None) -> str | None:
    return os.environ.get(key, default)


def _get_int(key: str, default: int) -> int:
    raw = os.environ.get(key)
    return int(raw) if raw not in (None, "") else default


def _get_float(key: str, default: float) -> float:
    raw = os.environ.get(key)
    return float(raw) if raw not in (None, "") else default


@dataclass(frozen=True, slots=True)
class Settings:
    # --- Nobitex ---
    nobitex_base_url: str = field(default_factory=lambda: _get_str("NOBITEX_BASE_URL", "https://apiv2.nobitex.ir"))
    nobitex_api_token: str | None = field(default_factory=lambda: _get_str("NOBITEX_API_TOKEN", None))

    # --- Bale ---
    bale_bot_token: str | None = field(default_factory=lambda: _get_str("BALE_BOT_TOKEN", None))
    bale_chat_id: str | None = field(default_factory=lambda: _get_str("BALE_CHAT_ID", None))

    # --- Database ---
    database_url: str = field(
        default_factory=lambda: _get_str("DATABASE_URL", "sqlite+aiosqlite:///./data/nobitex_agent.db")
    )

    # --- Logging ---
    log_level: str = field(default_factory=lambda: _get_str("LOG_LEVEL", "INFO").upper())

    # --- Trading defaults ---
    default_symbol: str = field(default_factory=lambda: _get_str("DEFAULT_SYMBOL", "BTCIRT"))
    default_risk_profile: str = field(default_factory=lambda: _get_str("DEFAULT_RISK_PROFILE", "moderate"))
    execution_mode: str = field(default_factory=lambda: _get_str("EXECUTION_MODE", "SPOT").upper())

    # --- Scheduler ---
    scan_interval_seconds: int = field(default_factory=lambda: _get_int("SCAN_INTERVAL_SECONDS", 300))
    alert_cooldown_seconds: int = field(default_factory=lambda: _get_int("ALERT_COOLDOWN_SECONDS", 1800))

    # --- Candle fetch ---
    candle_count: int = field(default_factory=lambda: _get_int("CANDLE_COUNT", 500))

    # --- Web UI (Setup Wizard / Dashboard / Settings) ---
    # No authentication is implemented in this build — see DEPLOYMENT.md's
    # security note. WEB_UI_HOST defaults to loopback-only for safety;
    # only change it to 0.0.0.0 (e.g. for Docker) behind a firewall,
    # VPN, or authenticating reverse proxy.
    web_ui_host: str = field(default_factory=lambda: _get_str("WEB_UI_HOST", "127.0.0.1"))
    web_ui_port: int = field(default_factory=lambda: _get_int("WEB_UI_PORT", 8765))

    def __post_init__(self) -> None:
        if self.log_level not in _ALLOWED_LOG_LEVELS:
            raise ValueError(f"LOG_LEVEL must be one of {_ALLOWED_LOG_LEVELS}, got {self.log_level!r}")
        if self.execution_mode not in ("SPOT", "COMMITMENT"):
            raise ValueError(f"EXECUTION_MODE must be SPOT or COMMITMENT, got {self.execution_mode!r}")
        if self.scan_interval_seconds <= 0:
            raise ValueError("SCAN_INTERVAL_SECONDS must be > 0")
        if self.alert_cooldown_seconds < 0:
            raise ValueError("ALERT_COOLDOWN_SECONDS must be >= 0")
        if self.candle_count < 50:
            raise ValueError("CANDLE_COUNT must be >= 50")
        if not (1 <= self.web_ui_port <= 65535):
            raise ValueError("WEB_UI_PORT must be a valid port number")

    def require_bale(self) -> tuple[str, str]:
        """Fail loudly when Bale credentials are needed but missing."""
        if not self.bale_bot_token or not self.bale_chat_id:
            raise RuntimeError(
                "BALE_BOT_TOKEN and BALE_CHAT_ID must be set to use Bale notifications."
            )
        return self.bale_bot_token, self.bale_chat_id


@lru_cache
def get_settings() -> Settings:
    """Return a cached, process-wide Settings instance."""
    _load_dotenv()
    return Settings()
