"""Typed, validated loader for `scoring_config.yaml`.

This is the single source of truth for every weight/threshold used by
the deterministic scoring engine and the directional resolver. No
scoring module may hard-code a point value or threshold — it must come
from a `ScoringConfig` instance (see REPLACEMENT_MODULE sections 42-43).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import yaml

_DEFAULT_PATH = Path(__file__).parent / "scoring_config.yaml"


@dataclass(frozen=True, slots=True)
class CategoryWeights:
    structure: int
    poi: int
    liquidity: int
    momentum: int
    mtf: int
    orderbook: int
    execution: int
    premium_discount: int

    def __post_init__(self) -> None:
        total = (
            self.structure + self.poi + self.liquidity + self.momentum
            + self.mtf + self.orderbook + self.execution + self.premium_discount
        )
        if total != 100:
            raise ValueError(f"Category weights must sum to 100, got {total}")


@dataclass(frozen=True, slots=True)
class PremiumDiscountConfig:
    equilibrium: float = 0.50
    buffer: float = 0.02


@dataclass(frozen=True, slots=True)
class ExecutionConfig:
    minimum_score: int = 3
    early_ltf_penalty: int = 1


@dataclass(frozen=True, slots=True)
class MTFTimeframes:
    htf: str = "4H"
    mtf: str = "1H"
    ltf: str = "15M"
    execution: str = "5M"


@dataclass(frozen=True, slots=True)
class DivergenceConfig:
    min_swing_distance: int = 5
    min_price_separation_pct: float = 0.1


@dataclass(frozen=True, slots=True)
class RiskProfileThreshold:
    threshold: int
    minimum_execution: int
    maximum_market_risk: str  # MarketRiskLevel value; kept as str to avoid a domain import cycle


@dataclass(frozen=True, slots=True)
class DecisionConfig:
    minimum_directional_score_difference: int = 8


@dataclass(frozen=True, slots=True)
class OrderBlockConfig:
    strong_move_atr_multiplier: float = 1.5
    atr_period: int = 14


@dataclass(frozen=True, slots=True)
class FVGConfig:
    invalidation_pct: float = 0.5


@dataclass(frozen=True, slots=True)
class RiskConfig:
    r_multiples: tuple[float, float, float] = (1.0, 2.0, 3.0)
    atr_buffer_multiplier: float = 0.25
    minimum_risk_reward: float = 1.0


@dataclass(frozen=True, slots=True)
class ScoringConfig:
    categories: CategoryWeights
    premium_discount: PremiumDiscountConfig
    execution: ExecutionConfig
    mtf_timeframes: MTFTimeframes
    ma20_slope_lookback: int
    divergence: DivergenceConfig
    risk_profiles: dict[str, RiskProfileThreshold]
    decision: DecisionConfig
    order_block: OrderBlockConfig
    fvg: FVGConfig
    risk: RiskConfig


def _load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _build_config(raw: dict) -> ScoringConfig:
    scoring = raw["scoring"]
    return ScoringConfig(
        categories=CategoryWeights(**scoring["categories"]),
        premium_discount=PremiumDiscountConfig(**scoring["premium_discount"]),
        execution=ExecutionConfig(**scoring["execution"]),
        mtf_timeframes=MTFTimeframes(**scoring["mtf_timeframes"]),
        ma20_slope_lookback=scoring["ma20_slope_lookback"],
        divergence=DivergenceConfig(**scoring["divergence"]),
        risk_profiles={
            name: RiskProfileThreshold(**vals)
            for name, vals in scoring["risk_profiles"].items()
        },
        decision=DecisionConfig(**raw["decision"]),
        order_block=OrderBlockConfig(**raw["order_block"]),
        fvg=FVGConfig(**raw["fvg"]),
        risk=RiskConfig(
            r_multiples=tuple(raw["risk"]["r_multiples"]),
            atr_buffer_multiplier=raw["risk"]["atr_buffer_multiplier"],
            minimum_risk_reward=raw["risk"]["minimum_risk_reward"],
        ),
    )


@lru_cache
def get_scoring_config(path: str | None = None) -> ScoringConfig:
    """Load and cache the scoring config. Pass an explicit `path` (str)
    to load an alternate file, e.g. for tests exercising non-default
    weights; omit it to use the bundled default."""
    resolved = Path(path) if path else _DEFAULT_PATH
    raw = _load_yaml(resolved)
    return _build_config(raw)
