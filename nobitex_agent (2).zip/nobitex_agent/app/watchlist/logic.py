"""Pure watchlist business logic (ADDITIONAL_MODULE: DYNAMIC_NOBITEX_
SYMBOL_&_WATCHLIST_MANAGER). Zero database/network dependency — every
function here takes plain data in, returns plain data out, so it's
testable without a live DB or Nobitex connection. `app/database/db.py`'s
`WatchlistSymbolRecord` methods are the thin persistence layer that
calls into this for validation/filtering.
"""

from __future__ import annotations

from dataclasses import dataclass

MARKET_TYPES = ("RIAL", "TETHER")


@dataclass(frozen=True, slots=True)
class WatchlistItem:
    symbol: str
    market_type: str
    enabled: bool
    display_order: int


def validate_symbol_format(symbol: str) -> bool:
    """A Nobitex-style symbol: uppercase letters/digits only, ending in
    a known quote currency (IRT or USDT), e.g. "BTCIRT", "ETHUSDT"."""
    if not symbol or not symbol.isupper() or not symbol.isalnum():
        return False
    return symbol.endswith("IRT") and len(symbol) > 3 or symbol.endswith("USDT") and len(symbol) > 4


def infer_market_type(symbol: str) -> str | None:
    if symbol.endswith("USDT"):
        return "TETHER"
    if symbol.endswith("IRT"):
        return "RIAL"
    return None


def search_symbols(available: list[dict[str, str]], query: str) -> list[dict[str, str]]:
    """Case-insensitive substring match against symbol or base currency —
    used by both the Setup Wizard's search box and the Bale "جستجوی نماد"
    handler."""
    if not query:
        return available
    q = query.strip().upper()
    return [s for s in available if q in s["symbol"] or q in s.get("base", "")]


def filter_by_market_type(available: list[dict[str, str]], market_type: str) -> list[dict[str, str]]:
    if market_type not in MARKET_TYPES:
        return available
    return [s for s in available if s.get("market_type") == market_type]


def sort_watchlist(items: list[WatchlistItem]) -> list[WatchlistItem]:
    return sorted(items, key=lambda i: i.display_order)


def reorder(symbols_in_new_order: list[str], current: list[WatchlistItem]) -> list[WatchlistItem]:
    """Given a caller-supplied new ordering (a list of symbols) and the
    current watchlist, return the items re-assigned to that order.
    Symbols present in `current` but omitted from `symbols_in_new_order`
    keep their relative order and are appended at the end (defensive —
    a caller should always supply every symbol, but a partial list must
    never silently drop watchlist entries)."""
    by_symbol = {item.symbol: item for item in current}
    ordered: list[WatchlistItem] = []
    seen: set[str] = set()

    for i, symbol in enumerate(symbols_in_new_order):
        item = by_symbol.get(symbol)
        if item is not None:
            ordered.append(
                WatchlistItem(symbol=item.symbol, market_type=item.market_type,
                               enabled=item.enabled, display_order=i)
            )
            seen.add(symbol)

    next_order = len(ordered)
    for item in current:
        if item.symbol not in seen:
            ordered.append(
                WatchlistItem(symbol=item.symbol, market_type=item.market_type,
                               enabled=item.enabled, display_order=next_order)
            )
            next_order += 1

    return ordered
