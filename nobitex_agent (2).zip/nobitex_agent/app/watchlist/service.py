"""Watchlist service — thin async wrapper connecting `app/database/db.py`
persistence to the pure logic in `app/watchlist/logic.py`. This is what
the Setup Wizard, Bale Control Center, and the autonomous monitor all
call — a single source of truth for "which symbols are being watched".
"""

from __future__ import annotations

from app.core.exceptions import ConfigurationError
from app.database.db import Database
from app.watchlist.logic import WatchlistItem, validate_symbol_format


class WatchlistService:
    def __init__(self, db: Database) -> None:
        self._db = db

    async def list_all(self) -> list[WatchlistItem]:
        records = await self._db.get_watchlist(enabled_only=False)
        return [
            WatchlistItem(symbol=r.symbol, market_type=r.market_type, enabled=r.enabled, display_order=r.display_order)
            for r in records
        ]

    async def list_enabled(self) -> list[str]:
        """Symbols the autonomous monitor should scan (ADDITIONAL_MODULE:
        DYNAMIC_NOBITEX_SYMBOL_&_WATCHLIST_MANAGER section 6)."""
        records = await self._db.get_watchlist(enabled_only=True)
        return [r.symbol for r in sorted(records, key=lambda r: r.display_order)]

    async def add(self, symbol: str, market_type: str) -> WatchlistItem:
        if not validate_symbol_format(symbol):
            raise ConfigurationError(f"Invalid symbol format: {symbol!r}")
        record = await self._db.add_watchlist_symbol(symbol, market_type)
        return WatchlistItem(symbol=record.symbol, market_type=record.market_type,
                              enabled=record.enabled, display_order=record.display_order)

    async def remove(self, symbol: str) -> bool:
        return await self._db.remove_watchlist_symbol(symbol)

    async def set_enabled(self, symbol: str, enabled: bool) -> bool:
        return await self._db.set_watchlist_symbol_enabled(symbol, enabled)

    async def reorder(self, ordered_symbols: list[str]) -> None:
        await self._db.reorder_watchlist(ordered_symbols)
