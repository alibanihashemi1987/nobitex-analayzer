"""Application-wide exception hierarchy."""

from __future__ import annotations


class AgentError(Exception):
    """Base class for all application-specific errors."""


class ConfigurationError(AgentError):
    """Required configuration is missing or invalid."""


class NobitexAPIError(AgentError):
    """Nobitex API returned an error or malformed response."""


class NobitexRateLimitError(NobitexAPIError):
    """Nobitex API rate limit was hit."""


class InsufficientCandlesError(AgentError):
    """Not enough closed candles are available to perform analysis."""


class BaleAPIError(AgentError):
    """Bale bot API returned an error."""


class DatabaseError(AgentError):
    """A persistence-layer operation failed."""


class InvalidSetupError(AgentError):
    """A generated setup fails validation (e.g. inverted SL/TP)."""
