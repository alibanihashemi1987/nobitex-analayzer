"""Bale Messenger Bot API client.

Bale's Bot API is Telegram-Bot-API-compatible for the endpoints used here
(sendMessage / sendPhoto). Base URL: https://tapi.bale.ai/bot{token}/...
"""

from __future__ import annotations

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.core.exceptions import BaleAPIError
from app.core.logging import get_logger

logger = get_logger(__name__)

_RETRYABLE_EXC = (httpx.TimeoutException, httpx.ConnectError)


class BaleClient:
    def __init__(self, bot_token: str, chat_id: str, timeout: float = 10.0) -> None:
        self._base_url = f"https://tapi.bale.ai/bot{bot_token}"
        self._chat_id = chat_id
        self._client = httpx.AsyncClient(timeout=timeout)

    async def aclose(self) -> None:
        await self._client.aclose()

    @retry(
        retry=retry_if_exception_type(_RETRYABLE_EXC),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=6),
        reraise=True,
    )
    async def test_connection(self) -> bool:
        """Used by the Setup Wizard's Bale "Test Connection" step. Calls
        the bot-token-scoped `getMe` endpoint (Telegram-Bot-API-compatible)
        -- succeeds only if the token itself is valid; does not require
        `chat_id` to be correct. Raises `BaleAPIError` on an invalid
        token; callers translate that to a Persian message."""
        resp = await self._client.post(f"{self._base_url}/getMe", json={})
        self._raise_for_bale_error(resp)
        return True

    @retry(
        retry=retry_if_exception_type(_RETRYABLE_EXC),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=6),
        reraise=True,
    )
    async def send_message(
        self, text: str, parse_mode: str = "Markdown", reply_markup: dict | None = None
    ) -> None:
        payload: dict = {"chat_id": self._chat_id, "text": text, "parse_mode": parse_mode}
        if reply_markup is not None:
            payload["reply_markup"] = reply_markup
        resp = await self._client.post(f"{self._base_url}/sendMessage", json=payload)
        self._raise_for_bale_error(resp)

    @retry(
        retry=retry_if_exception_type(_RETRYABLE_EXC),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=6),
        reraise=True,
    )
    async def send_photo(
        self, photo_bytes: bytes, caption: str = "", reply_markup: dict | None = None
    ) -> None:
        files = {"photo": ("chart.png", photo_bytes, "image/png")}
        data: dict = {"chat_id": self._chat_id, "caption": caption}
        if reply_markup is not None:
            import json as _json
            data["reply_markup"] = _json.dumps(reply_markup)
        resp = await self._client.post(f"{self._base_url}/sendPhoto", data=data, files=files)
        self._raise_for_bale_error(resp)

    @retry(
        retry=retry_if_exception_type(_RETRYABLE_EXC),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=6),
        reraise=True,
    )
    async def answer_callback_query(self, callback_query_id: str, text: str | None = None) -> None:
        """Acknowledge an inline-keyboard button press (Telegram-Bot-API-
        compatible `answerCallbackQuery`). Used by the Detailed Report
        callback handler so Bale stops showing the button's loading spinner."""
        payload: dict = {"callback_query_id": callback_query_id}
        if text:
            payload["text"] = text
        resp = await self._client.post(f"{self._base_url}/answerCallbackQuery", json=payload)
        self._raise_for_bale_error(resp)

    @staticmethod
    def _raise_for_bale_error(resp: httpx.Response) -> None:
        if resp.status_code >= 400:
            raise BaleAPIError(f"Bale API error {resp.status_code}: {resp.text}")
        try:
            body = resp.json()
        except ValueError as exc:
            raise BaleAPIError("Malformed JSON from Bale API") from exc
        if not body.get("ok", False):
            raise BaleAPIError(f"Bale API returned ok=false: {body}")
