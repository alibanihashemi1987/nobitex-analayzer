"""Dual-direction Backtester (MANDATORY_ARCHITECTURE_CHANGE sections
21-23). Walks historical candles chronologically; at every evaluation
point it builds a MarketContext using ONLY candles available up to that
point, then runs the exact same evaluate_long / evaluate_short /
resolve_final_decision pipeline used live -- never a simplified
BUY-only or LONG-first shortcut.

KNOWN SIMPLIFICATION: true multi-timeframe backtesting requires
resampling one base series into synchronized HTF/MTF/LTF/EXECUTION
candles. That resampler is not implemented in this build -- this
backtester instead runs all four timeframe roles off the SAME candle
series (documented in STRATEGY.md). The dual-direction decision
architecture and lookahead-safety guarantee are still fully exercised;
only the "genuine multi-timeframe" aspect is approximated until a
resampler is added.
"""

from __future__ import annotations

from dataclasses import dataclass

from app.config.scoring_config import ScoringConfig
from app.domain.context import build_market_context
from app.domain.directional import MarketAnalysisResult
from app.domain.enums import ExecutionMode, FinalDecision, TechnicalStatus
from app.domain.models import Candle
from app.strategy.directional.evaluate_long import evaluate_long
from app.strategy.directional.evaluate_short import evaluate_short
from app.strategy.directional.resolver import resolve_final_decision

MIN_CANDLES_PER_STEP = 60


@dataclass(frozen=True, slots=True)
class BacktestStep:
    index: int
    result: MarketAnalysisResult


def run_backtest(
    candles: list[Candle],
    scoring_config: ScoringConfig,
    execution_mode: ExecutionMode = ExecutionMode.COMMITMENT,
    risk_profile: str = "moderate",
    min_candles_per_step: int = MIN_CANDLES_PER_STEP,
) -> list[BacktestStep]:
    """Section 21: `long_result = evaluate_long(...); short_result =
    evaluate_short(...); decision = resolve_final_decision(...)` for
    EVERY historical evaluation point -- never a simplified algorithm."""
    steps: list[BacktestStep] = []
    role_to_timeframe = {
        "HTF": scoring_config.mtf_timeframes.htf, "MTF": scoring_config.mtf_timeframes.mtf,
        "LTF": scoring_config.mtf_timeframes.ltf, "EXECUTION": scoring_config.mtf_timeframes.execution,
    }

    for i in range(min_candles_per_step, len(candles) + 1):
        window = candles[:i]  # the entire lookahead-bias guarantee lives here
        context = build_market_context(
            symbol=window[-1].symbol,
            timestamp=window[-1].close_time,
            candles_by_role={role: window for role in role_to_timeframe},
            role_to_timeframe=role_to_timeframe,
            divergence_min_swing_distance=scoring_config.divergence.min_swing_distance,
            divergence_min_price_separation_pct=scoring_config.divergence.min_price_separation_pct,
            ma20_slope_lookback=scoring_config.ma20_slope_lookback,
            ob_atr_multiplier=scoring_config.order_block.strong_move_atr_multiplier,
            ob_atr_period=scoring_config.order_block.atr_period,
            fvg_invalidation_pct=scoring_config.fvg.invalidation_pct,
            premium_discount_equilibrium_buffer=scoring_config.premium_discount.buffer,
            orderbook_raw=None,
        )

        long_result = evaluate_long(context, scoring_config, risk_profile)
        short_result = evaluate_short(context, scoring_config, risk_profile)
        decision = resolve_final_decision(
            long_result, short_result, execution_mode, scoring_config.decision,
            window[-1].symbol, window[-1].close_time,
        )
        steps.append(BacktestStep(index=i - 1, result=decision))

    return steps


@dataclass(frozen=True, slots=True)
class BacktestPerformanceReport:
    long_opportunities: int
    short_opportunities: int
    buy_decisions: int
    sell_decisions: int
    wait_periods: int
    conflict_periods: int
    long_ready_rate_pct: float
    short_ready_rate_pct: float


def summarize_backtest(steps: list[BacktestStep]) -> BacktestPerformanceReport:
    """Section 23: report BOTH directions' opportunity counts, not just
    'BUY signals'."""
    total = len(steps)
    long_ready = sum(1 for s in steps if s.result.long_analysis.status == TechnicalStatus.READY)
    short_ready = sum(1 for s in steps if s.result.short_analysis.status == TechnicalStatus.READY)
    buys = sum(1 for s in steps if s.result.final_decision == FinalDecision.BUY)
    sells = sum(1 for s in steps if s.result.final_decision == FinalDecision.SELL)
    waits = sum(1 for s in steps if s.result.final_decision == FinalDecision.WAIT)
    conflicts = sum(1 for s in steps if s.result.final_decision == FinalDecision.CONFLICT)

    return BacktestPerformanceReport(
        long_opportunities=long_ready,
        short_opportunities=short_ready,
        buy_decisions=buys,
        sell_decisions=sells,
        wait_periods=waits,
        conflict_periods=conflicts,
        long_ready_rate_pct=round(100 * long_ready / total, 2) if total else 0.0,
        short_ready_rate_pct=round(100 * short_ready / total, 2) if total else 0.0,
    )
