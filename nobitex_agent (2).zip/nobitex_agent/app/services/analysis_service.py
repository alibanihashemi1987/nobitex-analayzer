"""Orchestrates a full dual-direction analysis cycle for one symbol:

    fetch candles per timeframe role (network I/O, the only impure step)
        -> build_market_context   (ONE immutable snapshot, section 1-3)
        -> evaluate_long / evaluate_short   (independent, section 1)
        -> resolve_final_decision            (comparison only, section 5)

This replaces the old single-direction confluence engine entirely, per
REPLACEMENT_MODULE section 44: "That model must NOT remain active
anywhere in the codebase."
"""

from __future__ import annotations

from dataclasses import replace
from datetime import UTC, datetime

from app.config.scoring_config import ScoringConfig
from app.core.exceptions import InsufficientCandlesError
from app.core.logging import get_logger
from app.data.nobitex.client import NobitexClient
from app.domain.context import MarketContext, TimeframeSnapshot, build_market_context
from app.domain.directional import MarketAnalysisResult, MarketOverview, TimeframeOverview
from app.domain.enums import ExecutionMode
from app.strategy.directional.evaluate_long import evaluate_long
from app.strategy.directional.evaluate_short import evaluate_short
from app.strategy.directional.resolver import resolve_final_decision

logger = get_logger(__name__)

MIN_CLOSED_CANDLES = 50


def _build_market_overview(context: MarketContext) -> MarketOverview | None:
    """Report-oriented summary derived from the already-built
    MarketContext — purely presentational, computes nothing new (reads
    `structure.trend` / `indicators.ma`, which the scoring engine already
    computed). Returns None if HTF data is unavailable."""
    htf = context.timeframes.get("HTF")
    if htf is None:
        return None

    def _overview(role: str) -> TimeframeOverview:
        snap: TimeframeSnapshot | None = context.timeframes.get(role)
        return TimeframeOverview(
            role=role,
            timeframe=snap.timeframe if snap else "",
            trend=snap.structure.trend if snap else None,
        )

    ma20_above_ma200 = (
        htf.indicators.ma.ma20 > htf.indicators.ma.ma200
        if htf.indicators.ma.ma20 is not None and htf.indicators.ma.ma200 is not None
        else None
    )

    return MarketOverview(
        htf=_overview("HTF"), mtf=_overview("MTF"), ltf=_overview("LTF"), execution=_overview("EXECUTION"),
        price_above_ma200=htf.indicators.ma.price_vs_ma200,
        ma20_above_ma200=ma20_above_ma200,
    )


async def run_dual_analysis(
    client: NobitexClient,
    scoring_config: ScoringConfig,
    symbol: str,
    execution_mode: ExecutionMode = ExecutionMode.COMMITMENT,
    risk_profile: str = "moderate",
    candle_count: int = 500,
) -> MarketAnalysisResult:
    """Fetch fresh candles for every configured timeframe role, build a
    single immutable MarketContext, then independently evaluate LONG and
    SHORT and resolve the final decision. This is the ONLY place that
    performs network I/O in the analysis pipeline — everything below it
    (context building, both evaluators, the resolver) is pure and
    testable without a network connection."""
    role_to_timeframe = {
        "HTF": scoring_config.mtf_timeframes.htf,
        "MTF": scoring_config.mtf_timeframes.mtf,
        "LTF": scoring_config.mtf_timeframes.ltf,
        "EXECUTION": scoring_config.mtf_timeframes.execution,
    }

    candles_by_role = {}
    for role, timeframe in role_to_timeframe.items():
        candles_by_role[role] = await client.fetch_candles(symbol, timeframe, candle_count)

    execution_candles = candles_by_role.get("EXECUTION", [])
    closed_execution = [c for c in execution_candles if c.state.value == "CLOSED"]
    if len(closed_execution) < MIN_CLOSED_CANDLES:
        raise InsufficientCandlesError(
            f"Only {len(closed_execution)} closed EXECUTION candles available for {symbol}; "
            f"need at least {MIN_CLOSED_CANDLES}."
        )

    orderbook_raw = None
    try:
        orderbook_raw = await client.fetch_orderbook(symbol)
    except Exception:
        logger.warning("orderbook_fetch_failed", symbol=symbol)

    entry_hint = closed_execution[-1].close if closed_execution else None
    timestamp = datetime.now(UTC)

    context = build_market_context(
        symbol=symbol,
        timestamp=timestamp,
        candles_by_role=candles_by_role,
        role_to_timeframe=role_to_timeframe,
        divergence_min_swing_distance=scoring_config.divergence.min_swing_distance,
        divergence_min_price_separation_pct=scoring_config.divergence.min_price_separation_pct,
        ma20_slope_lookback=scoring_config.ma20_slope_lookback,
        ob_atr_multiplier=scoring_config.order_block.strong_move_atr_multiplier,
        ob_atr_period=scoring_config.order_block.atr_period,
        fvg_invalidation_pct=scoring_config.fvg.invalidation_pct,
        premium_discount_equilibrium_buffer=scoring_config.premium_discount.buffer,
        orderbook_raw=orderbook_raw,
        entry_hint=entry_hint,
    )

    # Independent evaluation — evaluate_short never sees long_result, and
    # vice versa (section 1). The single shared `context` guarantees both
    # see the exact same market snapshot (section 2-3).
    long_result = evaluate_long(context, scoring_config, risk_profile)
    short_result = evaluate_short(context, scoring_config, risk_profile)

    final_result = resolve_final_decision(
        long_analysis=long_result,
        short_analysis=short_result,
        execution_mode=execution_mode,
        decision_config=scoring_config.decision,
        symbol=symbol,
        timestamp=timestamp,
    )

    # Attach the report-oriented overview after the fact — the resolver
    # itself never sees or produces this (BALE_REPORTING_ENGINE_REFACTOR:
    # reporting concerns are additive, never inserted into the analysis/
    # resolver pipeline).
    return replace(final_result, market_overview=_build_market_overview(context))
