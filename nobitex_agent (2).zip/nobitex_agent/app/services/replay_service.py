"""Lightweight sequential replay engine.

Feeds candles one at a time (oldest -> newest) into the analysis
pipeline, using ONLY the candles available up to and including the
current step. This is the mechanism used to validate that no detector
or the confluence engine leaks future information — the score, decision,
entry/SL/TP at step i must be reproducible using ONLY candles[0:i+1].
"""

from __future__ import annotations

from dataclasses import dataclass

from app.domain.enums import Direction
from app.domain.models import Candle, ConfluenceBreakdown
from app.indicators.ma import compute_moving_averages
from app.indicators.mfi import compute_mfi
from app.indicators.rsi import compute_rsi
from app.strategy.confluence.engine import compute_confluence
from app.strategy.fibonacci.ote import detect_ote_zone
from app.strategy.fibonacci.premium_discount import detect_premium_discount
from app.strategy.ict.fvg import detect_fvgs
from app.strategy.ict.order_block import detect_order_blocks
from app.strategy.liquidity.liquidity import detect_liquidity_sweeps
from app.strategy.smc.structure import detect_structure_breaks


@dataclass
class ReplayStep:
    index: int
    time: object
    confluence: ConfluenceBreakdown


def replay(candles: list[Candle], min_candles: int = 60) -> list[ReplayStep]:
    """Run the full analysis pipeline at every step i using candles[0:i+1] only."""
    steps: list[ReplayStep] = []

    for i in range(min_candles, len(candles) + 1):
        window = candles[:i]  # <-- the entire lookahead-bias guarantee lives here
        breaks = detect_structure_breaks(window)
        ma_result = compute_moving_averages(window)
        rsi_result = compute_rsi(window)
        mfi_result = compute_mfi(window)
        fvgs = [f for f in detect_fvgs(window) if f.active]
        obs = [ob for ob in detect_order_blocks(window, breaks) if ob.active]
        sweeps = detect_liquidity_sweeps(window)
        latest_sweep = sweeps[-1] if sweeps else None
        ote_zone = detect_ote_zone(window)
        pd_zone = detect_premium_discount(window)

        confluence = compute_confluence(
            htf_structure_breaks=breaks,
            ma_result=ma_result,
            active_order_blocks=obs,
            active_fvgs=fvgs,
            sweep_direction=latest_sweep.direction if latest_sweep else None,
            sweep_reversal_confirmed=latest_sweep.reversal_confirmed if latest_sweep else False,
            ote_zone=ote_zone,
            pd_zone=pd_zone,
            rsi_result=rsi_result,
            mfi_result=mfi_result,
        )
        steps.append(ReplayStep(index=i - 1, time=window[-1].open_time, confluence=confluence))

    return steps


def assert_no_lookahead(candles: list[Candle], step_index: int, min_candles: int = 60) -> bool:
    """Verify that analyzing candles[0:step_index+1] gives the SAME result
    whether or not additional future candles are appended afterward."""
    full_steps = replay(candles, min_candles)
    truncated_steps = replay(candles[: step_index + 1], min_candles)

    if step_index + 1 - min_candles >= len(truncated_steps):
        return True
    a = full_steps[step_index - min_candles]
    b = truncated_steps[-1]
    return a.confluence.total_score == b.confluence.total_score and a.confluence.decision == b.confluence.decision
