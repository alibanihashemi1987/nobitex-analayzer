"""Turns a resolved MarketAnalysisResult into: a persisted audit record
(always), a persisted tradeable Signal (only on BUY/SELL), and a Bale
alert. The dual-direction report format follows REPLACEMENT_MODULE
sections 15-20.

BALE_REPORTING_ENGINE_REFACTOR extension: Bale-facing alerts now use the
Persian `SummaryReportGenerator` (app/reporting/) with an inline
"مشاهده تحلیل کامل" button, instead of the English block below.
`format_market_analysis_report` is kept as-is — it's the English,
developer-facing report used for console/log output (main.py's
`analyze` command still prints it) and is unaffected by this change.
"""

from __future__ import annotations

import time
from datetime import UTC, datetime

from app.charts.chart_generator import generate_signal_chart
from app.core.logging import get_logger
from app.database.db import Database
from app.domain.directional import DirectionalAnalysis, MarketAnalysisResult
from app.domain.enums import ExecutionEligibility, FinalDecision, SignalDecision, TechnicalStatus
from app.domain.models import Candle, ConfluenceBreakdown, Signal
from app.notifications.bale.client import BaleClient
from app.reporting.detailed_report import DetailedReportGenerator
from app.reporting.report_keyboard import ReportKeyboardBuilder
from app.reporting.report_localization import ANALYSIS_NOT_FOUND_MESSAGE
from app.reporting.summary_report import SummaryReportGenerator

logger = get_logger(__name__)

_last_alert_ts: dict[str, float] = {}
_keyboard_builder = ReportKeyboardBuilder()


def _cooldown_active(symbol: str, cooldown_seconds: int) -> bool:
    last = _last_alert_ts.get(symbol)
    if last is None:
        return False
    return (time.monotonic() - last) < cooldown_seconds


def _mark_alerted(symbol: str) -> None:
    _last_alert_ts[symbol] = time.monotonic()


def _format_directional_block(label: str, emoji: str, analysis: DirectionalAnalysis) -> str:
    bd = analysis.score_breakdown
    lines = [
        f"{emoji} {label} SCENARIO",
        "",
        f"Score: {bd.total:.0f}/100",
        f"Status: {analysis.status.value}",
        "",
        f"Structure:        {bd.structure:.0f}/20",
        f"POI:              {bd.poi:.0f}/25",
        f"Liquidity:        {bd.liquidity:.0f}/15",
        f"Momentum:         {bd.momentum:.0f}/10",
        f"MTF:              {bd.mtf:.0f}/10",
        f"Order Book:       {bd.orderbook:.0f}/10",
        f"Execution:        {bd.execution:.0f}/5",
        f"Premium/Discount: {bd.premium_discount:.0f}/5",
        "",
        f"Execution Quality: {analysis.execution_quality:.0f}/5",
        f"Market Risk: {analysis.market_risk.value}",
        f"HTF Alignment: {analysis.htf_alignment.value}",
        f"Technical Status: {analysis.status.value}",
        f"Execution Eligibility: {analysis.execution_eligibility.value}",
    ]
    if analysis.execution_ineligibility_reason:
        lines.append(f"Eligibility Reason: {analysis.execution_ineligibility_reason}")

    if analysis.risk is not None and analysis.status == TechnicalStatus.READY:
        r = analysis.risk
        lines += [
            "",
            f"Entry: {r.entry}",
            f"SL:    {r.stop_loss}",
            f"TP1:   {r.tp1}  (R:R {r.risk_reward_tp1})",
            f"TP2:   {r.tp2}  (R:R {r.risk_reward_tp2})",
            f"TP3:   {r.tp3}  (R:R {r.risk_reward_tp3})",
        ]

    if analysis.rejection_reasons:
        lines.append("")
        lines.append("Reasons:")
        lines.extend(f"\u274c {reason}" for reason in analysis.rejection_reasons)

    lines.append("")
    lines.append(f"Result: {label} {analysis.status.value}")
    return "\n".join(lines)


def format_market_analysis_report(result: MarketAnalysisResult) -> str:
    diff_line = ""
    if result.score_difference is not None:
        diff_line = f"\nDifference: {result.score_difference} points"
        if result.htf_tie_break_used:
            diff_line += " (resolved via HTF tie-breaker)"

    sections = [
        "1. MARKET CONTEXT",
        f"Symbol: {result.symbol}   Timestamp: {result.timestamp.isoformat()}",
        "",
        "2. LONG ANALYSIS",
        _format_directional_block("LONG", "\U0001F7E2", result.long_analysis),
        "",
        "3. SHORT ANALYSIS",
        _format_directional_block("SHORT", "\U0001F534", result.short_analysis),
        "",
        "4. DIRECTION COMPARISON",
        f"LONG {result.long_analysis.score:.0f}/100 — {result.long_analysis.status.value}",
        f"SHORT {result.short_analysis.score:.0f}/100 — {result.short_analysis.status.value}",
        diff_line,
        f"Directional Winner: {result.directional_winner or 'None'}",
        "",
        "5. EXECUTION MODE",
        result.execution_mode.value,
        "",
        "6. FINAL DECISION",
        result.final_decision.value,
        "",
        "7. FINAL REASON",
        result.final_reason,
    ]
    return "\n".join(s for s in sections if s is not None)


def _winning_analysis(result: MarketAnalysisResult) -> DirectionalAnalysis | None:
    if result.directional_winner == "LONG":
        return result.long_analysis
    if result.directional_winner == "SHORT":
        return result.short_analysis
    return None


def build_signal_from_result(result: MarketAnalysisResult, symbol: str, timeframe: str, risk_profile: str) -> Signal | None:
    """Only called when final_decision is BUY or SELL — converts the
    winning DirectionalAnalysis into a tradeable Signal for TP/SL
    outcome tracking (app/tracking/performance_tracker.py)."""
    winning = _winning_analysis(result)
    if winning is None or winning.risk is None:
        return None

    decision = SignalDecision.BUY if result.final_decision == FinalDecision.BUY else SignalDecision.SELL
    confluence = ConfluenceBreakdown(
        component_scores={
            "structure": winning.score_breakdown.structure,
            "poi": winning.score_breakdown.poi,
            "liquidity": winning.score_breakdown.liquidity,
            "momentum": winning.score_breakdown.momentum,
            "mtf": winning.score_breakdown.mtf,
            "orderbook": winning.score_breakdown.orderbook,
            "execution": winning.score_breakdown.execution,
            "premium_discount": winning.score_breakdown.premium_discount,
        },
        total_score=winning.score_breakdown.total,
        decision=decision,
    )
    return Signal(
        symbol=symbol,
        timeframe=timeframe,
        decision=decision,
        risk=winning.risk,
        confluence=confluence,
        created_at=result.timestamp,
        poi_type=winning.primary_poi.poi_type if winning.primary_poi else None,
        risk_profile=risk_profile,
    )


async def process_and_alert(
    result: MarketAnalysisResult,
    db: Database,
    bale: BaleClient | None,
    cooldown_seconds: int,
    timeframe: str,
    risk_profile: str = "moderate",
    chart_candles: list[Candle] | None = None,
) -> str | None:
    """Always persists the full dual-direction AnalysisRecord. If the
    final decision is BUY/SELL, also persists a tradeable Signal and
    sends a Persian Bale alert with a "detailed report" button
    (cooldown-gated). Scheduled scans stay quiet on WAIT/CONFLICT to
    avoid spamming — use `send_summary_report` for a request that
    should always get a Bale message regardless of decision (e.g. a
    user-requested manual analysis)."""
    signal_id: str | None = None

    if result.final_decision in (FinalDecision.BUY, FinalDecision.SELL):
        signal = build_signal_from_result(result, result.symbol, timeframe, risk_profile)
        if signal is not None:
            signal_id = await db.save_signal(signal)

    await db.save_analysis_result(result, risk_profile=risk_profile, linked_signal_id=signal_id)

    if result.final_decision not in (FinalDecision.BUY, FinalDecision.SELL):
        return signal_id

    if _cooldown_active(result.symbol, cooldown_seconds):
        logger.info("alert_suppressed_cooldown", symbol=result.symbol)
        return signal_id

    _mark_alerted(result.symbol)

    if bale is not None:
        await _send_bale_summary(result, bale, risk_profile, chart_candles)

    return signal_id


async def send_summary_report(
    result: MarketAnalysisResult,
    db: Database,
    bale: BaleClient | None,
    risk_profile: str = "moderate",
    chart_candles: list[Candle] | None = None,
) -> None:
    """Send the Persian Summary Report to Bale unconditionally — BUY,
    SELL, WAIT, or CONFLICT. Used for user-requested analysis (section 4:
    the Summary Report must be sent after a user-requested analysis
    regardless of the resulting decision, unlike the cooldown-gated,
    BUY/SELL-only auto-alert in `process_and_alert`). Also persists the
    AnalysisRecord (idempotent — same analysis_id as any other call for
    this same result) so the report's "مشاهده تحلیل کامل" button works
    immediately."""
    await db.save_analysis_result(result, risk_profile=risk_profile, linked_signal_id=None)
    if bale is not None:
        await _send_bale_summary(result, bale, risk_profile, chart_candles)


async def _send_bale_summary(
    result: MarketAnalysisResult,
    bale: BaleClient,
    risk_profile: str,
    chart_candles: list[Candle] | None,
) -> None:
    report = SummaryReportGenerator().generate(result, risk_profile)
    keyboard = _keyboard_builder.detailed_analysis_button(result.analysis_id)
    try:
        if chart_candles:
            winning = _winning_analysis(result)
            chart_bytes = generate_signal_chart(
                chart_candles, winning.risk if winning else None,
                title=f"{result.symbol} \u2014 {result.final_decision.value}",
            )
            await bale.send_photo(chart_bytes, caption=report[:1024], reply_markup=keyboard)
        else:
            await bale.send_message(report, reply_markup=keyboard)
    except Exception:
        logger.exception("bale_alert_failed", symbol=result.symbol)


async def handle_detailed_report_request(
    analysis_id: str,
    db: Database,
    bale: BaleClient | None,
    risk_profile: str = "moderate",
) -> str:
    """Section 10: the callback/intent handler for the Detailed Report.
    Looks up the stored analysis by `analysis_id` (no recomputation —
    see app/database/serialization.py), generates the Persian Detailed
    Report, sends it to Bale if a client is provided, and always returns
    the report text (useful for tests / non-Bale callers). Returns the
    Persian "not found" message (never raises) if the analysis is
    missing or too old to have full-fidelity data."""
    stored = await db.get_stored_market_analysis_result(analysis_id)
    if stored is None:
        if bale is not None:
            try:
                await bale.send_message(ANALYSIS_NOT_FOUND_MESSAGE)
            except Exception:
                logger.exception("bale_not_found_message_failed", analysis_id=analysis_id)
        return ANALYSIS_NOT_FOUND_MESSAGE

    report = DetailedReportGenerator().generate(stored, risk_profile)
    if bale is not None:
        try:
            await bale.send_message(report)
        except Exception:
            logger.exception("bale_detailed_report_failed", analysis_id=analysis_id)
    return report
