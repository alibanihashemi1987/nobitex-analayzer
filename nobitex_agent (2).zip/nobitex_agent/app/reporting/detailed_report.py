"""Detailed Report — the full Persian report, sent only on request.

CRITICAL (section 10): `generate()` takes an already-built/reconstructed
`MarketAnalysisResult` and does nothing but format it. It never calls
`evaluate_long`/`evaluate_short`, never fetches market data, and never
touches the scoring engine. Whether that `MarketAnalysisResult` came
straight from a live analysis or was reconstructed from a stored
`AnalysisRecord` (see `app/database/serialization.py`) is invisible to
this generator — both are the same domain object.
"""

from __future__ import annotations

from app.domain.directional import DirectionalAnalysis, MarketAnalysisResult
from app.domain.enums import TechnicalStatus
from app.domain.events import ScoreFactor
from app.reporting.report_formatter import (
    SEPARATOR,
    build_persian_final_reason,
    fmt_price,
    fmt_rr,
    poi_summary_line,
    rejection_reason_lines,
    risk_plan_lines,
    translate_reason,
)
from app.reporting.report_localization import (
    CATEGORY_LABEL,
    EXECUTION_ELIGIBILITY_LABEL,
    EXECUTION_MODE_LABEL,
    FACTOR_NAME_LABEL,
    FINAL_DECISION_LABEL,
    HTF_ALIGNMENT_LABEL,
    MARKET_RISK_LABEL,
    MITIGATION_STATUS_LABEL,
    POI_TYPE_LABEL,
    RISK_PROFILE_LABEL,
    TECHNICAL_STATUS_LABEL,
    TREND_LABEL,
)

_CATEGORY_ORDER = (
    "structure", "poi", "liquidity", "momentum", "mtf", "orderbook", "execution", "premium_discount",
)


class DetailedReportGenerator:
    def generate(self, result: MarketAnalysisResult, risk_profile: str = "moderate") -> str:
        sections: list[str] = []
        sections += self._header(result, risk_profile)
        sections += self._market_overview_section(result)
        sections += self._directional_section(
            "\U0001F7E2", "\u062e\u0631\u06cc\u062f (LONG)", result.long_analysis
        )
        sections += self._directional_section(
            "\U0001F534", "\u0641\u0631\u0648\u0634 (SHORT)", result.short_analysis
        )
        sections += self._comparison_section(result)
        sections += self._decision_logic_section(result)
        sections += self._invalidation_section(result)
        sections += self._final_section(result)
        return "\n".join(sections)

    # --- 1. Header / market context -----------------------------------
    def _header(self, result: MarketAnalysisResult, risk_profile: str) -> list[str]:
        return [
            "\U0001F4CA \u06af\u0632\u0627\u0631\u0634 \u062c\u0627\u0645\u0639 \u062a\u062d\u0644\u06cc\u0644 \u0628\u0627\u0632\u0627\u0631",
            SEPARATOR, "",
            f"\u0646\u0645\u0627\u062f: {result.symbol}",
            f"\u062d\u0627\u0644\u062a \u0645\u0639\u0627\u0645\u0644\u0647: {EXECUTION_MODE_LABEL[result.execution_mode]}",
            f"\u067e\u0631\u0648\u0641\u0627\u06cc\u0644 \u0631\u06cc\u0633\u06a9: {RISK_PROFILE_LABEL.get(risk_profile, risk_profile)}",
            f"\u0632\u0645\u0627\u0646 \u062a\u062d\u0644\u06cc\u0644: {result.timestamp.strftime('%Y-%m-%d %H:%M UTC')}",
            f"\u0634\u0646\u0627\u0633\u0647 \u062a\u062d\u0644\u06cc\u0644: {result.analysis_id}",
            "",
        ]

    # --- 2. Market overview ---------------------------------------------
    def _market_overview_section(self, result: MarketAnalysisResult) -> list[str]:
        lines = [
            SEPARATOR,
            "\U0001F310 \u06f1. \u0648\u0636\u0639\u06cc\u062a \u06a9\u0644\u06cc \u0628\u0627\u0632\u0627\u0631",
            SEPARATOR, "",
        ]
        ov = result.market_overview
        if ov is None:
            lines.append("\u2014")
            lines.append("")
            return lines

        lines.append(f"\u062c\u0647\u062a \u063a\u0627\u0644\u0628 \u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 \u0628\u0627\u0644\u0627: {TREND_LABEL[ov.htf.trend]}")
        lines.append("")
        for tf in (ov.htf, ov.mtf, ov.ltf, ov.execution):
            lines.append(f"{tf.timeframe}:")
            lines.append(f"\u0631\u0648\u0646\u062f: {TREND_LABEL[tf.trend]}")
            lines.append("")

        if ov.price_above_ma200 is not None:
            side = "\u0628\u0627\u0644\u0627\u062a\u0631" if ov.price_above_ma200.value == "BULLISH" else "\u067e\u0627\u06cc\u06cc\u0646\u200c\u062a\u0631"
            lines.append(f"MA200:\n\u0642\u06cc\u0645\u062a {side} \u0627\u0632 MA200")
        if ov.ma20_above_ma200 is not None:
            rel = "\u0628\u0627\u0644\u0627\u062a\u0631 \u0627\u0632" if ov.ma20_above_ma200 else "\u067e\u0627\u06cc\u06cc\u0646\u200c\u062a\u0631 \u0627\u0632"
            lines.append(f"\nMA20:\n{rel} MA200")
        lines.append("")
        return lines

    # --- 3-4-... per-direction section ----------------------------------
    def _directional_section(self, emoji: str, label: str, analysis: DirectionalAnalysis) -> list[str]:
        lines = [
            SEPARATOR, f"{emoji} \u0633\u0646\u0627\u0631\u06cc\u0648\u06cc \u06a9\u0627\u0645\u0644 {label}", SEPARATOR, "",
            f"\u0627\u0645\u062a\u06cc\u0627\u0632: {analysis.score:.0f}/100",
            f"\u0648\u0636\u0639\u06cc\u062a \u0641\u0646\u06cc: {TECHNICAL_STATUS_LABEL[analysis.status]}",
            f"\u0627\u0645\u06a9\u0627\u0646 \u0627\u062c\u0631\u0627: {EXECUTION_ELIGIBILITY_LABEL[analysis.execution_eligibility]}",
            f"\u0631\u06cc\u0633\u06a9: {MARKET_RISK_LABEL[analysis.market_risk]}",
            f"\u06a9\u06cc\u0641\u06cc\u062a \u0648\u0631\u0648\u062f: {analysis.execution_quality:.0f}/5",
            "",
        ]
        if analysis.execution_ineligibility_reason:
            lines.append(f"\u062f\u0644\u06cc\u0644 \u0639\u062f\u0645 \u0627\u0645\u06a9\u0627\u0646 \u0627\u062c\u0631\u0627: {translate_reason(analysis.execution_ineligibility_reason)}")
            lines.append("")

        lines += self._scoring_breakdown_lines(analysis)
        lines += self._poi_lines(analysis)
        lines += self._momentum_lines(analysis)
        lines += self._ltf_confirmation_lines(analysis)

        if analysis.risk is not None:
            lines.append("\U0001F4CD \u0628\u0631\u0646\u0627\u0645\u0647 \u0627\u062c\u0631\u0627:")
            lines.append("")
            lines += risk_plan_lines(analysis.risk)
            lines.append("")

        if analysis.rejection_reasons:
            lines.append("\u0645\u0648\u0627\u0646\u0639 \u0648\u0631\u0648\u062f:")
            lines += rejection_reason_lines(analysis.rejection_reasons)
            lines.append("")

        return lines

    def _scoring_breakdown_lines(self, analysis: DirectionalAnalysis) -> list[str]:
        bd = analysis.score_breakdown
        lines = ["\U0001F4C8 \u0627\u0645\u062a\u06cc\u0627\u0632\u062f\u0647\u06cc:", ""]
        maxima = {
            "structure": 20, "poi": 25, "liquidity": 15, "momentum": 10,
            "mtf": 10, "orderbook": 10, "execution": 5, "premium_discount": 5,
        }
        for cat in _CATEGORY_ORDER:
            value = getattr(bd, cat)
            lines.append(f"{CATEGORY_LABEL[cat]}: {value:.0f}/{maxima[cat]}")
        lines.append("")
        lines.append(f"\u0645\u062c\u0645\u0648\u0639: {bd.total:.0f}/100")
        lines.append("")
        if bd.factors:
            lines.append("\u062c\u0632\u0626\u06cc\u0627\u062a \u0627\u0645\u062a\u06cc\u0627\u0632\u062f\u0647\u06cc:")
            for f in bd.factors:
                lines.append(self._factor_line(f))
            lines.append("")
        return lines

    @staticmethod
    def _factor_line(f: ScoreFactor) -> str:
        # Only the Persian factor name + points-awarded are shown here —
        # the factor's `evidence` field is free-form English prose
        # generated by the (deliberately English-only) analysis engine,
        # so it is intentionally NOT surfaced in the Bale report (section
        # 1: "Do NOT generate English prose inside the report"). Full
        # traceability by factor_id/points is preserved; sentence-level
        # rationale is available via the English console/log report
        # (app/services/signal_service.py:format_market_analysis_report)
        # for operators who need it.
        name_fa = FACTOR_NAME_LABEL.get(f.factor_id, f.name)
        return f"\u2022 {name_fa}: {f.awarded_points:.0f}/{f.maximum_points:.0f}"

    def _poi_lines(self, analysis: DirectionalAnalysis) -> list[str]:
        lines = ["\U0001F3AF \u0646\u0642\u0637\u0647 \u0645\u0648\u0631\u062f \u062a\u0648\u062c\u0647:", ""]
        poi = analysis.primary_poi
        if poi is None:
            lines.append("\u2014")
            lines.append("")
            return lines
        lines.append(f"\u0646\u0648\u0639: {POI_TYPE_LABEL.get(poi.poi_type, poi.poi_type)}")
        lines.append(f"\u0648\u0636\u0639\u06cc\u062a: {MITIGATION_STATUS_LABEL.get(poi.mitigation_status, poi.mitigation_status)}")
        lines.append(f"\u0645\u062d\u062f\u0648\u062f\u0647: {fmt_price(poi.zone_low)} \u062a\u0627 {fmt_price(poi.zone_high)}")
        lines.append("")
        return lines

    def _momentum_lines(self, analysis: DirectionalAnalysis) -> list[str]:
        lines = ["\U0001F4CA \u0645\u0648\u0645\u0646\u062a\u0648\u0645:", ""]
        momentum_factors = [f for f in analysis.score_breakdown.factors if f.category == "momentum"]
        if not momentum_factors:
            lines.append("\u2014")
        for f in momentum_factors:
            name_fa = FACTOR_NAME_LABEL.get(f.factor_id, f.name)
            lines.append(f"{name_fa}: {f.awarded_points:.0f}/{f.maximum_points:.0f}")
        lines.append("")
        return lines

    def _ltf_confirmation_lines(self, analysis: DirectionalAnalysis) -> list[str]:
        lines = ["\u23F1 \u062a\u0623\u06cc\u06cc\u062f \u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 \u067e\u0627\u06cc\u06cc\u0646:", ""]
        mtf_factors = [f for f in analysis.score_breakdown.factors if f.category == "mtf"]
        if not mtf_factors:
            lines.append("\u2014")
        for f in mtf_factors:
            name_fa = FACTOR_NAME_LABEL.get(f.factor_id, f.name)
            lines.append(f"{name_fa}: {f.awarded_points:.0f}/{f.maximum_points:.0f}")
        if analysis.early_ltf_entry:
            lines.append(
                "\u26A0\uFE0F \u0648\u0631\u0648\u062f \u0632\u0648\u062f\u0647\u0646\u06af\u0627\u0645 "
                "(EARLY_LTF_ENTRY) \u2014 \u062a\u0627\u06cc\u06cc\u062f \u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 "
                "\u0628\u0627\u0644\u0627 \u0647\u0646\u0648\u0632 \u06a9\u0627\u0645\u0644 \u0646\u0634\u062f\u0647 \u0627\u0633\u062a."
            )
        lines.append("")
        return lines

    # --- Comparison -------------------------------------------------------
    def _comparison_section(self, result: MarketAnalysisResult) -> list[str]:
        long_a, short_a = result.long_analysis, result.short_analysis
        lines = [
            SEPARATOR, "\u2696\uFE0F \u0645\u0642\u0627\u06cc\u0633\u0647 \u062e\u0631\u06cc\u062f \u0648 \u0641\u0631\u0648\u0634", SEPARATOR, "",
            f"\U0001F7E2 \u062e\u0631\u06cc\u062f: {long_a.score:.0f}/100 \u2014 {TECHNICAL_STATUS_LABEL[long_a.status]}",
            f"\U0001F534 \u0641\u0631\u0648\u0634: {short_a.score:.0f}/100 \u2014 {TECHNICAL_STATUS_LABEL[short_a.status]}",
            "",
        ]
        if result.score_difference is not None:
            lines.append(f"\u0627\u062e\u062a\u0644\u0627\u0641: {result.score_difference:.0f}")
            lines.append("")
        lines.append("\u0647\u0645\u200c\u0631\u0627\u0633\u062a\u0627\u06cc\u06cc HTF:")
        lines.append(f"\u062e\u0631\u06cc\u062f: {HTF_ALIGNMENT_LABEL[long_a.htf_alignment]}")
        lines.append(f"\u0641\u0631\u0648\u0634: {HTF_ALIGNMENT_LABEL[short_a.htf_alignment]}")
        lines.append("")
        lines.append("\u06a9\u06cc\u0641\u06cc\u062a \u0648\u0631\u0648\u062f:")
        lines.append(f"\u062e\u0631\u06cc\u062f: {long_a.execution_quality:.0f}/5")
        lines.append(f"\u0641\u0631\u0648\u0634: {short_a.execution_quality:.0f}/5")
        lines.append("")
        return lines

    # --- Decision logic -----------------------------------------------
    def _decision_logic_section(self, result: MarketAnalysisResult) -> list[str]:
        return [
            SEPARATOR, "\U0001F9E0 \u0645\u0646\u0637\u0642 \u062a\u0635\u0645\u06cc\u0645", SEPARATOR, "",
            build_persian_final_reason(result), "",
        ]

    # --- Invalidation ----------------------------------------------------
    def _invalidation_section(self, result: MarketAnalysisResult) -> list[str]:
        winning = None
        if result.directional_winner == "LONG":
            winning = result.long_analysis
        elif result.directional_winner == "SHORT":
            winning = result.short_analysis

        lines = [SEPARATOR, "\u26A0\uFE0F \u0634\u0631\u0627\u06cc\u0637 \u0627\u0628\u0637\u0627\u0644", SEPARATOR, ""]
        if winning is None or winning.risk is None:
            lines.append(
                "\u062f\u0631 \u062d\u0627\u0644\u062a WAIT/CONFLICT \u0645\u0648\u0642\u0639\u06cc\u062a\u06cc "
                "\u0628\u0631\u0627\u06cc \u0627\u0628\u0637\u0627\u0644 \u0648\u062c\u0648\u062f \u0646\u062f\u0627\u0631\u062f."
            )
        else:
            lines.append(
                f"\u0628\u0627 \u0631\u0633\u06cc\u062f\u0646 \u0642\u06cc\u0645\u062a \u0628\u0647 "
                f"\u062d\u062f \u0636\u0631\u0631 ({fmt_price(winning.risk.stop_loss)}) "
                f"\u0633\u0646\u0627\u0631\u06cc\u0648 \u0628\u0627\u0637\u0644 \u062a\u0644\u0642\u06cc "
                f"\u0645\u06cc\u200c\u0634\u0648\u062f."
            )
            if winning.primary_poi is not None:
                lines.append(
                    f"\u0634\u06a9\u0633\u062a\u0646 \u0633\u0627\u062e\u062a\u0627\u0631 "
                    f"\u0646\u0642\u0637\u0647 \u0645\u0648\u0631\u062f \u062a\u0648\u062c\u0647 "
                    f"({POI_TYPE_LABEL.get(winning.primary_poi.poi_type, winning.primary_poi.poi_type)}) "
                    f"\u0646\u06cc\u0632 \u0645\u06cc\u200c\u062a\u0648\u0627\u0646\u062f \u0627\u06cc\u0646 "
                    f"\u0633\u0646\u0627\u0631\u06cc\u0648 \u0631\u0627 \u0628\u06cc\u200c\u0627\u0639\u062a\u0628\u0627\u0631 "
                    f"\u06a9\u0646\u062f."
                )
        lines.append("")
        return lines

    # --- Final -------------------------------------------------------
    def _final_section(self, result: MarketAnalysisResult) -> list[str]:
        lines = [SEPARATOR, "\U0001F3AF \u0646\u062a\u06cc\u062c\u0647 \u0646\u0647\u0627\u06cc\u06cc", SEPARATOR, ""]
        lines.append(FINAL_DECISION_LABEL[result.final_decision])
        lines.append("")
        lines.append(f"\u062f\u0644\u06cc\u0644: {build_persian_final_reason(result)}")
        lines.append("")
        lines.append(f"\u0648\u0636\u0639\u06cc\u062a \u0641\u0646\u06cc: {result.directional_winner or '\u2014'}")
        lines.append(f"\u0633\u0637\u062d \u0631\u06cc\u0633\u06a9: {MARKET_RISK_LABEL[result.long_analysis.market_risk] if result.directional_winner == 'LONG' else MARKET_RISK_LABEL[result.short_analysis.market_risk] if result.directional_winner == 'SHORT' else '\u2014'}")
        return lines
