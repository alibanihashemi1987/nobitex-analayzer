"""Summary Report — the concise, automatically-sent Bale message.

Sent after every scheduled/user-requested analysis (section 4). Never
sends the Detailed Report. Always shows both LONG and SHORT, even for
WAIT (section 6) and CONFLICT (section 8), and distinguishes Technical
Status from Execution Eligibility (section 7).
"""

from __future__ import annotations

from app.domain.directional import DirectionalAnalysis, MarketAnalysisResult
from app.domain.enums import ExecutionMode, FinalDecision, TechnicalStatus
from app.reporting.report_formatter import (
    SEPARATOR,
    build_persian_final_reason,
    fmt_price,
    poi_summary_line,
    short_status_line,
    translate_reason,
)
from app.reporting.report_localization import (
    EXECUTION_ELIGIBILITY_LABEL,
    EXECUTION_MODE_LABEL,
    FINAL_DECISION_LABEL,
    HTF_ALIGNMENT_LABEL,
    RISK_PROFILE_LABEL,
    TECHNICAL_STATUS_LABEL,
    TREND_LABEL,
)


class SummaryReportGenerator:
    def generate(self, result: MarketAnalysisResult, risk_profile: str = "moderate") -> str:
        lines: list[str] = []
        lines += self._header(result, risk_profile)
        lines += self._market_overview_block(result)
        lines.append(SEPARATOR)
        lines += self._directional_block(
            "\U0001F7E2 \u0633\u0646\u0627\u0631\u06cc\u0648\u06cc \u062e\u0631\u06cc\u062f", result.long_analysis
        )
        lines.append(SEPARATOR)
        lines += self._directional_block(
            "\U0001F534 \u0633\u0646\u0627\u0631\u06cc\u0648\u06cc \u0641\u0631\u0648\u0634", result.short_analysis
        )
        lines.append(SEPARATOR)
        lines += self._comparison_block(result)
        lines.append(SEPARATOR)
        lines += self._final_decision_block(result)
        return "\n".join(lines)

    def _header(self, result: MarketAnalysisResult, risk_profile: str) -> list[str]:
        return [
            f"\U0001F4CA \u062a\u062d\u0644\u06cc\u0644 {result.symbol}",
            SEPARATOR,
            "",
            f"\U0001F550 \u0632\u0645\u0627\u0646: {result.timestamp.strftime('%Y-%m-%d %H:%M UTC')}",
            f"\u2699\uFE0F \u062d\u0627\u0644\u062a \u0645\u0639\u0627\u0645\u0644\u0647: {EXECUTION_MODE_LABEL[result.execution_mode]}",
            f"\U0001F3AF \u067e\u0631\u0648\u0641\u0627\u06cc\u0644 \u0631\u06cc\u0633\u06a9: {RISK_PROFILE_LABEL.get(risk_profile, risk_profile)}",
            "",
        ]

    def _market_overview_block(self, result: MarketAnalysisResult) -> list[str]:
        ov = result.market_overview
        lines = ["\U0001F310 \u0648\u0636\u0639\u06cc\u062a \u0628\u0627\u0632\u0627\u0631", ""]
        if ov is None:
            lines.append("\u2014")
            return lines
        lines.append(
            "\u0631\u0648\u0646\u062f \u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 \u0628\u0627\u0644\u0627:"
        )
        lines.append(TREND_LABEL[ov.htf.trend])
        lines.append("")
        for tf in (ov.htf, ov.mtf, ov.ltf, ov.execution):
            lines.append(f"{tf.timeframe}: {TREND_LABEL[tf.trend]}")
        return lines

    def _directional_block(self, label: str, analysis: DirectionalAnalysis) -> list[str]:
        lines = [
            label, "",
            f"\u0627\u0645\u062a\u06cc\u0627\u0632: {analysis.score:.0f}/100",
            f"\u0648\u0636\u0639\u06cc\u062a \u0641\u0646\u06cc: {TECHNICAL_STATUS_LABEL[analysis.status]}",
            f"\u0627\u0645\u06a9\u0627\u0646 \u0627\u062c\u0631\u0627: {EXECUTION_ELIGIBILITY_LABEL[analysis.execution_eligibility]}",
            "",
            f"\u0646\u0642\u0637\u0647 \u0645\u0648\u0631\u062f \u062a\u0648\u062c\u0647: {poi_summary_line(analysis.primary_poi)}",
            f"\u0647\u0645\u200c\u0631\u0627\u0633\u062a\u0627\u06cc\u06cc HTF: {HTF_ALIGNMENT_LABEL[analysis.htf_alignment]}",
            f"\u06a9\u06cc\u0641\u06cc\u062a \u0648\u0631\u0648\u062f: {analysis.execution_quality:.0f}/5",
        ]
        return lines

    def _comparison_block(self, result: MarketAnalysisResult) -> list[str]:
        lines = [
            "\u2696\uFE0F \u0645\u0642\u0627\u06cc\u0633\u0647 \u062f\u0648 \u0633\u0646\u0627\u0631\u06cc\u0648", "",
            short_status_line("\u062e\u0631\u06cc\u062f", "\U0001F7E2", result.long_analysis),
            short_status_line("\u0641\u0631\u0648\u0634", "\U0001F534", result.short_analysis),
            "",
            "\u0628\u0631\u062a\u0631\u06cc:",
        ]
        winner_fa = {
            "LONG": "\u062e\u0631\u06cc\u062f",
            "SHORT": "\u0641\u0631\u0648\u0634",
            None: "\u0647\u06cc\u0686\u200c\u06a9\u062f\u0627\u0645 / \u062a\u0639\u0627\u0631\u0636",
        }
        lines.append(winner_fa.get(result.directional_winner, "\u0647\u06cc\u0686\u200c\u06a9\u062f\u0627\u0645"))
        return lines

    def _final_decision_block(self, result: MarketAnalysisResult) -> list[str]:
        lines = [
            "\U0001F3AF \u0646\u062a\u06cc\u062c\u0647 \u0646\u0647\u0627\u06cc\u06cc", "",
            FINAL_DECISION_LABEL[result.final_decision],
        ]

        if result.final_decision == FinalDecision.WAIT:
            lines += self._wait_specific_lines(result)
        elif result.final_decision == FinalDecision.CONFLICT:
            lines += self._conflict_specific_lines(result)
        else:
            winning = result.long_analysis if result.directional_winner == "LONG" else result.short_analysis
            if winning.risk is not None:
                lines.append("")
                lines.append(f"\u0648\u0631\u0648\u062f: {fmt_price(winning.risk.entry)}")
                lines.append(f"\u062d\u062f \u0636\u0631\u0631: {fmt_price(winning.risk.stop_loss)}")
                lines.append(f"\u0647\u062f\u0641 \u0627\u0648\u0644: {fmt_price(winning.risk.tp1)}")
                lines.append(f"\u0647\u062f\u0641 \u062f\u0648\u0645: {fmt_price(winning.risk.tp2)}")

        lines.append("")
        lines.append("\u062f\u0644\u06cc\u0644:")
        lines.append(build_persian_final_reason(result))
        return lines

    def _wait_specific_lines(self, result: MarketAnalysisResult) -> list[str]:
        """Section 6: WAIT must never look like only LONG was checked."""
        lines = ["", short_status_line("\u062e\u0631\u06cc\u062f", "\U0001F7E2", result.long_analysis)]
        lines.append(short_status_line("\u0641\u0631\u0648\u0634", "\U0001F534", result.short_analysis))
        # A READY-but-not-eligible side (e.g. SPOT-blocked SHORT) gets an
        # explicit note so it's never confused with NOT_READY (section 7).
        for label, analysis in (
            ("\u062e\u0631\u06cc\u062f", result.long_analysis),
            ("\u0641\u0631\u0648\u0634", result.short_analysis),
        ):
            if (
                analysis.status == TechnicalStatus.READY
                and analysis.execution_ineligibility_reason
            ):
                lines.append("")
                lines.append(
                    f"\u26A0\uFE0F {label} \u0627\u0632 \u0646\u0638\u0631 \u062a\u06a9\u0646\u06cc\u06a9\u0627\u0644 "
                    f"\u0622\u0645\u0627\u062f\u0647 \u0627\u0633\u062a \u0627\u0645\u0627 "
                    f"{translate_reason(analysis.execution_ineligibility_reason)}"
                )
        lines.append("")
        lines.append(
            "\u23F3 \u0633\u06cc\u0633\u062a\u0645 \u0645\u0646\u062a\u0638\u0631 \u062a\u0634\u06a9\u06cc\u0644 "
            "\u0645\u0648\u0642\u0639\u06cc\u062a \u0645\u0639\u062a\u0628\u0631 \u0627\u0633\u062a."
        )
        return lines

    def _conflict_specific_lines(self, result: MarketAnalysisResult) -> list[str]:
        lines = ["", short_status_line("\u062e\u0631\u06cc\u062f", "\U0001F7E2", result.long_analysis)]
        lines.append(short_status_line("\u0641\u0631\u0648\u0634", "\U0001F534", result.short_analysis))
        if result.score_difference is not None:
            lines.append("")
            lines.append(f"\u0627\u062e\u062a\u0644\u0627\u0641: {result.score_difference:.0f} \u0627\u0645\u062a\u06cc\u0627\u0632")
        lines.append("")
        lines.append(
            "\u0633\u0627\u062e\u062a\u0627\u0631 \u0628\u0627\u0632\u0627\u0631 \u0628\u0631\u062a\u0631\u06cc "
            "\u0642\u0637\u0639\u06cc \u06cc\u06a9\u06cc \u0627\u0632 \u062f\u0648 \u062c\u0647\u062a \u0631\u0627 "
            "\u062a\u0623\u06cc\u06cc\u062f \u0646\u0645\u06cc\u200c\u06a9\u0646\u062f."
        )
        lines.append("")
        lines.append(
            "\u23F3 \u067e\u06cc\u0634\u0646\u0647\u0627\u062f \u0633\u06cc\u0633\u062a\u0645: "
            "\u0641\u0639\u0644\u0627\u064b \u0627\u0632 \u0648\u0631\u0648\u062f \u062e\u0648\u062f\u062f\u0627\u0631\u06cc \u0634\u0648\u062f."
        )
        return lines
