"""Recognizes a Persian text request for the Detailed Report.

Section 9 Option B: users may type a phrase instead of pressing the
button. This is intentionally a plain substring match against a small,
explicit phrase list (`report_localization.DETAILED_REPORT_INTENT_PHRASES`)
rather than a second analysis/NLU pipeline — "Do not hard-code a second
analysis flow for these commands."
"""

from __future__ import annotations

from app.reporting.report_localization import DETAILED_REPORT_INTENT_PHRASES


def is_detailed_report_request(text: str) -> bool:
    if not text:
        return False
    normalized = " ".join(text.split()).strip()
    return any(phrase in normalized for phrase in DETAILED_REPORT_INTENT_PHRASES)
