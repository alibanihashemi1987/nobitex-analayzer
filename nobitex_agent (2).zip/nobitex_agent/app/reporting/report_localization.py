"""Persian localization tables for user-facing Bale reports.

Per BALE_REPORTING_ENGINE_REFACTOR section 1: internal identifiers
(enum values, class/field names) stay English everywhere else in the
codebase. This module is the ONE place that maps them to the Persian
text a Bale report actually shows. Nothing here should be imported by
`app/domain`, `app/strategy`, `app/risk`, or any other analysis module —
it is presentation-only and consumed exclusively by `app/reporting/`.
"""

from __future__ import annotations

from app.domain.enums import (
    Direction,
    ExecutionEligibility,
    ExecutionMode,
    FinalDecision,
    HTFAlignmentStrength,
    MarketRiskLevel,
    TechnicalStatus,
)

DIRECTION_LABEL = {
    "LONG": "\u062e\u0631\u06cc\u062f (LONG)",
    "SHORT": "\u0641\u0631\u0648\u0634 (SHORT)",
}
DIRECTION_EMOJI = {"LONG": "\U0001F7E2", "SHORT": "\U0001F534"}

TREND_LABEL: dict[Direction | None, str] = {
    Direction.BULLISH: "\U0001F7E2 \u0635\u0639\u0648\u062f\u06cc",
    Direction.BEARISH: "\U0001F534 \u0646\u0632\u0648\u0644\u06cc",
    None: "\U0001F7E1 \u062e\u0646\u062b\u06cc",
}

TECHNICAL_STATUS_LABEL = {
    TechnicalStatus.READY: "\u2705 \u0622\u0645\u0627\u062f\u0647",
    TechnicalStatus.NOT_READY: "\u274C \u0622\u0645\u0627\u062f\u0647 \u0646\u06cc\u0633\u062a",
    TechnicalStatus.INVALID: "\u26A0\uFE0F \u0646\u0627\u0645\u0639\u062a\u0628\u0631",
}
# Short form used inline in the WAIT block ("73/100 | آماده نیست").
TECHNICAL_STATUS_SHORT = {
    TechnicalStatus.READY: "\u0622\u0645\u0627\u062f\u0647",
    TechnicalStatus.NOT_READY: "\u0622\u0645\u0627\u062f\u0647 \u0646\u06cc\u0633\u062a",
    TechnicalStatus.INVALID: "\u0646\u0627\u0645\u0639\u062a\u0628\u0631",
}

EXECUTION_ELIGIBILITY_LABEL = {
    ExecutionEligibility.ELIGIBLE: "\u2705 \u0645\u062c\u0627\u0632",
    ExecutionEligibility.NOT_ELIGIBLE: "\u274C \u063a\u06cc\u0631\u0645\u062c\u0627\u0632",
    ExecutionEligibility.UNKNOWN: "\u2753 \u0646\u0627\u0645\u0634\u062e\u0635",
}

MARKET_RISK_LABEL = {
    MarketRiskLevel.LOW: "\U0001F7E2 \u067e\u0627\u06cc\u06cc\u0646",
    MarketRiskLevel.MEDIUM: "\U0001F7E1 \u0645\u062a\u0648\u0633\u0637",
    MarketRiskLevel.HIGH: "\U0001F7E0 \u0628\u0627\u0644\u0627",
    MarketRiskLevel.CRITICAL: "\U0001F534 \u0628\u062d\u0631\u0627\u0646\u06cc",
}

HTF_ALIGNMENT_LABEL = {
    HTFAlignmentStrength.STRONG: "\u0642\u0648\u06cc",
    HTFAlignmentStrength.MODERATE: "\u0645\u062a\u0648\u0633\u0637",
    HTFAlignmentStrength.WEAK: "\u0636\u0639\u06cc\u0641",
    HTFAlignmentStrength.NEUTRAL: "\u062e\u0646\u062b\u06cc",
    HTFAlignmentStrength.OPPOSITE: "\u0645\u062e\u0627\u0644\u0641",
}

EXECUTION_MODE_LABEL = {
    ExecutionMode.SPOT: "\u0627\u0633\u067e\u0627\u062a",
    ExecutionMode.COMMITMENT: "\u062a\u0639\u0647\u062f\u06cc",
}

FINAL_DECISION_LABEL = {
    FinalDecision.BUY: "\U0001F7E2 \u062e\u0631\u06cc\u062f (BUY)",
    FinalDecision.SELL: "\U0001F534 \u0641\u0631\u0648\u0634 (SELL)",
    FinalDecision.WAIT: "\u23F8 \u0645\u0646\u062a\u0638\u0631 \u0628\u0645\u0627\u0646\u06cc\u062f (WAIT)",
    FinalDecision.CONFLICT: "\u26A0\uFE0F \u062a\u0639\u0627\u0631\u0636 (CONFLICT)",
}

RISK_PROFILE_LABEL = {
    "conservative": "\u0645\u062d\u0627\u0641\u0638\u0647\u200c\u06a9\u0627\u0631\u0627\u0646\u0647",
    "moderate": "\u0645\u062a\u0648\u0633\u0637",
    "aggressive": "\u062a\u0647\u0627\u062c\u0645\u06cc",
}

# POI type -> Persian label with the English term kept alongside, per
# spec section 1's examples ("بلوک سفارش (Order Block)").
POI_TYPE_LABEL = {
    "LIQUIDITY_SWEEP_STRUCTURAL_SHIFT": "\u062c\u0627\u0631\u0648\u0628 \u0646\u0642\u062f\u06cc\u0646\u06af\u06cc \u0648 \u062a\u063a\u06cc\u06cc\u0631 \u0633\u0627\u062e\u062a\u0627\u0631",
    "ORDER_BLOCK": "\u0628\u0644\u0648\u06a9 \u0633\u0641\u0627\u0631\u0634 (Order Block)",
    "BREAKER_BLOCK": "\u0628\u0644\u0648\u06a9 \u0634\u06a9\u0633\u062a (Breaker Block)",
    "FVG": "\u0634\u06a9\u0627\u0641 \u0627\u0631\u0632\u0634 \u0645\u0646\u0635\u0641\u0627\u0646\u0647 (FVG)",
    "OTE": "\u0645\u0646\u0637\u0642\u0647 \u0648\u0631\u0648\u062f \u0628\u0647\u06cc\u0646\u0647 (OTE)",
    "MITIGATION_BLOCK": "\u0628\u0644\u0648\u06a9 \u062a\u0639\u062f\u06cc\u0644 (Mitigation Block)",
    "VOLUME_IMBALANCE": "\u0639\u062f\u0645 \u062a\u0639\u0627\u062f\u0644 \u062d\u062c\u0645 (Volume Imbalance)",
    "DYNAMIC_MA": "\u0645\u06cc\u0627\u0646\u06af\u06cc\u0646 \u0645\u062a\u062d\u0631\u06a9 \u067e\u0648\u06cc\u0627",
}

MITIGATION_STATUS_LABEL = {
    "ACTIVE": "\u0641\u0639\u0627\u0644 / \u062f\u0633\u062a\u200c\u0646\u062e\u0648\u0631\u062f\u0647",
    "PARTIALLY_MITIGATED": "\u062c\u0632\u0626\u06cc \u062a\u0639\u062f\u06cc\u0644\u200c\u0634\u062f\u0647",
    "MITIGATED": "\u062a\u0639\u062f\u06cc\u0644\u200c\u0634\u062f\u0647",
    "INVALIDATED": "\u0646\u0627\u0645\u0639\u062a\u0628\u0631",
}

ZONE_LABEL = {
    "PREMIUM": "\u0645\u0646\u0637\u0642\u0647 \u067e\u0631\u0645\u06cc\u0648\u0645 (Premium)",
    "DISCOUNT": "\u0645\u0646\u0637\u0642\u0647 \u062f\u06cc\u0633\u06a9\u0627\u0648\u0646\u062a (Discount)",
    "EQUILIBRIUM": "\u062a\u0639\u0627\u062f\u0644 (Equilibrium)",
}

CATEGORY_LABEL = {
    "structure": "\u0633\u0627\u062e\u062a\u0627\u0631 \u0628\u0627\u0632\u0627\u0631",
    "poi": "\u0646\u0642\u0637\u0647 \u0645\u0648\u0631\u062f \u062a\u0648\u062c\u0647 (POI)",
    "liquidity": "\u0646\u0642\u062f\u06cc\u0646\u06af\u06cc",
    "momentum": "\u0645\u0648\u0645\u0646\u062a\u0648\u0645",
    "mtf": "\u0647\u0645\u200c\u0631\u0627\u0633\u062a\u0627\u06cc\u06cc \u0686\u0646\u062f\u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645\u06cc",
    "orderbook": "\u062f\u0641\u062a\u0631 \u0633\u0641\u0627\u0631\u0634\u0627\u062a",
    "execution": "\u06a9\u06cc\u0641\u06cc\u062a \u0648\u0631\u0648\u062f",
    "premium_discount": "\u067e\u0631\u0645\u06cc\u0648\u0645/\u062f\u06cc\u0633\u06a9\u0627\u0648\u0646\u062a",
}

# Fixed, small (18-entry) factor_id -> Persian name table. Unlike each
# factor's free-form `evidence` string (dynamically generated English
# prose with computed numbers, e.g. "MA20 slope = 0.89%"), the factor
# NAMES/IDs are a closed, enumerable set — see every category_*.py
# module's ScoreFactor(...) calls. This is what lets the Detailed
# Report show "چرا این امتیاز داده شد" without ever surfacing raw
# English prose (section 1: "Do NOT generate English prose inside the
# report").
FACTOR_NAME_LABEL = {
    "A1": "\u062c\u0647\u062a \u0633\u0627\u062e\u062a\u0627\u0631\u06cc HTF",
    "A2": "\u0628\u0627\u06cc\u0627\u0633 \u06a9\u0644\u0627\u0646 MA200",
    "A3": "\u0634\u06cc\u0628 MA20",
    "A4": "\u0631\u0627\u0628\u0637\u0647 MA20/MA200",
    "B1": "\u0642\u062f\u0631\u062a \u0646\u0642\u0637\u0647 \u0645\u0648\u0631\u062f \u062a\u0648\u062c\u0647 \u0627\u0635\u0644\u06cc",
    "B2": "\u062a\u0627\u0632\u06af\u06cc \u0646\u0642\u0637\u0647 \u0645\u0648\u0631\u062f \u062a\u0648\u062c\u0647",
    "B3": "\u0627\u0631\u062a\u0628\u0627\u0637 \u0633\u0627\u062e\u062a\u0627\u0631\u06cc",
    "B4": "\u06a9\u06cc\u0641\u06cc\u062a \u0648\u0627\u06a9\u0646\u0634 \u0646\u0642\u0637\u0647",
    "C1": "\u062c\u0627\u0631\u0648\u0628 \u0646\u0642\u062f\u06cc\u0646\u06af\u06cc",
    "C2": "\u0648\u0627\u06a9\u0646\u0634 \u0633\u0627\u062e\u062a\u0627\u0631\u06cc",
    "C3": "\u06a9\u06cc\u0641\u06cc\u062a \u0647\u062f\u0641 \u0646\u0642\u062f\u06cc\u0646\u06af\u06cc",
    "D1": "\u0634\u0627\u062e\u0635 \u062c\u0631\u06cc\u0627\u0646 \u0646\u0642\u062f\u06cc\u0646\u06af\u06cc (MFI10)",
    "D2": "\u0634\u0627\u062e\u0635 \u0642\u062f\u0631\u062a \u0646\u0633\u0628\u06cc (RSI14)",
    "E1": "\u0647\u0645\u200c\u0631\u0627\u0633\u062a\u0627\u06cc\u06cc HTF \u0648 MTF",
    "E2": "\u062a\u0623\u06cc\u06cc\u062f \u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 \u067e\u0627\u06cc\u06cc\u0646",
    "F1": "\u062d\u0645\u0627\u06cc\u062a \u0646\u0642\u062f\u06cc\u0646\u06af\u06cc \u062c\u0647\u062a\u062f\u0627\u0631",
    "F2": "\u06a9\u06cc\u0641\u06cc\u062a \u0645\u0633\u06cc\u0631 \u0646\u0642\u062f\u06cc\u0646\u06af\u06cc",
    "G1": "\u06a9\u06cc\u0641\u06cc\u062a \u0648\u0631\u0648\u062f",
    "H1": "\u0645\u0648\u0642\u0639\u06cc\u062a \u067e\u0631\u0645\u06cc\u0648\u0645/\u062f\u06cc\u0633\u06a9\u0627\u0648\u0646\u062a",
}

TIMEFRAME_ROLE_LABEL = {
    "HTF": "\u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 \u0628\u0627\u0644\u0627",
    "MTF": "\u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 \u0645\u06cc\u0627\u0646\u06cc",
    "LTF": "\u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 \u067e\u0627\u06cc\u06cc\u0646",
    "EXECUTION": "\u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645 \u0627\u062c\u0631\u0627",
}

DETAILED_REPORT_BUTTON_TEXT = "\U0001F50D \u0645\u0634\u0627\u0647\u062f\u0647 \u062a\u062d\u0644\u06cc\u0644 \u06a9\u0627\u0645\u0644"

ANALYSIS_NOT_FOUND_MESSAGE = (
    "\u26A0\uFE0F \u06af\u0632\u0627\u0631\u0634 \u062a\u062d\u0644\u06cc\u0644 \u062f\u0631 \u062f\u0633\u062a\u0631\u0633 \u0646\u06cc\u0633\u062a.\n\n"
    "\u0627\u06cc\u0646 \u062a\u062d\u0644\u06cc\u0644 \u062f\u06cc\u06af\u0631 \u062f\u0631 \u062d\u0627\u0641\u0638\u0647 \u0633\u06cc\u0633\u062a\u0645 \u0648\u062c\u0648\u062f \u0646\u062f\u0627\u0631\u062f\n"
    "\u06cc\u0627 \u0645\u0646\u0642\u0636\u06cc \u0634\u062f\u0647 \u0627\u0633\u062a.\n\n"
    "\u0644\u0637\u0641\u0627\u064b \u06cc\u06a9 \u062a\u062d\u0644\u06cc\u0644 \u062c\u062f\u06cc\u062f \u062f\u0631\u062e\u0648\u0627\u0633\u062a \u06a9\u0646\u06cc\u062f."
)

# Persian phrases that, when found in an inbound message, should be
# routed to the Detailed Report handler (section 9, Option B). Matched
# case-insensitively against a normalized (whitespace-collapsed) string.
DETAILED_REPORT_INTENT_PHRASES = (
    "\u062a\u062d\u0644\u06cc\u0644 \u06a9\u0627\u0645\u0644",
    "\u06af\u0632\u0627\u0631\u0634 \u06a9\u0627\u0645\u0644",
    "\u062c\u0632\u0626\u06cc\u0627\u062a \u062a\u062d\u0644\u06cc\u0644",
    "\u062c\u0632\u0626\u06cc\u0627\u062a",
    "\u06af\u0632\u0627\u0631\u0634 \u0645\u0641\u0635\u0644",
)

# --- ADDITIONAL_MODULE: BALE_AGENT_CONTROL_CENTER ---

MAIN_MENU_ITEMS = {
    "status": "\U0001F916 \u0648\u0636\u0639\u06cc\u062a \u0627\u06cc\u062c\u0646\u062a",
    "analysis": "\U0001F4CA \u062a\u062d\u0644\u06cc\u0644 \u0628\u0627\u0632\u0627\u0631",
    "watchlist": "\u2B50 \u0646\u0645\u0627\u062f\u0647\u0627\u06cc \u0645\u0646\u062a\u062e\u0628",
    "settings": "\u2699\uFE0F \u062a\u0646\u0638\u06cc\u0645\u0627\u062a",
    "alerts": "\U0001F6A8 \u0647\u0634\u062f\u0627\u0631\u0647\u0627",
    "performance": "\U0001F4C8 \u06af\u0632\u0627\u0631\u0634 \u0639\u0645\u0644\u06a9\u0631\u062f",
}

MONITORING_CONTROL_LABELS = {
    "start": "\u25B6\uFE0F \u0634\u0631\u0648\u0639 \u067e\u0627\u06cc\u0634",
    "pause": "\u23F8 \u062a\u0648\u0642\u0641 \u067e\u0627\u06cc\u0634",
    "resume": "\U0001F504 \u0627\u062f\u0627\u0645\u0647 \u067e\u0627\u06cc\u0634",
}

WATCHLIST_ACTION_LABELS = {
    "add": "\u2795 \u0627\u0641\u0632\u0648\u062f\u0646",
    "remove": "\u2796 \u062d\u0630\u0641",
    "edit": "\u270F\uFE0F \u0648\u06cc\u0631\u0627\u06cc\u0634",
    "refresh": "\U0001F504 \u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06cc \u0646\u0645\u0627\u062f\u0647\u0627",
}

SETTINGS_FIELD_LABELS = {
    "risk_profile": "\u067e\u0631\u0648\u0641\u0627\u06cc\u0644 \u0631\u06cc\u0633\u06a9",
    "execution_mode": "\u062d\u0627\u0644\u062a \u0645\u0639\u0627\u0645\u0644\u0647",
    "scan_interval_seconds": "\u0641\u0627\u0635\u0644\u0647 \u067e\u0627\u06cc\u0634",
    "enabled_timeframes": "\u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645\u200c\u0647\u0627",
    "scheduled_reports_enabled": "\u06af\u0632\u0627\u0631\u0634\u200c\u0647\u0627\u06cc \u0632\u0645\u0627\u0646\u200c\u0628\u0646\u062f\u06cc",
    "event_alerts_enabled": "\u0647\u0634\u062f\u0627\u0631\u0647\u0627\u06cc \u0631\u0648\u06cc\u062f\u0627\u062f",
    "alert_cooldown_seconds": "\u0641\u0627\u0635\u0644\u0647 \u0647\u0634\u062f\u0627\u0631",
}

CONFIG_UPDATED_MESSAGE = "\u2705 \u062a\u0646\u0638\u06cc\u0645\u0627\u062a \u0628\u0627 \u0645\u0648\u0641\u0642\u06cc\u062a \u0628\u0647\u200c\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06cc \u0634\u062f."
CONFIG_UPDATE_FAILED_MESSAGE = "\u274C \u0628\u0647\u200c\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06cc \u062a\u0646\u0638\u06cc\u0645\u0627\u062a \u0645\u0648\u0641\u0642 \u0646\u0628\u0648\u062f."
SYMBOL_ADDED_MESSAGE = "\u2705 \u0646\u0645\u0627\u062f \u0628\u0647 \u0641\u0647\u0631\u0633\u062a \u0645\u0646\u062a\u062e\u0628 \u0627\u0636\u0627\u0641\u0647 \u0634\u062f."
SYMBOL_REMOVED_MESSAGE = "\u2705 \u0646\u0645\u0627\u062f \u0627\u0632 \u0641\u0647\u0631\u0633\u062a \u0645\u0646\u062a\u062e\u0628 \u062d\u0630\u0641 \u0634\u062f."
SYMBOL_NOT_FOUND_MESSAGE = "\u26A0\uFE0F \u0646\u0645\u0627\u062f\u06cc \u0628\u0627 \u0627\u06cc\u0646 \u0645\u0634\u062e\u0635\u0647 \u06cc\u0627\u0641\u062a \u0646\u0634\u062f."
INVALID_SYMBOL_MESSAGE = "\u26A0\uFE0F \u0641\u0631\u0645\u062a \u0646\u0645\u0627\u062f \u0646\u0627\u0645\u0639\u062a\u0628\u0631 \u0627\u0633\u062a."
MONITORING_STARTED_MESSAGE = "\u25B6\uFE0F \u067e\u0627\u06cc\u0634 \u0628\u0627\u0632\u0627\u0631 \u0634\u0631\u0648\u0639 \u0634\u062f."
MONITORING_PAUSED_MESSAGE = "\u23F8 \u067e\u0627\u06cc\u0634 \u0628\u0627\u0632\u0627\u0631 \u0645\u062a\u0648\u0642\u0641 \u0634\u062f."
MONITORING_RESUMED_MESSAGE = "\U0001F504 \u067e\u0627\u06cc\u0634 \u0628\u0627\u0632\u0627\u0631 \u0627\u062f\u0627\u0645\u0647 \u06cc\u0627\u0641\u062a."
UNKNOWN_COMMAND_MESSAGE = "\u2753 \u062f\u0633\u062a\u0648\u0631 \u0634\u0646\u0627\u062e\u062a\u0647 \u0646\u0634\u062f. \u0627\u0632 \u0645\u0646\u0648\u06cc \u0632\u06cc\u0631 \u0627\u0633\u062a\u0641\u0627\u062f\u0647 \u06a9\u0646\u06cc\u062f."
