"""Bale Agent Control Center (ADDITIONAL_MODULE: BALE_AGENT_CONTROL_CENTER).

`BaleCommandRouter` is pure dispatch logic: given inbound text or
callback_data plus injected collaborators (watchlist service, runtime
config accessor, health snapshot builder, monitoring controller), it
returns a `BaleResponse` (Persian text + optional keyboard) — it never
touches httpx/BaleClient/sqlalchemy directly, which is what makes it
testable with duck-typed fakes (see tests/unit/test_bale_control.py).

Wiring this to a live Bale inbound webhook/long-poll loop is the one
piece intentionally left out — see REPORTING.md's "Known limitations"
(same boundary as the Detailed Report callback from the previous
module). `MonitoringController` is a small Protocol so the real
APScheduler-backed scheduler can implement it without this router
knowing anything about APScheduler.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from app.monitoring.health_service import AgentStatusSnapshot
from app.monitoring.status_formatter import format_status_text
from app.reporting.intent import is_detailed_report_request
from app.reporting.report_localization import (
    CONFIG_UPDATED_MESSAGE,
    INVALID_SYMBOL_MESSAGE,
    MAIN_MENU_ITEMS,
    MONITORING_CONTROL_LABELS,
    MONITORING_PAUSED_MESSAGE,
    MONITORING_RESUMED_MESSAGE,
    MONITORING_STARTED_MESSAGE,
    RISK_PROFILE_LABEL,
    SYMBOL_ADDED_MESSAGE,
    SYMBOL_NOT_FOUND_MESSAGE,
    SYMBOL_REMOVED_MESSAGE,
    UNKNOWN_COMMAND_MESSAGE,
)
from app.watchlist.logic import search_symbols, validate_symbol_format


@dataclass(frozen=True, slots=True)
class BaleResponse:
    text: str
    keyboard: dict | None = None


class MonitoringController(Protocol):
    async def start(self) -> None: ...
    async def pause(self) -> None: ...
    async def resume(self) -> None: ...
    def is_active(self) -> bool: ...


class RuntimeConfigAccessor(Protocol):
    async def get(self) -> dict: ...
    async def update(self, **fields) -> dict: ...


class WatchlistAccessor(Protocol):
    async def list_all(self) -> list: ...  # list[WatchlistItem]
    async def add(self, symbol: str, market_type: str): ...
    async def remove(self, symbol: str) -> bool: ...
    async def set_enabled(self, symbol: str, enabled: bool) -> bool: ...


def main_menu_keyboard() -> dict:
    items = list(MAIN_MENU_ITEMS.items())
    rows = [items[i : i + 2] for i in range(0, len(items), 2)]
    return {
        "inline_keyboard": [
            [{"text": label, "callback_data": f"menu:{key}"} for key, label in row]
            for row in rows
        ]
    }


def main_menu_text() -> str:
    return "\U0001F916 \u067e\u0646\u0644 \u06a9\u0646\u062a\u0631\u0644 \u0627\u06cc\u062c\u0646\u062a\n\n\u06cc\u06a9 \u06af\u0632\u06cc\u0646\u0647 \u0631\u0627 \u0627\u0646\u062a\u062e\u0627\u0628 \u06a9\u0646\u06cc\u062f:"


def monitoring_controls_keyboard(is_active: bool) -> dict:
    buttons = (
        [{"text": MONITORING_CONTROL_LABELS["pause"], "callback_data": "monitor:pause"}]
        if is_active
        else [{"text": MONITORING_CONTROL_LABELS["start"], "callback_data": "monitor:start"}]
    )
    buttons.append({"text": MONITORING_CONTROL_LABELS["resume"], "callback_data": "monitor:resume"})
    return {"inline_keyboard": [buttons]}


class BaleCommandRouter:
    def __init__(
        self,
        watchlist: WatchlistAccessor,
        config: RuntimeConfigAccessor,
        monitoring: MonitoringController,
        status_snapshot_builder,  # async callable() -> AgentStatusSnapshot
    ) -> None:
        self._watchlist = watchlist
        self._config = config
        self._monitoring = monitoring
        self._status_snapshot_builder = status_snapshot_builder

    async def handle_callback(self, callback_data: str) -> BaleResponse:
        if callback_data.startswith("menu:"):
            return await self._handle_menu(callback_data.removeprefix("menu:"))
        if callback_data.startswith("monitor:"):
            return await self._handle_monitor(callback_data.removeprefix("monitor:"))
        if callback_data.startswith("watchlist:"):
            return await self._handle_watchlist_callback(callback_data.removeprefix("watchlist:"))
        if callback_data.startswith("settings:"):
            return await self._handle_settings_callback(callback_data.removeprefix("settings:"))
        return BaleResponse(UNKNOWN_COMMAND_MESSAGE)

    async def handle_text(self, text: str) -> BaleResponse:
        normalized = " ".join(text.split()).strip()
        if not normalized:
            return BaleResponse(UNKNOWN_COMMAND_MESSAGE)

        if normalized in ("/start", "\u0645\u0646\u0648", "menu"):
            return BaleResponse(main_menu_text(), main_menu_keyboard())

        if is_detailed_report_request(normalized):
            # The Detailed Report itself is handled by
            # signal_service.handle_detailed_report_request (needs an
            # analysis_id, which a bare text intent doesn't carry) --
            # this router just recognizes the intent so the caller can
            # route it onward; see REPORTING.md.
            return BaleResponse(UNKNOWN_COMMAND_MESSAGE)

        # Anything else is treated as a watchlist search query.
        return await self._handle_watchlist_search(normalized)

    async def _handle_menu(self, item: str) -> BaleResponse:
        if item == "status":
            snapshot: AgentStatusSnapshot = await self._status_snapshot_builder()
            return BaleResponse(format_status_text(snapshot))
        if item == "watchlist":
            return await self._render_watchlist()
        if item == "settings":
            return await self._render_settings()
        # analysis / alerts / performance menu entries hand off to
        # existing surfaces (SummaryReportGenerator / performance
        # tracker) rather than duplicating that logic here.
        return BaleResponse(MAIN_MENU_ITEMS.get(item, UNKNOWN_COMMAND_MESSAGE))

    async def _handle_monitor(self, action: str) -> BaleResponse:
        if action == "start":
            await self._monitoring.start()
            return BaleResponse(MONITORING_STARTED_MESSAGE, monitoring_controls_keyboard(True))
        if action == "pause":
            await self._monitoring.pause()
            return BaleResponse(MONITORING_PAUSED_MESSAGE, monitoring_controls_keyboard(False))
        if action == "resume":
            await self._monitoring.resume()
            return BaleResponse(MONITORING_RESUMED_MESSAGE, monitoring_controls_keyboard(True))
        return BaleResponse(UNKNOWN_COMMAND_MESSAGE)

    async def _render_watchlist(self) -> BaleResponse:
        items = await self._watchlist.list_all()
        if not items:
            text = "\u2B50 \u0646\u0645\u0627\u062f\u0647\u0627\u06cc \u0645\u0646\u062a\u062e\u0628\n\n\u0641\u0647\u0631\u0633\u062a \u062e\u0627\u0644\u06cc \u0627\u0633\u062a."
        else:
            lines = ["\u2B50 \u0646\u0645\u0627\u062f\u0647\u0627\u06cc \u0645\u0646\u062a\u062e\u0628", ""]
            for item in items:
                dot = "\U0001F7E2" if item.enabled else "\u26AA"
                lines.append(f"{dot} {item.symbol}")
            text = "\n".join(lines)
        keyboard = {
            "inline_keyboard": [[
                {"text": "\u2795 \u0627\u0641\u0632\u0648\u062f\u0646", "callback_data": "watchlist:prompt_add"},
                {"text": "\U0001F504 \u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06cc", "callback_data": "watchlist:refresh"},
            ]]
        }
        return BaleResponse(text, keyboard)

    async def _handle_watchlist_callback(self, action: str) -> BaleResponse:
        if action == "refresh" or action == "list":
            return await self._render_watchlist()
        if action.startswith("remove:"):
            symbol = action.removeprefix("remove:")
            removed = await self._watchlist.remove(symbol)
            return BaleResponse(SYMBOL_REMOVED_MESSAGE if removed else SYMBOL_NOT_FOUND_MESSAGE)
        if action.startswith("enable:"):
            symbol = action.removeprefix("enable:")
            ok = await self._watchlist.set_enabled(symbol, True)
            return BaleResponse(CONFIG_UPDATED_MESSAGE if ok else SYMBOL_NOT_FOUND_MESSAGE)
        if action.startswith("disable:"):
            symbol = action.removeprefix("disable:")
            ok = await self._watchlist.set_enabled(symbol, False)
            return BaleResponse(CONFIG_UPDATED_MESSAGE if ok else SYMBOL_NOT_FOUND_MESSAGE)
        return BaleResponse(UNKNOWN_COMMAND_MESSAGE)

    async def _handle_watchlist_search(self, query: str) -> BaleResponse:
        # Search is performed against the user's own watchlist here
        # (no live Nobitex call from a bare text message); adding a NEW
        # symbol not yet on the watchlist is done via the Setup Wizard's
        # dynamic-discovery search or an explicit "watchlist:add:{SYMBOL}"
        # callback, which validates the format before persisting.
        items = await self._watchlist.list_all()
        candidates = [{"symbol": i.symbol, "base": i.symbol[:-4] if i.symbol.endswith("USDT") else i.symbol[:-3]} for i in items]
        matches = search_symbols(candidates, query)
        if not matches:
            return BaleResponse(SYMBOL_NOT_FOUND_MESSAGE)
        lines = ["\U0001F50D \u0646\u062a\u0627\u06cc\u062c \u062c\u0633\u062a\u062c\u0648:", ""]
        lines += [m["symbol"] for m in matches]
        return BaleResponse("\n".join(lines))

    async def _render_settings(self) -> BaleResponse:
        cfg = await self._config.get()
        lines = [
            "\u2699\uFE0F \u062a\u0646\u0638\u06cc\u0645\u0627\u062a", "",
            f"\u067e\u0631\u0648\u0641\u0627\u06cc\u0644 \u0631\u06cc\u0633\u06a9: {RISK_PROFILE_LABEL.get(cfg.get('risk_profile'), cfg.get('risk_profile'))}",
            f"\u062d\u0627\u0644\u062a \u0645\u0639\u0627\u0645\u0644\u0647: {cfg.get('execution_mode')}",
            f"\u0641\u0627\u0635\u0644\u0647 \u067e\u0627\u06cc\u0634: {cfg.get('scan_interval_seconds', 0) // 60} \u062f\u0642\u06cc\u0642\u0647",
        ]
        return BaleResponse("\n".join(lines))

    async def _handle_settings_callback(self, action: str) -> BaleResponse:
        if action.startswith("risk:"):
            profile = action.removeprefix("risk:")
            if profile not in ("conservative", "moderate", "aggressive"):
                return BaleResponse(INVALID_SYMBOL_MESSAGE)
            await self._config.update(risk_profile=profile)
            return BaleResponse(CONFIG_UPDATED_MESSAGE)
        if action.startswith("mode:"):
            mode = action.removeprefix("mode:")
            if mode not in ("SPOT", "COMMITMENT"):
                return BaleResponse(INVALID_SYMBOL_MESSAGE)
            await self._config.update(execution_mode=mode)
            return BaleResponse(CONFIG_UPDATED_MESSAGE)
        return BaleResponse(UNKNOWN_COMMAND_MESSAGE)

    async def add_symbol(self, symbol: str, market_type: str) -> BaleResponse:
        """Not routed from a bare callback (needs both symbol and market
        type, normally supplied by the wizard/dashboard's structured
        add-flow) — exposed directly for that caller."""
        if not validate_symbol_format(symbol):
            return BaleResponse(INVALID_SYMBOL_MESSAGE)
        await self._watchlist.add(symbol, market_type)
        return BaleResponse(SYMBOL_ADDED_MESSAGE)
