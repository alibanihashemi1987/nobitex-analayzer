"""Inline keyboard construction for Bale reports.

Bale's Bot API is Telegram-Bot-API-compatible for inline keyboards:
`reply_markup: {"inline_keyboard": [[{"text": ..., "callback_data": ...}]]}`.
"""

from __future__ import annotations

from app.reporting.report_localization import DETAILED_REPORT_BUTTON_TEXT

CALLBACK_PREFIX = "detailed_analysis"


class ReportKeyboardBuilder:
    def detailed_analysis_button(self, analysis_id: str) -> dict:
        """Inline keyboard with a single 'مشاهده تحلیل کامل' button whose
        callback_data references the exact analysis_id (section 14)."""
        return {
            "inline_keyboard": [[
                {
                    "text": DETAILED_REPORT_BUTTON_TEXT,
                    "callback_data": f"{CALLBACK_PREFIX}:{analysis_id}",
                }
            ]]
        }


def parse_detailed_analysis_callback(callback_data: str) -> str | None:
    """Extract the analysis_id from a 'detailed_analysis:{id}' callback
    string. Returns None if the string doesn't match that format —
    callers should ignore/ack-only such callbacks rather than error."""
    if not callback_data or ":" not in callback_data:
        return None
    prefix, _, analysis_id = callback_data.partition(":")
    if prefix != CALLBACK_PREFIX or not analysis_id:
        return None
    return analysis_id
