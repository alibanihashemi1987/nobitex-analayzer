"""Bridges Flask's synchronous route handlers to the application's single
asyncio event loop.

The web UI runs in its own OS thread (Flask's dev server), while the
scheduler/Database live on the main thread's asyncio event loop. Rather
than giving the web UI a second `Database` instance on a second event
loop (two separate SQLAlchemy engines pointed at the same SQLite file —
workable, but needless complexity for a local, single-user app), every
Flask route submits its async work to the ONE real loop via
`asyncio.run_coroutine_threadsafe` and blocks for the result. This is a
standard, well-understood pattern for embedding a sync web framework
inside an asyncio application.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Coroutine
from typing import TypeVar

T = TypeVar("T")


class AsyncBridge:
    def __init__(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def run(self, coro: Coroutine[object, object, T], timeout: float = 15.0) -> T:
        """Block the calling (Flask/web) thread until `coro` completes on
        the app's main event loop, and return its result."""
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result(timeout=timeout)
