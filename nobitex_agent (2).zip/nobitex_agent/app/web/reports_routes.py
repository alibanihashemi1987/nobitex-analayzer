"""Report History page (`/reports`) — MODULE_7 section 9.

Reads `AnalysisRecord` (every cycle, live or manual) and, where a trade
was actually taken, the linked `SignalRecord`'s outcome status — both
already persisted by the existing `signal_service.py`. This module only
queries and formats; it computes nothing new.
"""

from __future__ import annotations

from flask import Blueprint, render_template, request

from app.domain.enums import FinalDecision
from app.reporting.detailed_report import DetailedReportGenerator
from app.reporting.report_localization import FINAL_DECISION_LABEL

_SIGNAL_STATUS_LABEL = {
    "OPEN": "\u0628\u0627\u0632 (\u062f\u0631 \u062d\u0627\u0644 \u067e\u06cc\u06af\u06cc\u0631\u06cc)",
    "TP1_HIT": "\u0647\u062f\u0641 \u0627\u0648\u0644 \u0641\u0639\u0627\u0644 \u0634\u062f \u2705",
    "TP2_HIT": "\u0647\u062f\u0641 \u062f\u0648\u0645 \u0641\u0639\u0627\u0644 \u0634\u062f \u2705",
    "TP3_HIT": "\u0647\u062f\u0641 \u0633\u0648\u0645 \u0641\u0639\u0627\u0644 \u0634\u062f \u2705",
    "SL_HIT": "\u062d\u062f \u0636\u0631\u0631 \u062e\u0648\u0631\u062f \u274C",
    "EXPIRED": "\u0645\u0646\u0642\u0636\u06cc \u0634\u062f",
    "INVALIDATED": "\u0646\u0627\u0645\u0639\u062a\u0628\u0631 \u0634\u062f",
}


def _decision_enum(value: str):
    try:
        return FinalDecision(value)
    except ValueError:
        return None


def build_reports_blueprint(bridge, db):
    bp = Blueprint("reports", __name__)

    @bp.route("/reports")
    def reports_list():
        symbol_filter = request.args.get("symbol", "").strip().upper() or None
        decision_filter = request.args.get("decision", "ALL")

        records = bridge.run(db.all_analysis_records(symbol=symbol_filter))
        records.sort(key=lambda r: r.timestamp, reverse=True)

        if decision_filter in ("BUY", "SELL", "WAIT", "CONFLICT"):
            records = [r for r in records if r.final_decision == decision_filter]

        rows = []
        for r in records[:200]:
            outcome_label = None
            if r.linked_signal_id:
                signal = bridge.run(db.get_signal_by_id(r.linked_signal_id))
                if signal is not None:
                    outcome_label = _SIGNAL_STATUS_LABEL.get(signal.status, signal.status)
            rows.append({
                "record": r,
                "final_decision_label": FINAL_DECISION_LABEL.get(_decision_enum(r.final_decision), r.final_decision),
                "outcome_label": outcome_label,
            })

        return render_template(
            "reports.html", rows=rows, symbol_filter=symbol_filter or "",
            decision_filter=decision_filter,
        )

    @bp.route("/reports/<analysis_id>")
    def report_detail(analysis_id: str):
        stored = bridge.run(db.get_stored_market_analysis_result(analysis_id))
        if stored is None:
            return render_template("report_detail.html", analysis_id=analysis_id, report_text=None)

        record = bridge.run(db.get_analysis_by_id(analysis_id))
        risk_profile = record.risk_profile if record else "moderate"
        report_text = DetailedReportGenerator().generate(stored, risk_profile)
        return render_template("report_detail.html", analysis_id=analysis_id, report_text=report_text)

    return bp
