"""Flask app factory for the Persian RTL web UI.

Three surfaces, per the two UI-related spec modules:

- First-Run Setup Wizard (`/setup/...`) — FIRST-RUN_SETUP_&_CREDENTIAL_
  MANAGEMENT: Nobitex connection, Bale connection, trading config,
  watchlist, monitoring config. No terminal input required.
- Dashboard (`/dashboard`) — AGENT_DASHBOARD_&_SYSTEM_HEALTH.
- Settings (`/settings`) — reconfiguration after first run, per section 4
  of the setup module.

All templates are Persian, `dir="rtl"` (PERSIAN_RTL_USER_INTERFACE).
Internal identifiers stay English throughout this module and its
templates' Jinja variable names — only the rendered text is Persian.

Every route is a thin adapter: it calls `bridge.run(...)` to execute
already-existing async service methods (`WatchlistService`,
`DatabaseRuntimeConfigAccessor`, `CredentialManager`,
`NobitexClient.test_connection`, `BaleClient.send_message` for its test)
and renders a template. No trading/analysis logic lives here.
"""

from __future__ import annotations

import os
import secrets
from pathlib import Path

from flask import Flask, redirect, render_template, request, session, url_for

from app.data.nobitex.client import NobitexClient
from app.database.db import Database
from app.monitoring.health_service import HealthService, ServiceHealth, build_status_snapshot, today_key
from app.notifications.bale.client import BaleClient
from app.reporting.report_localization import FINAL_DECISION_LABEL
from app.runtime.config_accessor import DatabaseRuntimeConfigAccessor
from app.runtime.monitoring_controller import MonitoringController
from app.security.credential_manager import CredentialManager
from app.watchlist.logic import filter_by_market_type, search_symbols, validate_symbol_format
from app.watchlist.service import WatchlistService
from app.web.analysis_routes import build_analysis_blueprint
from app.web.api_routes import build_api_blueprint
from app.web.async_bridge import AsyncBridge
from app.web.network_diagnostics import diagnose_connection_error
from app.web.reports_routes import build_reports_blueprint

_TIMEFRAME_CHOICES = ("4H", "1H", "15M", "5M")
_RISK_PROFILES = ("conservative", "moderate", "aggressive")


def _secret_key(data_dir: Path) -> bytes:
    key_path = data_dir / ".web_secret_key"
    if key_path.exists():
        return key_path.read_bytes()
    key = secrets.token_bytes(32)
    data_dir.mkdir(parents=True, exist_ok=True)
    key_path.write_bytes(key)
    os.chmod(key_path, 0o600)
    return key


def create_app(
    bridge: AsyncBridge,
    db: Database,
    credential_manager: CredentialManager,
    monitoring_controller: MonitoringController,
    health: HealthService,
    nobitex_base_url: str,
    scoring_config=None,
    data_dir: str = "./data",
) -> Flask:
    template_dir = Path(__file__).parent / "templates"
    static_dir = Path(__file__).parent / "static"
    app = Flask(__name__, template_folder=str(template_dir), static_folder=str(static_dir))
    app.secret_key = _secret_key(Path(data_dir))

    if scoring_config is None:
        from app.config.scoring_config import get_scoring_config
        scoring_config = get_scoring_config()

    watchlist_service = WatchlistService(db)
    config_accessor = DatabaseRuntimeConfigAccessor(db)

    app.register_blueprint(build_analysis_blueprint(
        bridge, db, credential_manager, watchlist_service, config_accessor, scoring_config, nobitex_base_url,
    ))
    app.register_blueprint(build_reports_blueprint(bridge, db))
    app.register_blueprint(build_api_blueprint(
        bridge, db, credential_manager, watchlist_service, config_accessor,
        monitoring_controller, health, scoring_config, nobitex_base_url,
    ))

    # ---------------------------------------------------------------- #
    # Helpers
    # ---------------------------------------------------------------- #
    def flash(message: str, kind: str = "info") -> None:
        session["_flash"] = {"message": message, "kind": kind}

    def pop_flash() -> dict | None:
        return session.pop("_flash", None)

    def is_setup_completed() -> bool:
        cfg = bridge.run(config_accessor.get())
        return bool(cfg["setup_completed"])

    app.jinja_env.globals["pop_flash"] = pop_flash

    # ---------------------------------------------------------------- #
    # Root
    # ---------------------------------------------------------------- #
    @app.route("/")
    def index():
        if is_setup_completed():
            return redirect(url_for("dashboard"))
        return redirect(url_for("setup_step", step=1))

    # ---------------------------------------------------------------- #
    # Setup Wizard
    # ---------------------------------------------------------------- #
    @app.route("/setup/<int:step>", methods=["GET", "POST"])
    def setup_step(step: int):
        if step not in (1, 2, 3, 4, 5):
            return redirect(url_for("setup_step", step=1))

        if step == 1:
            return _setup_step1_nobitex(bridge, credential_manager, nobitex_base_url, flash)
        if step == 2:
            return _setup_step2_bale(bridge, credential_manager, flash)
        if step == 3:
            return _setup_step3_trading(bridge, config_accessor, flash)
        if step == 4:
            return _setup_step4_watchlist(bridge, watchlist_service, credential_manager, nobitex_base_url, flash)
        return _setup_step5_monitoring(bridge, config_accessor, monitoring_controller, flash)

    # ---------------------------------------------------------------- #
    # Dashboard
    # ---------------------------------------------------------------- #
    @app.route("/dashboard")
    def dashboard():
        if not is_setup_completed():
            # Guards against a stale bookmarked/reused browser tab landing
            # here directly (e.g. from a previous run) before setup was
            # ever completed -- the "/" route already redirects correctly
            # on a fresh visit, but this makes /dashboard itself safe too.
            return redirect(url_for("setup_step", step=1))
        snapshot = bridge.run(_build_snapshot(db, health, watchlist_service, config_accessor, credential_manager, nobitex_base_url))
        market_bias = bridge.run(_build_market_bias(db, watchlist_service))
        return render_template(
            "dashboard.html", snapshot=snapshot, monitoring_active=monitoring_controller.is_active(),
            market_bias=market_bias,
        )

    @app.route("/dashboard/monitoring/<action>", methods=["POST"])
    def dashboard_monitoring(action: str):
        if action == "pause":
            bridge.run(monitoring_controller.pause())
            flash("\u067e\u0627\u06cc\u0634 \u0645\u062a\u0648\u0642\u0641 \u0634\u062f.", "success")
        elif action in ("start", "resume"):
            bridge.run(monitoring_controller.start())
            flash("\u067e\u0627\u06cc\u0634 \u0641\u0639\u0627\u0644 \u0634\u062f.", "success")
        return redirect(url_for("dashboard"))

    # ---------------------------------------------------------------- #
    # Settings (post-setup reconfiguration)
    # ---------------------------------------------------------------- #
    @app.route("/settings")
    def settings_home():
        return render_template("settings.html")

    @app.route("/settings/bale-test", methods=["POST"])
    def settings_bale_test():
        bot_token, chat_id = bridge.run(credential_manager.get_bale_credentials())
        if not (bot_token and chat_id):
            flash("\u0627\u0628\u062a\u062f\u0627 \u062a\u0648\u06a9\u0646 Bale \u0631\u0627 \u062a\u0646\u0638\u06cc\u0645 \u06a9\u0646\u06cc\u062f.", "error")
            return redirect(url_for("settings_home"))
        ok, message = _test_bale_connection(bridge, bot_token, chat_id)
        flash(message, "success" if ok else "error")
        return redirect(url_for("settings_home"))

    @app.route("/settings/reset", methods=["POST"])
    def settings_reset():
        bridge.run(credential_manager.clear_all())
        bridge.run(config_accessor.update(setup_completed=False))
        bridge.run(monitoring_controller.pause())
        flash("\u062a\u0646\u0638\u06cc\u0645\u0627\u062a \u0628\u0627\u0632\u0646\u0634\u0627\u0646\u06cc \u0634\u062f. \u0644\u0637\u0641\u0627\u064b \u062f\u0648\u0628\u0627\u0631\u0647 \u0631\u0627\u0647\u200c\u0627\u0646\u062f\u0627\u0632\u06cc \u0631\u0627 \u0637\u06cc \u06a9\u0646\u06cc\u062f.", "success")
        return redirect(url_for("index"))

    return app


# ---------------------------------------------------------------------- #
# Step implementations (kept as module-level functions so `create_app`
# doesn't become one enormous closure)
# ---------------------------------------------------------------------- #

def _setup_step1_nobitex(bridge, credential_manager, nobitex_base_url, flash):
    if request.method == "POST":
        api_token = request.form.get("api_token", "").strip()
        action = request.form.get("action")

        if action == "test":
            if not api_token:
                flash("\u0644\u0637\u0641\u0627\u064b \u062a\u0648\u06a9\u0646 API \u0631\u0627 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.", "error")
            else:
                ok, message = _test_nobitex_connection(bridge, nobitex_base_url, api_token)
                flash(message, "success" if ok else "error")
        elif action == "continue":
            if not api_token:
                flash("\u0644\u0637\u0641\u0627\u064b \u062a\u0648\u06a9\u0646 API \u0631\u0627 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.", "error")
            else:
                bridge.run(credential_manager.save_nobitex_credentials(api_token, ""))
                return redirect(url_for("setup_step", step=2))
    return render_template("setup_step1.html", step=1)


def _test_nobitex_connection(bridge, base_url, api_token) -> tuple[bool, str]:
    async def _run():
        async with NobitexClient(base_url, api_token) as client:
            await client.test_connection()

    try:
        bridge.run(_run())
        return True, "\u2705 \u0627\u062a\u0635\u0627\u0644 \u0628\u0647 \u0646\u0648\u0628\u06cc\u062a\u06a9\u0633 \u0628\u0627 \u0645\u0648\u0641\u0642\u06cc\u062a \u0628\u0631\u0642\u0631\u0627\u0631 \u0634\u062f."
    except Exception as exc:
        return False, "\u26A0\uFE0F " + diagnose_connection_error(exc, "\u0646\u0648\u0628\u06cc\u062a\u06a9\u0633")


def _setup_step2_bale(bridge, credential_manager, flash):
    if request.method == "POST":
        bot_token = request.form.get("bot_token", "").strip()
        chat_id = request.form.get("chat_id", "").strip()
        action = request.form.get("action")

        if action == "test":
            if not bot_token or not chat_id:
                flash("\u0644\u0637\u0641\u0627\u064b Bot Token \u0648 Chat ID \u0631\u0627 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.", "error")
            else:
                ok, message = _test_bale_connection(bridge, bot_token, chat_id)
                flash(message, "success" if ok else "error")
        elif action == "continue":
            if bot_token and chat_id:
                bridge.run(credential_manager.save_bale_credentials(bot_token, chat_id))
            return redirect(url_for("setup_step", step=3))
    return render_template("setup_step2.html", step=2)


def _test_bale_connection(bridge, bot_token, chat_id) -> tuple[bool, str]:
    async def _run():
        client = BaleClient(bot_token, chat_id)
        try:
            await client.send_message(
                "\u2705 \u0627\u062a\u0635\u0627\u0644 \u0627\u06cc\u062c\u0646\u062a \u0645\u0639\u0627\u0645\u0644\u0627\u062a\u06cc \u0646\u0648\u0628\u06cc\u062a\u06a9\u0633 \u0628\u0631\u0642\u0631\u0627\u0631 \u0634\u062f."
            )
        finally:
            await client.aclose()

    try:
        bridge.run(_run())
        return True, "\u2705 \u067e\u06cc\u0627\u0645 \u062a\u0633\u062a \u0628\u0647 Bale \u0627\u0631\u0633\u0627\u0644 \u0634\u062f."
    except Exception as exc:
        return False, "\u26A0\uFE0F " + diagnose_connection_error(exc, "Bale")


def _setup_step3_trading(bridge, config_accessor, flash):
    if request.method == "POST":
        mode = request.form.get("execution_mode", "SPOT")
        risk = request.form.get("risk_profile", "moderate")
        interval = request.form.get("scan_interval_seconds", "300")
        timeframes = request.form.getlist("timeframes") or list(_TIMEFRAME_CHOICES)

        errors = []
        if mode not in ("SPOT", "COMMITMENT"):
            errors.append("\u062d\u0627\u0644\u062a \u0645\u0639\u0627\u0645\u0644\u0647 \u0646\u0627\u0645\u0639\u062a\u0628\u0631 \u0627\u0633\u062a.")
        if risk not in _RISK_PROFILES:
            errors.append("\u067e\u0631\u0648\u0641\u0627\u06cc\u0644 \u0631\u06cc\u0633\u06a9 \u0646\u0627\u0645\u0639\u062a\u0628\u0631 \u0627\u0633\u062a.")
        try:
            interval_int = max(60, int(interval))
        except ValueError:
            errors.append("\u0641\u0627\u0635\u0644\u0647 \u067e\u0627\u06cc\u0634 \u0628\u0627\u06cc\u062f \u0639\u062f\u062f \u0635\u062d\u06cc\u062d \u0628\u0627\u0634\u062f.")
            interval_int = 300

        if errors:
            for e in errors:
                flash(e, "error")
        else:
            bridge.run(config_accessor.update(
                execution_mode=mode, risk_profile=risk,
                scan_interval_seconds=interval_int, enabled_timeframes=timeframes,
            ))
            return redirect(url_for("setup_step", step=4))

    cfg = bridge.run(config_accessor.get())
    return render_template(
        "setup_step3.html", step=3, cfg=cfg,
        timeframe_choices=_TIMEFRAME_CHOICES, risk_profiles=_RISK_PROFILES,
    )


def _setup_step4_watchlist(bridge, watchlist_service, credential_manager, nobitex_base_url, flash):
    query = request.args.get("q", "").strip()
    market_filter = request.args.get("market", "ALL")

    if request.method == "POST":
        action = request.form.get("action")
        symbol = request.form.get("symbol", "").strip().upper()
        market_type = request.form.get("market_type", "").strip().upper()

        if action == "add":
            if not validate_symbol_format(symbol):
                flash(f"\u0646\u0645\u0627\u062f {symbol} \u0645\u0639\u062a\u0628\u0631 \u0646\u06cc\u0633\u062a.", "error")
            else:
                bridge.run(watchlist_service.add(symbol, market_type or "TETHER"))
                flash(f"\u0646\u0645\u0627\u062f {symbol} \u0627\u0636\u0627\u0641\u0647 \u0634\u062f.", "success")
        elif action == "remove":
            bridge.run(watchlist_service.remove(symbol))
            flash(f"\u0646\u0645\u0627\u062f {symbol} \u062d\u0630\u0641 \u0634\u062f.", "success")
        elif action == "toggle":
            enabled = request.form.get("enabled") == "1"
            bridge.run(watchlist_service.set_enabled(symbol, not enabled))
        elif action == "continue":
            return redirect(url_for("setup_step", step=5))
        return redirect(url_for("setup_step", step=4))

    watchlist = bridge.run(watchlist_service.list_all())

    available: list[dict] = []
    discovery_error: str | None = None
    api_key, _ = bridge.run(credential_manager.get_nobitex_credentials())
    if api_key:
        try:
            async def _discover():
                async with NobitexClient(nobitex_base_url, api_key) as client:
                    return await client.fetch_all_market_symbols()
            available = bridge.run(_discover())
        except Exception:
            discovery_error = "\u0644\u06cc\u0633\u062a \u0646\u0645\u0627\u062f\u0647\u0627 \u062f\u0631 \u062f\u0633\u062a\u0631\u0633 \u0646\u06cc\u0633\u062a \u2014 \u0627\u0632 \u062c\u0633\u062a\u062c\u0648\u06cc \u062f\u0633\u062a\u06cc \u0627\u0633\u062a\u0641\u0627\u062f\u0647 \u06a9\u0646\u06cc\u062f."

    if available:
        if market_filter in ("RIAL", "TETHER"):
            available = filter_by_market_type(available, market_filter)
        if query:
            available = search_symbols(available, query)

    return render_template(
        "setup_step4.html", step=4, watchlist=watchlist, available=available[:50],
        discovery_error=discovery_error, query=query, market_filter=market_filter,
    )


def _setup_step5_monitoring(bridge, config_accessor, monitoring_controller, flash):
    if request.method == "POST":
        auto_monitoring = request.form.get("auto_monitoring") == "on"
        scheduled_reports = request.form.get("scheduled_reports") == "on"
        event_alerts = request.form.get("event_alerts") == "on"
        candle_close_reports = request.form.get("candle_close_reports") == "on"
        cooldown = request.form.get("alert_cooldown_seconds", "1800")
        try:
            cooldown_int = max(0, int(cooldown))
        except ValueError:
            cooldown_int = 1800

        bridge.run(config_accessor.update(
            auto_monitoring_enabled=auto_monitoring,
            scheduled_reports_enabled=scheduled_reports,
            event_alerts_enabled=event_alerts,
            candle_close_reports_enabled=candle_close_reports,
            alert_cooldown_seconds=cooldown_int,
            setup_completed=True,
        ))
        if auto_monitoring:
            bridge.run(monitoring_controller.start())
        else:
            bridge.run(monitoring_controller.pause())
        flash("\u0631\u0627\u0647\u200c\u0627\u0646\u062f\u0627\u0632\u06cc \u0628\u0627 \u0645\u0648\u0641\u0642\u06cc\u062a \u06a9\u0627\u0645\u0644 \u0634\u062f!", "success")
        return redirect(url_for("dashboard"))

    cfg = bridge.run(config_accessor.get())
    return render_template("setup_step5.html", step=5, cfg=cfg)


async def _build_market_bias(db, watchlist_service) -> list[dict]:
    """MODULE_7 section 3 "Market Overview" widget: latest known final
    decision per enabled watchlist symbol. Reads whatever the most
    recent `AnalysisRecord` for that symbol already says — computes
    nothing new."""
    enabled_symbols = await watchlist_service.list_enabled()  # list[str]
    bias = []
    for symbol in enabled_symbols:
        records = await db.all_analysis_records(symbol=symbol)
        latest = max(records, key=lambda r: r.timestamp) if records else None
        bias.append({
            "symbol": symbol,
            "final_decision": latest.final_decision if latest else None,
            "label": FINAL_DECISION_LABEL.get(_decision_enum(latest.final_decision), "\u2014") if latest else "\u2014",
        })
    return bias


def _decision_enum(value):
    from app.domain.enums import FinalDecision
    try:
        return FinalDecision(value)
    except ValueError:
        return None


async def _build_snapshot(db, health, watchlist_service, config_accessor, credential_manager, nobitex_base_url):
    database_health = ServiceHealth(connected=True)
    try:
        cfg = await config_accessor.get()
        enabled_symbols = await watchlist_service.list_enabled()
        counter = await db.get_daily_counter(today_key())
    except Exception as exc:
        # A database-layer failure must degrade the page, not crash it
        # with a raw 500 -- see AGENT_DASHBOARD_&_SYSTEM_HEALTH section
        # "Degraded State": one service failing must never take down the
        # whole UI.
        database_health = ServiceHealth(connected=False, detail=str(exc))
        cfg = {"scan_interval_seconds": 0, "enabled_timeframes": []}
        enabled_symbols = []
        counter = None

    try:
        api_key, _ = await credential_manager.get_nobitex_credentials()
    except Exception as exc:
        api_key = None
        nobitex_health = ServiceHealth(connected=False, detail=str(exc))
    else:
        if api_key:
            try:
                async with NobitexClient(nobitex_base_url, api_key) as client:
                    await client.test_connection()
                nobitex_health = ServiceHealth(connected=True)
            except Exception as exc:
                nobitex_health = ServiceHealth(
                    connected=False,
                    detail=diagnose_connection_error(exc, "\u0646\u0648\u0628\u06cc\u062a\u06a9\u0633"),
                )
        else:
            nobitex_health = ServiceHealth(connected=False, detail="\u062a\u0646\u0638\u06cc\u0645 \u0646\u0634\u062f\u0647")

    try:
        bot_token, chat_id = await credential_manager.get_bale_credentials()
        bale_health = ServiceHealth(connected=bool(bot_token and chat_id), detail=None if bot_token else "\u062a\u0646\u0638\u06cc\u0645 \u0646\u0634\u062f\u0647")
    except Exception as exc:
        bale_health = ServiceHealth(connected=False, detail=diagnose_connection_error(exc, "Bale"))

    return build_status_snapshot(
        health, nobitex_health, bale_health, database_health,
        enabled_symbol_count=len(enabled_symbols),
        scan_interval_seconds=cfg["scan_interval_seconds"],
        timeframes=tuple(cfg["enabled_timeframes"]),
        alerts_today=counter.alerts_sent if counter else 0,
        analyses_today=counter.analyses_run if counter else 0,
    )
