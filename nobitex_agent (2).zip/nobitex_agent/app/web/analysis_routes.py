"""Live Analysis page (`/analysis`) — MODULE_7 section 6.

Reuses `run_dual_analysis` (the exact same function the scheduler calls)
for the "اجرای تحلیل فوری" manual trigger, and the exact same
`SummaryReportGenerator`/`DetailedReportGenerator` already used for Bale
— rendered as HTML instead of sent as a Bale message. No analysis or
scoring logic is duplicated here; this module only formats and displays
already-computed results.
"""

from __future__ import annotations

from flask import Blueprint, render_template, request

from app.data.nobitex.client import NobitexClient
from app.domain.enums import ExecutionMode
from app.reporting.detailed_report import DetailedReportGenerator
from app.reporting.summary_report import SummaryReportGenerator
from app.runtime.config_accessor import DatabaseRuntimeConfigAccessor
from app.services.analysis_service import run_dual_analysis
from app.watchlist.service import WatchlistService


def build_analysis_blueprint(
    bridge, db, credential_manager, watchlist_service: WatchlistService,
    config_accessor: DatabaseRuntimeConfigAccessor, scoring_config, nobitex_base_url: str,
) -> Blueprint:
    bp = Blueprint("analysis", __name__)

    @bp.route("/analysis")
    def analysis_home():
        watchlist = bridge.run(watchlist_service.list_enabled())  # list[str]
        symbol = request.args.get("symbol") or (watchlist[0] if watchlist else None)

        summary_text: str | None = None
        detailed_text: str | None = None
        chart_data_uri: str | None = None
        error: str | None = None
        result = None

        if symbol and request.args.get("run") == "1":
            result, error = _run_live_analysis(bridge, db, credential_manager, scoring_config, nobitex_base_url, symbol)
            if result is not None:
                cfg = bridge.run(config_accessor.get())
                summary_text = SummaryReportGenerator().generate(result, cfg["risk_profile"])
                if request.args.get("detailed") == "1":
                    detailed_text = DetailedReportGenerator().generate(result, cfg["risk_profile"])
                chart_data_uri = _try_build_chart(bridge, credential_manager, nobitex_base_url, scoring_config, symbol, result)

        return render_template(
            "analysis.html", watchlist=watchlist, symbol=symbol, result=result,
            summary_text=summary_text, detailed_text=detailed_text,
            chart_data_uri=chart_data_uri, error=error,
            show_detailed=request.args.get("detailed") == "1",
        )

    return bp


def _run_live_analysis(bridge, db, credential_manager, scoring_config, nobitex_base_url, symbol):
    api_key, _ = bridge.run(credential_manager.get_nobitex_credentials())
    if not api_key:
        return None, "\u0627\u062a\u0635\u0627\u0644 \u0646\u0648\u0628\u06cc\u062a\u06a9\u0633 \u062a\u0646\u0638\u06cc\u0645 \u0646\u0634\u062f\u0647 \u0627\u0633\u062a. \u0627\u0628\u062a\u062f\u0627 \u0645\u0631\u0627\u062d\u0644 \u0631\u0627\u0647\u200c\u0627\u0646\u062f\u0627\u0632\u06cc \u0631\u0627 \u062a\u06a9\u0645\u06cc\u0644 \u06a9\u0646\u06cc\u062f."

    async def _run():
        cfg = await db.get_runtime_config()
        async with NobitexClient(nobitex_base_url, api_key) as client:
            return await run_dual_analysis(
                client, scoring_config, symbol,
                ExecutionMode(cfg.execution_mode), cfg.risk_profile,
            )

    try:
        return bridge.run(_run()), None
    except Exception as exc:
        return None, (
            "\u26A0\uFE0F \u062e\u0637\u0627 \u062f\u0631 \u0627\u062c\u0631\u0627\u06cc \u062a\u062d\u0644\u06cc\u0644\n\n"
            f"\u062c\u0632\u0626\u06cc\u0627\u062a \u0641\u0646\u06cc: {type(exc).__name__}"
        )


def _try_build_chart(bridge, credential_manager, nobitex_base_url, scoring_config, symbol, result) -> str | None:
    """Reuses the existing mplfinance chart generator (already used for
    Bale sendPhoto) — per MODULE_7 section 7: "If the existing project
    already generates mplfinance charts, preserve that functionality and
    expose the generated charts in the dashboard as an additional
    option." Returns a base64 data: URI, or None if it couldn't be built
    (never fatal to the page — the report text is still shown)."""
    import base64

    from app.charts.chart_generator import generate_signal_chart
    from app.data.market.timeframe import only_closed

    api_key, _ = bridge.run(credential_manager.get_nobitex_credentials())
    if not api_key:
        return None

    winning = None
    if result.directional_winner == "LONG":
        winning = result.long_analysis
    elif result.directional_winner == "SHORT":
        winning = result.short_analysis

    async def _fetch():
        async with NobitexClient(nobitex_base_url, api_key) as client:
            return await client.fetch_candles(symbol, scoring_config.mtf_timeframes.execution, count=150)

    try:
        candles = bridge.run(_fetch())
        closed = only_closed(candles)
        if len(closed) < 10:
            return None
        png_bytes = generate_signal_chart(
            closed, winning.risk if winning else None, title=f"{symbol} \u2014 {result.final_decision.value}",
        )
        return "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii")
    except Exception:
        return None
