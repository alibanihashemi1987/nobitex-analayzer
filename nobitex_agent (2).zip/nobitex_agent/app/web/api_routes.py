"""JSON API endpoints (MODULE_7 section 18).

Every endpoint here is a thin JSON-serializing wrapper over the SAME
service calls the HTML routes use (`WatchlistService`,
`DatabaseRuntimeConfigAccessor`, `HealthService`, `run_dual_analysis`,
`MonitoringController`) — no analysis or scoring logic is duplicated or
re-implemented for the API; it is the identical call, just returned as
`jsonify(...)` instead of `render_template(...)`.
"""

from __future__ import annotations

from flask import Blueprint, jsonify, request

from app.data.nobitex.client import NobitexClient
from app.domain.enums import ExecutionMode
from app.monitoring.health_service import ServiceHealth, build_status_snapshot, today_key
from app.notifications.bale.client import BaleClient
from app.services.analysis_service import run_dual_analysis
from app.watchlist.logic import validate_symbol_format


def _watchlist_row_to_dict(row) -> dict:
    return {
        "symbol": row.symbol, "market_type": row.market_type,
        "enabled": row.enabled, "display_order": row.display_order,
    }


def _analysis_record_to_dict(r) -> dict:
    return {
        "id": r.id, "symbol": r.symbol, "timestamp": r.timestamp.isoformat(),
        "execution_mode": r.execution_mode, "risk_profile": r.risk_profile,
        "long_score": r.long_score, "long_status": r.long_status,
        "short_score": r.short_score, "short_status": r.short_status,
        "final_decision": r.final_decision, "final_reason": r.final_reason,
        "directional_winner": r.directional_winner,
        "long_entry": r.long_entry, "long_sl": r.long_sl,
        "long_tp1": r.long_tp1, "long_tp2": r.long_tp2, "long_tp3": r.long_tp3,
        "short_entry": r.short_entry, "short_sl": r.short_sl,
        "short_tp1": r.short_tp1, "short_tp2": r.short_tp2, "short_tp3": r.short_tp3,
        "linked_signal_id": r.linked_signal_id,
    }


def build_api_blueprint(
    bridge, db, credential_manager, watchlist_service, config_accessor,
    monitoring_controller, health, scoring_config, nobitex_base_url,
):
    bp = Blueprint("api", __name__, url_prefix="/api")

    # ---------------------------------------------------------------- #
    @bp.route("/status")
    def api_status():
        async def _build():
            cfg = await config_accessor.get()
            enabled = await watchlist_service.list_enabled()
            api_key, _ = await credential_manager.get_nobitex_credentials()
            nobitex_health = ServiceHealth(connected=False, detail="\u062a\u0646\u0638\u06cc\u0645 \u0646\u0634\u062f\u0647")
            if api_key:
                try:
                    async with NobitexClient(nobitex_base_url, api_key) as client:
                        await client.test_connection()
                    nobitex_health = ServiceHealth(connected=True)
                except Exception as exc:
                    nobitex_health = ServiceHealth(connected=False, detail=str(exc))
            bot_token, chat_id = await credential_manager.get_bale_credentials()
            bale_health = ServiceHealth(connected=bool(bot_token and chat_id))
            counter = await db.get_daily_counter(today_key())
            snapshot = build_status_snapshot(
                health, nobitex_health, bale_health, ServiceHealth(connected=True),
                enabled_symbol_count=len(enabled), scan_interval_seconds=cfg["scan_interval_seconds"],
                timeframes=tuple(cfg["enabled_timeframes"]),
                alerts_today=counter.alerts_sent if counter else 0,
                analyses_today=counter.analyses_run if counter else 0,
            )
            return snapshot, cfg

        snapshot, cfg = bridge.run(_build())
        return jsonify({
            "monitoring_active": monitoring_controller.is_active(),
            "degraded": snapshot.degraded,
            "nobitex": {"connected": snapshot.nobitex.connected, "detail": snapshot.nobitex.detail},
            "bale": {"connected": snapshot.bale.connected, "detail": snapshot.bale.detail},
            "database": {"connected": snapshot.database.connected, "detail": snapshot.database.detail},
            "enabled_symbol_count": snapshot.enabled_symbol_count,
            "timeframes": list(snapshot.timeframes),
            "last_scan_time": snapshot.last_scan_time.isoformat() if snapshot.last_scan_time else None,
            "next_scan_time": snapshot.next_scan_time.isoformat() if snapshot.next_scan_time else None,
            "alerts_today": snapshot.alerts_today,
            "analyses_today": snapshot.analyses_today,
            "execution_mode": cfg["execution_mode"],
            "risk_profile": cfg["risk_profile"],
        })

    # ---------------------------------------------------------------- #
    @bp.route("/symbols")
    def api_symbols():
        api_key, _ = bridge.run(credential_manager.get_nobitex_credentials())
        if not api_key:
            return jsonify({"error": "nobitex_not_configured", "symbols": []}), 200

        async def _discover():
            async with NobitexClient(nobitex_base_url, api_key) as client:
                return await client.fetch_all_market_symbols()

        try:
            return jsonify({"symbols": bridge.run(_discover())})
        except Exception as exc:
            return jsonify({"error": str(exc), "symbols": []}), 200

    # ---------------------------------------------------------------- #
    @bp.route("/watchlist", methods=["GET", "POST"])
    def api_watchlist():
        if request.method == "POST":
            body = request.get_json(silent=True) or {}
            symbol = str(body.get("symbol", "")).strip().upper()
            market_type = str(body.get("market_type", "TETHER")).strip().upper()
            if not validate_symbol_format(symbol):
                return jsonify({"error": "invalid_symbol_format"}), 400
            row = bridge.run(watchlist_service.add(symbol, market_type))
            return jsonify(_watchlist_row_to_dict(row)), 201

        rows = bridge.run(watchlist_service.list_all())
        return jsonify([_watchlist_row_to_dict(r) for r in rows])

    @bp.route("/watchlist/<symbol>", methods=["PUT", "DELETE"])
    def api_watchlist_item(symbol: str):
        symbol = symbol.upper()
        if request.method == "DELETE":
            removed = bridge.run(watchlist_service.remove(symbol))
            return jsonify({"removed": removed})

        body = request.get_json(silent=True) or {}
        if "enabled" in body:
            ok = bridge.run(watchlist_service.set_enabled(symbol, bool(body["enabled"])))
            return jsonify({"updated": ok})
        return jsonify({"error": "no_recognized_fields"}), 400

    # ---------------------------------------------------------------- #
    @bp.route("/analysis/<symbol>")
    def api_get_analysis(symbol: str):
        records = bridge.run(db.all_analysis_records(symbol=symbol.upper()))
        if not records:
            return jsonify({"error": "no_analysis_found"}), 404
        latest = max(records, key=lambda r: r.timestamp)
        return jsonify(_analysis_record_to_dict(latest))

    @bp.route("/analysis/<symbol>/run", methods=["POST"])
    def api_run_analysis(symbol: str):
        api_key, _ = bridge.run(credential_manager.get_nobitex_credentials())
        if not api_key:
            return jsonify({"error": "nobitex_not_configured"}), 400

        async def _run():
            cfg = await db.get_runtime_config()
            async with NobitexClient(nobitex_base_url, api_key) as client:
                return await run_dual_analysis(
                    client, scoring_config, symbol.upper(),
                    ExecutionMode(cfg.execution_mode), cfg.risk_profile,
                )

        try:
            result = bridge.run(_run())
        except Exception as exc:
            return jsonify({"error": str(exc)}), 502

        return jsonify({
            "symbol": result.symbol,
            "analysis_id": result.analysis_id,
            "final_decision": result.final_decision.value,
            "long_score": result.long_analysis.score,
            "short_score": result.short_analysis.score,
            "long_status": result.long_analysis.status.value,
            "short_status": result.short_analysis.status.value,
        })

    # ---------------------------------------------------------------- #
    @bp.route("/reports")
    def api_reports():
        symbol = request.args.get("symbol")
        records = bridge.run(db.all_analysis_records(symbol=symbol.upper() if symbol else None))
        records.sort(key=lambda r: r.timestamp, reverse=True)
        return jsonify([_analysis_record_to_dict(r) for r in records[:200]])

    @bp.route("/reports/<analysis_id>")
    def api_report_detail(analysis_id: str):
        record = bridge.run(db.get_analysis_by_id(analysis_id))
        if record is None:
            return jsonify({"error": "not_found"}), 404
        return jsonify(_analysis_record_to_dict(record))

    # ---------------------------------------------------------------- #
    @bp.route("/settings", methods=["GET", "PUT"])
    def api_settings():
        if request.method == "PUT":
            body = request.get_json(silent=True) or {}
            allowed = {
                "execution_mode", "risk_profile", "scan_interval_seconds", "enabled_timeframes",
                "auto_monitoring_enabled", "scheduled_reports_enabled", "event_alerts_enabled",
                "alert_cooldown_seconds", "candle_close_reports_enabled",
            }
            updates = {k: v for k, v in body.items() if k in allowed}
            if not updates:
                return jsonify({"error": "no_recognized_fields"}), 400
            cfg = bridge.run(config_accessor.update(**updates))
            return jsonify(cfg)
        return jsonify(bridge.run(config_accessor.get()))

    # ---------------------------------------------------------------- #
    @bp.route("/bale/test", methods=["POST"])
    def api_bale_test():
        bot_token, chat_id = bridge.run(credential_manager.get_bale_credentials())
        if not (bot_token and chat_id):
            return jsonify({"ok": False, "error": "bale_not_configured"}), 400

        async def _send():
            client = BaleClient(bot_token, chat_id)
            try:
                await client.send_message(
                    "\u2705 \u067e\u06cc\u0627\u0645 \u062a\u0633\u062a \u0627\u0632 \u062f\u0627\u0634\u0628\u0648\u0631\u062f \u0648\u0628."
                )
            finally:
                await client.aclose()

        try:
            bridge.run(_send())
            return jsonify({"ok": True})
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 502

    # ---------------------------------------------------------------- #
    @bp.route("/scanner/start", methods=["POST"])
    def api_scanner_start():
        bridge.run(monitoring_controller.start())
        return jsonify({"active": True})

    @bp.route("/scanner/stop", methods=["POST"])
    def api_scanner_stop():
        bridge.run(monitoring_controller.pause())
        return jsonify({"active": False})

    @bp.route("/scanner/scan-now", methods=["POST"])
    def api_scanner_scan_now():
        body = request.get_json(silent=True) or {}
        symbol = body.get("symbol")
        if symbol:
            return api_run_analysis(symbol)
        return jsonify({"error": "symbol_required"}), 400

    return bp
