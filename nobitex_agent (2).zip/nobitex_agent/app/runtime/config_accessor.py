"""Database-backed `RuntimeConfigAccessor` (see `app/reporting/
bale_control.py`'s Protocol). One implementation, shared by the web UI
(`app/web/`) and the Bale Control Center, so a setting changed from
either surface is immediately visible to the other — there is exactly
one place (`RuntimeConfigRecord`, via `Database`) that actually holds
the value.
"""

from __future__ import annotations

from app.database.db import Database

_CONFIG_FIELDS = (
    "setup_completed", "execution_mode", "risk_profile", "scan_interval_seconds",
    "enabled_timeframes", "auto_monitoring_enabled", "scheduled_reports_enabled",
    "event_alerts_enabled", "alert_cooldown_seconds", "candle_close_reports_enabled",
)


class DatabaseRuntimeConfigAccessor:
    def __init__(self, db: Database) -> None:
        self._db = db

    async def get(self) -> dict:
        record = await self._db.get_runtime_config()
        return {field: getattr(record, field) for field in _CONFIG_FIELDS}

    async def update(self, **fields: object) -> dict:
        unknown = set(fields) - set(_CONFIG_FIELDS)
        if unknown:
            raise ValueError(f"Unknown runtime config field(s): {unknown}")
        record = await self._db.update_runtime_config(**fields)
        return {field: getattr(record, field) for field in _CONFIG_FIELDS}
