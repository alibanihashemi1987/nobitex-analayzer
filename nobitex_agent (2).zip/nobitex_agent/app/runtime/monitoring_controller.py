"""Shared, thread-safe start/pause/resume state for the autonomous
monitor. One instance is constructed at startup and handed to BOTH the
asyncio scheduler (`app/scheduler/scheduler.py`, running in the main
thread's event loop) and the Flask web UI (running in its own thread —
see `app/web/`) and the Bale Control Center router
(`app/reporting/bale_control.py`). All three can request a state change;
`threading.Event` is safe to read/write across threads without an
explicit lock (that's exactly what it's for), so no asyncio-specific
coordination is needed.

Implements the `MonitoringController` Protocol already defined in
`app/reporting/bale_control.py` — the Bale Control Center's monitoring
buttons ("▶️ شروع پایش" / "⏸ توقف پایش" / "🔄 ادامه پایش") and the
dashboard's equivalent buttons both end up calling the exact same
object, so their effect is always consistent regardless of which
surface triggered it.
"""

from __future__ import annotations

import threading
from datetime import UTC, datetime


class MonitoringController:
    def __init__(self, *, initially_active: bool = True) -> None:
        self._active = threading.Event()
        if initially_active:
            self._active.set()
        self._last_changed_at: datetime = datetime.now(UTC)
        self._lock = threading.Lock()

    async def start(self) -> None:
        with self._lock:
            self._active.set()
            self._last_changed_at = datetime.now(UTC)

    async def pause(self) -> None:
        with self._lock:
            self._active.clear()
            self._last_changed_at = datetime.now(UTC)

    async def resume(self) -> None:
        await self.start()

    def is_active(self) -> bool:
        return self._active.is_set()

    @property
    def last_changed_at(self) -> datetime:
        return self._last_changed_at
