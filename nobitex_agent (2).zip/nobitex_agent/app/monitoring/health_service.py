"""Agent health/status tracking (ADDITIONAL_MODULE: AGENT_DASHBOARD_&_
SYSTEM_HEALTH). `AgentStatusSnapshot` is the single data model both the
Bale Control Center's "وضعیت ایجنت" and the web Dashboard render from —
one source of truth, two presentations (Persian text vs. Persian HTML).
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import UTC, datetime


@dataclass(frozen=True, slots=True)
class ServiceHealth:
    connected: bool
    detail: str | None = None  # Persian-ready reason when connected=False


@dataclass(frozen=True, slots=True)
class AgentStatusSnapshot:
    agent_active: bool
    monitoring_active: bool
    nobitex: ServiceHealth
    bale: ServiceHealth
    database: ServiceHealth
    enabled_symbol_count: int
    scan_interval_seconds: int
    timeframes: tuple[str, ...]
    last_scan_time: datetime | None
    next_scan_time: datetime | None
    alerts_today: int
    analyses_today: int
    last_error: str | None = None

    @property
    def degraded(self) -> bool:
        return not (self.nobitex.connected and self.bale.connected and self.database.connected)


class HealthService:
    """Tracks operational counters/timestamps in-memory for the running
    process, backed by `Database`'s daily-counter table for the
    "امروز" (today) figures so they survive a restart within the same
    UTC day. Connectivity (`nobitex`/`bale`/`database`) is supplied by
    the caller per snapshot (see `build_status_snapshot`) rather than
    actively probed here, since a probe itself is a network call that
    belongs in the orchestration layer, not this bookkeeping class."""

    def __init__(self) -> None:
        self._monitoring_active = False
        self._last_scan_time: datetime | None = None
        self._last_scan_monotonic: float | None = None
        self._last_error: str | None = None

    def set_monitoring_active(self, active: bool) -> None:
        self._monitoring_active = active

    def is_monitoring_active(self) -> bool:
        return self._monitoring_active

    def record_scan_success(self, at: datetime | None = None) -> None:
        self._last_scan_time = at or datetime.now(UTC)
        self._last_scan_monotonic = time.monotonic()
        self._last_error = None

    def record_scan_failure(self, reason: str, at: datetime | None = None) -> None:
        self._last_scan_time = at or datetime.now(UTC)
        self._last_scan_monotonic = time.monotonic()
        self._last_error = reason

    @property
    def last_scan_time(self) -> datetime | None:
        return self._last_scan_time

    @property
    def last_error(self) -> str | None:
        return self._last_error

    def next_scan_time(self, scan_interval_seconds: int) -> datetime | None:
        if self._last_scan_time is None:
            return None
        from datetime import timedelta
        return self._last_scan_time + timedelta(seconds=scan_interval_seconds)


def today_key(at: datetime | None = None) -> str:
    return (at or datetime.now(UTC)).strftime("%Y-%m-%d")


def build_status_snapshot(
    health: HealthService,
    nobitex: ServiceHealth,
    bale: ServiceHealth,
    database: ServiceHealth,
    enabled_symbol_count: int,
    scan_interval_seconds: int,
    timeframes: tuple[str, ...],
    alerts_today: int,
    analyses_today: int,
) -> AgentStatusSnapshot:
    return AgentStatusSnapshot(
        agent_active=True,
        monitoring_active=health.is_monitoring_active(),
        nobitex=nobitex, bale=bale, database=database,
        enabled_symbol_count=enabled_symbol_count,
        scan_interval_seconds=scan_interval_seconds,
        timeframes=timeframes,
        last_scan_time=health.last_scan_time,
        next_scan_time=health.next_scan_time(scan_interval_seconds),
        alerts_today=alerts_today,
        analyses_today=analyses_today,
        last_error=health.last_error,
    )
