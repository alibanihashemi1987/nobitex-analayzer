"""Persian formatting of `AgentStatusSnapshot` — pure functions, no I/O.
Used by both `app/reporting/` (Bale control center) and `app/web/`
(dashboard), so the two surfaces never drift out of sync.
"""

from __future__ import annotations

from app.monitoring.health_service import AgentStatusSnapshot, ServiceHealth

_GREEN = "\U0001F7E2"
_RED = "\U0001F534"
_PAUSE = "\u23F8"


def _dot(connected: bool) -> str:
    return _GREEN if connected else _RED


def format_status_text(snapshot: AgentStatusSnapshot) -> str:
    """Matches the canonical format in ADDITIONAL_MODULE:
    BALE_AGENT_CONTROL_CENTER / AGENT_DASHBOARD (plain-text, for Bale)."""
    monitoring_dot = _GREEN if snapshot.monitoring_active else _PAUSE
    lines = [
        f"{_GREEN if snapshot.agent_active else _RED} \u0648\u0636\u0639\u06cc\u062a Agent: "
        f"{'\u0641\u0639\u0627\u0644' if snapshot.agent_active else '\u063a\u06cc\u0631\u0641\u0639\u0627\u0644'}",
        f"{monitoring_dot} \u067e\u0627\u06cc\u0634 \u0628\u0627\u0632\u0627\u0631: "
        f"{'\u0641\u0639\u0627\u0644' if snapshot.monitoring_active else '\u0645\u062a\u0648\u0642\u0641'}",
        f"{_dot(snapshot.nobitex.connected)} \u0646\u0648\u0628\u06cc\u062a\u06a9\u0633: "
        f"{'\u0645\u062a\u0635\u0644' if snapshot.nobitex.connected else '\u0642\u0637\u0639'}",
        f"{_dot(snapshot.bale.connected)} Bale: "
        f"{'\u0645\u062a\u0635\u0644' if snapshot.bale.connected else '\u0642\u0637\u0639'}",
        f"{_dot(snapshot.database.connected)} Database: "
        f"{'\u0622\u0645\u0627\u062f\u0647' if snapshot.database.connected else '\u0642\u0637\u0639'}",
        "",
        f"\u0646\u0645\u0627\u062f\u0647\u0627\u06cc \u0641\u0639\u0627\u0644: {snapshot.enabled_symbol_count}",
        f"\u0641\u0627\u0635\u0644\u0647 \u067e\u0627\u06cc\u0634: {snapshot.scan_interval_seconds // 60} \u062f\u0642\u06cc\u0642\u0647",
        f"\u062a\u0627\u06cc\u0645\u200c\u0641\u0631\u06cc\u0645\u200c\u0647\u0627: {' / '.join(snapshot.timeframes)}",
        "",
        f"\u0622\u062e\u0631\u06cc\u0646 \u067e\u0627\u06cc\u0634:\n{snapshot.last_scan_time.strftime('%H:%M:%S') if snapshot.last_scan_time else '\u2014'}",
        f"\u067e\u0627\u06cc\u0634 \u0628\u0639\u062f\u06cc:\n{snapshot.next_scan_time.strftime('%H:%M:%S') if snapshot.next_scan_time else '\u2014'}",
        "",
        f"\u0647\u0634\u062f\u0627\u0631\u0647\u0627\u06cc \u0627\u0645\u0631\u0648\u0632: {snapshot.alerts_today}",
        f"\u062a\u062d\u0644\u06cc\u0644\u200c\u0647\u0627\u06cc \u0627\u0645\u0631\u0648\u0632: {snapshot.analyses_today}",
    ]

    if snapshot.degraded:
        lines.append("")
        lines.append(_degraded_block(snapshot))

    return "\n".join(lines)


def _degraded_block(snapshot: AgentStatusSnapshot) -> str:
    lines = ["\u26A0\uFE0F \u0648\u0636\u0639\u06cc\u062a \u0633\u06cc\u0633\u062a\u0645", ""]
    for label, health, ready_word in (
        ("\u0646\u0648\u0628\u06cc\u062a\u06a9\u0633", snapshot.nobitex, "\u0645\u062a\u0635\u0644"),
        ("Bale", snapshot.bale, "\u0645\u062a\u0635\u0644"),
        ("Database", snapshot.database, "\u0622\u0645\u0627\u062f\u0647"),
    ):
        status_word = ready_word if health.connected else "\u0642\u0637\u0639"
        lines.append(f"{label}: {_dot(health.connected)} {status_word}")
    lines.append(
        f"\u067e\u0627\u06cc\u0634: {_PAUSE if not snapshot.monitoring_active else _GREEN} "
        f"{'\u0645\u062a\u0648\u0642\u0641' if not snapshot.monitoring_active else '\u0641\u0639\u0627\u0644'}"
    )
    if snapshot.last_error:
        lines.append("")
        lines.append("\u0639\u0644\u062a:")
        lines.append(snapshot.last_error)
    return "\n".join(lines)


def service_health(connected: bool, reason_fa: str | None = None) -> ServiceHealth:
    return ServiceHealth(connected=connected, detail=reason_fa)
