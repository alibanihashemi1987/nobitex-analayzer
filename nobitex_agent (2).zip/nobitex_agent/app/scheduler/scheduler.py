from __future__ import annotations

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.config.scoring_config import ScoringConfig
from app.config.settings import Settings
from app.core.logging import get_logger
from app.data.nobitex.client import NobitexClient
from app.database.db import Database
from app.domain.enums import ExecutionMode, FinalDecision
from app.monitoring.health_service import HealthService, today_key
from app.notifications.bale.client import BaleClient
from app.runtime.monitoring_controller import MonitoringController
from app.services.analysis_service import run_dual_analysis
from app.services.signal_service import process_and_alert

logger = get_logger(__name__)


async def _resolve_symbols(db: Database, settings: Settings) -> list[str]:
    """Section 6 (DYNAMIC_NOBITEX_SYMBOL_&_WATCHLIST_MANAGER): the monitor
    scans exactly the enabled watchlist symbols. Falls back to
    `settings.default_symbol` only when the watchlist is empty (e.g. a
    fresh install before the user has added anything), so the agent
    isn't silently idle."""
    enabled = await db.get_watchlist(enabled_only=True)
    if enabled:
        return [row.symbol for row in enabled]
    return [settings.default_symbol]


def build_scheduler(
    settings: Settings,
    scoring_config: ScoringConfig,
    client: NobitexClient,
    db: Database,
    bale: BaleClient | None,
    symbols: list[str] | None = None,
    monitoring_controller: MonitoringController | None = None,
    health: HealthService | None = None,
) -> AsyncIOScheduler:
    """`symbols`, if given, overrides dynamic watchlist resolution (kept
    for the manual/CLI code path and tests); pass None to have every
    scan cycle pull the current enabled watchlist from the database, so
    a user editing their watchlist from the Bale Control Center or the
    web Dashboard takes effect on the very next cycle with no restart
    (ADDITIONAL_MODULE: BALE_AGENT_CONTROL_CENTER, "Do not restart the
    entire application unnecessarily when changing a setting")."""
    scheduler = AsyncIOScheduler()
    execution_mode = ExecutionMode(settings.execution_mode)

    async def scan_job() -> None:
        if monitoring_controller is not None and not monitoring_controller.is_active():
            logger.debug("scan_skipped_monitoring_paused")
            return

        active_symbols = symbols if symbols is not None else await _resolve_symbols(db, settings)
        any_failure: str | None = None
        for symbol in active_symbols:
            try:
                result = await run_dual_analysis(
                    client, scoring_config, symbol, execution_mode, settings.default_risk_profile,
                    candle_count=settings.candle_count,
                )
                signal_id = await process_and_alert(
                    result, db, bale, settings.alert_cooldown_seconds,
                    timeframe=scoring_config.mtf_timeframes.execution,
                    risk_profile=settings.default_risk_profile,
                )
                logger.info(
                    "scan_complete", symbol=symbol, final_decision=result.final_decision.value,
                    long_score=result.long_analysis.score, short_score=result.short_analysis.score,
                )
                if health is not None:
                    await db.increment_daily_counter("analyses_run", today_key())
                    if result.final_decision in (FinalDecision.BUY, FinalDecision.SELL) and signal_id:
                        await db.increment_daily_counter("alerts_sent", today_key())
            except Exception as exc:
                logger.exception("scan_job_failed", symbol=symbol)
                any_failure = f"{symbol}: {exc}"
                if health is not None:
                    await db.increment_daily_counter("scan_errors", today_key())

        if health is not None:
            if any_failure is not None:
                health.record_scan_failure(any_failure)
            else:
                health.record_scan_success()

    scheduler.add_job(
        scan_job,
        "interval",
        seconds=settings.scan_interval_seconds,
        id="market_scan",
        max_instances=1,
        coalesce=True,
    )
    return scheduler
