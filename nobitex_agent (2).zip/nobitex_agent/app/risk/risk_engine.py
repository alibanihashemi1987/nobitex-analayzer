"""Deterministic Entry / Stop Loss / TP1-3 calculation.

Rules:

- Entry = current close price (or a supplied POI midpoint, e.g. OB/FVG
  midpoint, when trading a retracement into a zone).
- Stop Loss = beyond the invalidation point of the POI (OB/FVG boundary or
  swept swing) plus an ATR-based buffer, so SL sits outside normal noise.
- TP1/TP2/TP3 = fixed R-multiples of the initial risk (1R, 2R, 3R by
  default, configurable), OR the next opposing liquidity/structure level
  if one is nearer than the R-multiple target (never further).

All values must produce a strictly positive risk (|entry - stop_loss| > 0)
or the setup is rejected as invalid (see InvalidSetupError).
"""

from __future__ import annotations

from app.core.exceptions import InvalidSetupError
from app.domain.enums import Direction
from app.domain.models import RiskLevels


def calculate_risk_levels(
    direction: Direction,
    entry: float,
    invalidation_level: float,
    atr_buffer: float,
    r_multiples: tuple[float, float, float] = (1.0, 2.0, 3.0),
    opposing_levels: list[float] | None = None,
) -> RiskLevels:
    if direction == Direction.BULLISH:
        stop_loss = invalidation_level - atr_buffer
        if stop_loss >= entry:
            raise InvalidSetupError("Stop loss must be below entry for a long setup.")
        risk = entry - stop_loss
        raw_targets = [entry + r * risk for r in r_multiples]
        if opposing_levels:
            nearer = [lvl for lvl in opposing_levels if lvl > entry]
            if nearer:
                raw_targets = [min(t, min(nearer)) if t > min(nearer) else t for t in raw_targets]
    else:
        stop_loss = invalidation_level + atr_buffer
        if stop_loss <= entry:
            raise InvalidSetupError("Stop loss must be above entry for a short setup.")
        risk = stop_loss - entry
        raw_targets = [entry - r * risk for r in r_multiples]
        if opposing_levels:
            nearer = [lvl for lvl in opposing_levels if lvl < entry]
            if nearer:
                raw_targets = [max(t, max(nearer)) if t < max(nearer) else t for t in raw_targets]

    tp1, tp2, tp3 = raw_targets

    if risk <= 0:
        raise InvalidSetupError("Computed risk is not strictly positive.")

    def _rr(target: float) -> float:
        return round(abs(target - entry) / risk, 3)

    return RiskLevels(
        entry=round(entry, 8),
        stop_loss=round(stop_loss, 8),
        tp1=round(tp1, 8),
        tp2=round(tp2, 8),
        tp3=round(tp3, 8),
        risk_reward_tp1=_rr(tp1),
        risk_reward_tp2=_rr(tp2),
        risk_reward_tp3=_rr(tp3),
    )
