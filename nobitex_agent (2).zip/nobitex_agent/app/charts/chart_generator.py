"""Chart generation: candlestick chart annotated with Entry/SL/TP levels."""

from __future__ import annotations

import io

import matplotlib
import mplfinance as mpf
import pandas as pd

matplotlib.use("Agg")  # headless rendering, safe for servers/containers

from app.domain.models import Candle, RiskLevels


def generate_signal_chart(candles: list[Candle], risk: RiskLevels | None = None, title: str = "") -> bytes:
    df = pd.DataFrame(
        {
            "Open": [c.open for c in candles],
            "High": [c.high for c in candles],
            "Low": [c.low for c in candles],
            "Close": [c.close for c in candles],
            "Volume": [c.volume for c in candles],
        },
        index=pd.DatetimeIndex([c.open_time for c in candles], name="Date"),
    )

    hlines = {}
    if risk is not None:
        hlines = {
            "hlines": [risk.entry, risk.stop_loss, risk.tp1, risk.tp2, risk.tp3],
            "colors": ["blue", "red", "green", "green", "green"],
            "linestyle": "--",
            "linewidths": 0.8,
        }

    buf = io.BytesIO()
    mpf.plot(
        df,
        type="candle",
        style="yahoo",
        title=title,
        volume=True,
        hlines=hlines if risk is not None else None,
        savefig=dict(fname=buf, format="png", dpi=150),
    )
    buf.seek(0)
    return buf.read()
