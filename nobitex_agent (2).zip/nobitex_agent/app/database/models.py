from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import JSON, DateTime, Float, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


def _uuid() -> str:
    return str(uuid.uuid4())


class SignalRecord(Base):
    __tablename__ = "signals"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    symbol: Mapped[str] = mapped_column(String, index=True)
    timeframe: Mapped[str] = mapped_column(String, index=True)
    decision: Mapped[str] = mapped_column(String)
    risk_profile: Mapped[str] = mapped_column(String, default="moderate")
    poi_type: Mapped[str | None] = mapped_column(String, nullable=True)

    entry: Mapped[float] = mapped_column(Float)
    stop_loss: Mapped[float] = mapped_column(Float)
    tp1: Mapped[float] = mapped_column(Float)
    tp2: Mapped[float] = mapped_column(Float)
    tp3: Mapped[float] = mapped_column(Float)
    rr_tp1: Mapped[float] = mapped_column(Float)
    rr_tp2: Mapped[float] = mapped_column(Float)
    rr_tp3: Mapped[float] = mapped_column(Float)

    score_breakdown: Mapped[dict] = mapped_column(JSON)
    total_score: Mapped[float] = mapped_column(Float)

    status: Mapped[str] = mapped_column(String, default="OPEN", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    outcome_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    time_to_target_seconds: Mapped[int | None] = mapped_column(nullable=True)
    time_to_stop_seconds: Mapped[int | None] = mapped_column(nullable=True)


class AnalysisRecord(Base):
    """Full dual-direction audit trail — one row per analysis cycle (live
    or backtest), regardless of whether a trade was ultimately taken.

    Schema follows REPLACEMENT_MODULE section 38 (Score Traceability) and
    MANDATORY_ARCHITECTURE_CHANGE section 22 (Backtest Result Schema):
    every cycle records BOTH directions' scores/status/levels, not just
    the winning one, so WAIT and CONFLICT periods remain analyzable.
    """

    __tablename__ = "analysis_records"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    symbol: Mapped[str] = mapped_column(String, index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    execution_mode: Mapped[str] = mapped_column(String)
    risk_profile: Mapped[str] = mapped_column(String, default="moderate")

    long_score: Mapped[float] = mapped_column(Float)
    long_status: Mapped[str] = mapped_column(String)
    long_execution_eligibility: Mapped[str] = mapped_column(String)
    long_market_risk: Mapped[str] = mapped_column(String)
    long_entry: Mapped[float | None] = mapped_column(Float, nullable=True)
    long_sl: Mapped[float | None] = mapped_column(Float, nullable=True)
    long_tp1: Mapped[float | None] = mapped_column(Float, nullable=True)
    long_tp2: Mapped[float | None] = mapped_column(Float, nullable=True)
    long_tp3: Mapped[float | None] = mapped_column(Float, nullable=True)
    long_rejection_reasons: Mapped[list] = mapped_column(JSON, default=list)
    long_score_breakdown: Mapped[dict] = mapped_column(JSON, default=dict)

    short_score: Mapped[float] = mapped_column(Float)
    short_status: Mapped[str] = mapped_column(String)
    short_execution_eligibility: Mapped[str] = mapped_column(String)
    short_market_risk: Mapped[str] = mapped_column(String)
    short_entry: Mapped[float | None] = mapped_column(Float, nullable=True)
    short_sl: Mapped[float | None] = mapped_column(Float, nullable=True)
    short_tp1: Mapped[float | None] = mapped_column(Float, nullable=True)
    short_tp2: Mapped[float | None] = mapped_column(Float, nullable=True)
    short_tp3: Mapped[float | None] = mapped_column(Float, nullable=True)
    short_rejection_reasons: Mapped[list] = mapped_column(JSON, default=list)
    short_score_breakdown: Mapped[dict] = mapped_column(JSON, default=dict)

    final_decision: Mapped[str] = mapped_column(String, index=True)
    final_reason: Mapped[str] = mapped_column(String)
    directional_winner: Mapped[str | None] = mapped_column(String, nullable=True)
    score_difference: Mapped[float | None] = mapped_column(Float, nullable=True)
    htf_tie_break_used: Mapped[bool] = mapped_column(default=False)

    linked_signal_id: Mapped[str | None] = mapped_column(String, nullable=True)

    # --- Full-fidelity payloads (BALE_REPORTING_ENGINE_REFACTOR) ---
    # Everything a DetailedReportGenerator needs to reconstruct a real
    # DirectionalAnalysis / MarketAnalysisResult WITHOUT recomputation —
    # see app/database/serialization.py. Nullable so older rows (written
    # before this column existed) don't break reads; `get_stored_market_
    # analysis_result` falls back gracefully when these are absent.
    long_full: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    short_full: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    market_overview: Mapped[dict | None] = mapped_column(JSON, nullable=True)


class WatchlistSymbolRecord(Base):
    """A user's personal, persisted symbol watchlist (ADDITIONAL_MODULE:
    DYNAMIC_NOBITEX_SYMBOL_&_WATCHLIST_MANAGER). The autonomous monitor
    scans exactly the rows with enabled=True, ordered by display_order."""

    __tablename__ = "watchlist_symbols"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    symbol: Mapped[str] = mapped_column(String, index=True, unique=True)  # e.g. "BTCUSDT"
    market_type: Mapped[str] = mapped_column(String)  # "RIAL" / "TETHER"
    enabled: Mapped[bool] = mapped_column(default=True)
    display_order: Mapped[int] = mapped_column(default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class RuntimeConfigRecord(Base):
    """Single-row table (fixed id="default") for every user-adjustable
    setting the Setup Wizard, Bale Control Center, and Dashboard can
    change without editing `.env`/`scoring_config.yaml` or restarting the
    process. This is deliberately separate from `app/config/settings.py`
    (deploy-time config) and `scoring_config.yaml` (strategy constants) —
    see CONFIGURATION.md's "three layers of configuration" section."""

    __tablename__ = "runtime_config"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: "default")
    setup_completed: Mapped[bool] = mapped_column(default=False)
    execution_mode: Mapped[str] = mapped_column(String, default="SPOT")
    risk_profile: Mapped[str] = mapped_column(String, default="moderate")
    scan_interval_seconds: Mapped[int] = mapped_column(default=300)
    enabled_timeframes: Mapped[list] = mapped_column(JSON, default=list)
    auto_monitoring_enabled: Mapped[bool] = mapped_column(default=True)
    scheduled_reports_enabled: Mapped[bool] = mapped_column(default=False)
    event_alerts_enabled: Mapped[bool] = mapped_column(default=True)
    alert_cooldown_seconds: Mapped[int] = mapped_column(default=1800)
    candle_close_reports_enabled: Mapped[bool] = mapped_column(default=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class DailyCounterRecord(Base):
    """Per-day operational counters for the Agent Dashboard / Bale status
    ("هشدارهای امروز", "تحلیل‌های امروز"). One row per calendar date
    (UTC), created on first use each day."""

    __tablename__ = "daily_counters"

    date: Mapped[str] = mapped_column(String, primary_key=True)  # "YYYY-MM-DD"
    alerts_sent: Mapped[int] = mapped_column(default=0)
    analyses_run: Mapped[int] = mapped_column(default=0)
    scan_errors: Mapped[int] = mapped_column(default=0)
