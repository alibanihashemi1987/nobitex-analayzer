from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import UTC, datetime

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.exceptions import DatabaseError
from app.database.models import (
    AnalysisRecord,
    Base,
    DailyCounterRecord,
    RuntimeConfigRecord,
    SignalRecord,
    WatchlistSymbolRecord,
)
from app.database.serialization import (
    directional_analysis_from_dict,
    directional_analysis_to_dict,
    market_overview_from_dict,
    market_overview_to_dict,
    score_breakdown_to_dict as _breakdown_to_dict,
)
from app.domain.directional import MarketAnalysisResult
from app.domain.enums import ExecutionMode, FinalDecision, SignalStatus
from app.domain.models import Signal


class Database:
    def __init__(self, database_url: str) -> None:
        self._engine = create_async_engine(database_url, future=True)
        self._session_factory = async_sessionmaker(self._engine, expire_on_commit=False)

    async def init_models(self) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    async def dispose(self) -> None:
        await self._engine.dispose()

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        async with self._session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception as exc:
                await session.rollback()
                raise DatabaseError(str(exc)) from exc

    async def save_signal(self, signal: Signal) -> str:
        async with self.session() as session:
            record = SignalRecord(
                symbol=signal.symbol,
                timeframe=signal.timeframe,
                decision=signal.decision.value,
                risk_profile=signal.risk_profile,
                poi_type=signal.poi_type,
                entry=signal.risk.entry,
                stop_loss=signal.risk.stop_loss,
                tp1=signal.risk.tp1,
                tp2=signal.risk.tp2,
                tp3=signal.risk.tp3,
                rr_tp1=signal.risk.risk_reward_tp1,
                rr_tp2=signal.risk.risk_reward_tp2,
                rr_tp3=signal.risk.risk_reward_tp3,
                score_breakdown=signal.confluence.component_scores,
                total_score=signal.confluence.total_score,
                status=signal.status.value,
                created_at=signal.created_at,
            )
            session.add(record)
            await session.flush()
            return record.id

    async def get_open_signals(self, symbol: str | None = None) -> list[SignalRecord]:
        async with self.session() as session:
            stmt = select(SignalRecord).where(SignalRecord.status == SignalStatus.OPEN.value)
            if symbol:
                stmt = stmt.where(SignalRecord.symbol == symbol)
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def update_outcome(
        self,
        signal_id: str,
        status: SignalStatus,
        outcome_time: datetime,
        time_to_target_seconds: int | None = None,
        time_to_stop_seconds: int | None = None,
    ) -> None:
        async with self.session() as session:
            await session.execute(
                update(SignalRecord)
                .where(SignalRecord.id == signal_id)
                .values(
                    status=status.value,
                    outcome_time=outcome_time,
                    time_to_target_seconds=time_to_target_seconds,
                    time_to_stop_seconds=time_to_stop_seconds,
                )
            )

    async def all_signals(self) -> list[SignalRecord]:
        async with self.session() as session:
            result = await session.execute(select(SignalRecord))
            return list(result.scalars().all())

    async def get_signal_by_id(self, signal_id: str) -> SignalRecord | None:
        async with self.session() as session:
            return await session.get(SignalRecord, signal_id)

    async def save_analysis_result(
        self, result: MarketAnalysisResult, risk_profile: str = "moderate", linked_signal_id: str | None = None
    ) -> str:
        """Persist a full dual-direction analysis cycle (section 38).
        Called every cycle regardless of the final decision, so WAIT and
        CONFLICT periods remain analyzable later (section 22-23)."""
        long_r = result.long_analysis.risk
        short_r = result.short_analysis.risk
        async with self.session() as session:
            record = AnalysisRecord(
                id=result.analysis_id,
                symbol=result.symbol,
                timestamp=result.timestamp,
                execution_mode=result.execution_mode.value,
                risk_profile=risk_profile,
                long_score=result.long_analysis.score,
                long_status=result.long_analysis.status.value,
                long_execution_eligibility=result.long_analysis.execution_eligibility.value,
                long_market_risk=result.long_analysis.market_risk.value,
                long_entry=long_r.entry if long_r else None,
                long_sl=long_r.stop_loss if long_r else None,
                long_tp1=long_r.tp1 if long_r else None,
                long_tp2=long_r.tp2 if long_r else None,
                long_tp3=long_r.tp3 if long_r else None,
                long_rejection_reasons=list(result.long_analysis.rejection_reasons),
                long_score_breakdown=_breakdown_to_dict(result.long_analysis.score_breakdown),
                short_score=result.short_analysis.score,
                short_status=result.short_analysis.status.value,
                short_execution_eligibility=result.short_analysis.execution_eligibility.value,
                short_market_risk=result.short_analysis.market_risk.value,
                short_entry=short_r.entry if short_r else None,
                short_sl=short_r.stop_loss if short_r else None,
                short_tp1=short_r.tp1 if short_r else None,
                short_tp2=short_r.tp2 if short_r else None,
                short_tp3=short_r.tp3 if short_r else None,
                short_rejection_reasons=list(result.short_analysis.rejection_reasons),
                short_score_breakdown=_breakdown_to_dict(result.short_analysis.score_breakdown),
                final_decision=result.final_decision.value,
                final_reason=result.final_reason,
                directional_winner=result.directional_winner,
                score_difference=result.score_difference,
                htf_tie_break_used=result.htf_tie_break_used,
                linked_signal_id=linked_signal_id,
                long_full=directional_analysis_to_dict(result.long_analysis),
                short_full=directional_analysis_to_dict(result.short_analysis),
                market_overview=market_overview_to_dict(result.market_overview),
            )
            session.add(record)
            await session.flush()
            return record.id

    async def all_analysis_records(self, symbol: str | None = None) -> list[AnalysisRecord]:
        async with self.session() as session:
            stmt = select(AnalysisRecord)
            if symbol:
                stmt = stmt.where(AnalysisRecord.symbol == symbol)
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def get_analysis_by_id(self, analysis_id: str) -> AnalysisRecord | None:
        async with self.session() as session:
            return await session.get(AnalysisRecord, analysis_id)

    async def get_stored_market_analysis_result(self, analysis_id: str) -> MarketAnalysisResult | None:
        """Reconstruct a full `MarketAnalysisResult` from a persisted
        `AnalysisRecord` — used exclusively by the Detailed Report path
        (BALE_REPORTING_ENGINE_REFACTOR section 10). Performs ZERO
        network I/O and ZERO re-analysis; it is pure deserialization via
        app/database/serialization.py. Returns None if the record is
        missing, or if it predates the `long_full`/`short_full` columns
        (older rows can't be fully reconstructed — the caller should
        show the "analysis no longer available" message in that case,
        exactly as it would for a missing record)."""
        record = await self.get_analysis_by_id(analysis_id)
        if record is None or record.long_full is None or record.short_full is None:
            return None
        return MarketAnalysisResult(
            symbol=record.symbol,
            timestamp=record.timestamp,
            long_analysis=directional_analysis_from_dict(record.long_full),
            short_analysis=directional_analysis_from_dict(record.short_full),
            final_decision=FinalDecision(record.final_decision),
            execution_mode=ExecutionMode(record.execution_mode),
            final_reason=record.final_reason,
            directional_winner=record.directional_winner,
            score_difference=record.score_difference,
            htf_tie_break_used=record.htf_tie_break_used,
            analysis_id=record.id,
            market_overview=market_overview_from_dict(record.market_overview),
        )

    # --- Watchlist (ADDITIONAL_MODULE: DYNAMIC_NOBITEX_SYMBOL_&_WATCHLIST_MANAGER) ---

    async def get_watchlist(self, enabled_only: bool = False) -> list[WatchlistSymbolRecord]:
        async with self.session() as session:
            stmt = select(WatchlistSymbolRecord).order_by(WatchlistSymbolRecord.display_order)
            if enabled_only:
                stmt = stmt.where(WatchlistSymbolRecord.enabled == True)  # noqa: E712
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def add_watchlist_symbol(self, symbol: str, market_type: str) -> WatchlistSymbolRecord:
        now = datetime.now(UTC)
        async with self.session() as session:
            existing = await session.execute(
                select(WatchlistSymbolRecord).where(WatchlistSymbolRecord.symbol == symbol)
            )
            row = existing.scalar_one_or_none()
            if row is not None:
                row.enabled = True
                row.updated_at = now
                await session.flush()
                return row

            count_result = await session.execute(select(WatchlistSymbolRecord))
            next_order = len(count_result.scalars().all())
            record = WatchlistSymbolRecord(
                symbol=symbol, market_type=market_type, enabled=True,
                display_order=next_order, created_at=now, updated_at=now,
            )
            session.add(record)
            await session.flush()
            return record

    async def remove_watchlist_symbol(self, symbol: str) -> bool:
        async with self.session() as session:
            existing = await session.execute(
                select(WatchlistSymbolRecord).where(WatchlistSymbolRecord.symbol == symbol)
            )
            row = existing.scalar_one_or_none()
            if row is None:
                return False
            await session.delete(row)
            return True

    async def set_watchlist_symbol_enabled(self, symbol: str, enabled: bool) -> bool:
        async with self.session() as session:
            result = await session.execute(
                update(WatchlistSymbolRecord)
                .where(WatchlistSymbolRecord.symbol == symbol)
                .values(enabled=enabled, updated_at=datetime.now(UTC))
            )
            return result.rowcount > 0

    async def reorder_watchlist(self, ordered_symbols: list[str]) -> None:
        async with self.session() as session:
            for i, symbol in enumerate(ordered_symbols):
                await session.execute(
                    update(WatchlistSymbolRecord)
                    .where(WatchlistSymbolRecord.symbol == symbol)
                    .values(display_order=i, updated_at=datetime.now(UTC))
                )

    # --- Runtime config (ADDITIONAL_MODULE: FIRST-RUN_SETUP & BALE_CONTROL_CENTER) ---

    async def get_runtime_config(self) -> RuntimeConfigRecord:
        async with self.session() as session:
            record = await session.get(RuntimeConfigRecord, "default")
            if record is None:
                record = RuntimeConfigRecord(
                    id="default", enabled_timeframes=["4H", "1H", "15M", "5M"],
                    updated_at=datetime.now(UTC),
                )
                session.add(record)
                await session.flush()
            return record

    async def update_runtime_config(self, **fields) -> RuntimeConfigRecord:
        async with self.session() as session:
            record = await session.get(RuntimeConfigRecord, "default")
            if record is None:
                record = RuntimeConfigRecord(id="default", updated_at=datetime.now(UTC))
                session.add(record)
            for key, value in fields.items():
                setattr(record, key, value)
            record.updated_at = datetime.now(UTC)
            await session.flush()
            return record

    # --- Daily counters (ADDITIONAL_MODULE: AGENT_DASHBOARD_&_SYSTEM_HEALTH) ---

    async def increment_daily_counter(self, field: str, date_str: str) -> None:
        async with self.session() as session:
            record = await session.get(DailyCounterRecord, date_str)
            if record is None:
                record = DailyCounterRecord(date=date_str)
                session.add(record)
                await session.flush()
            setattr(record, field, getattr(record, field) + 1)

    async def get_daily_counter(self, date_str: str) -> DailyCounterRecord | None:
        async with self.session() as session:
            return await session.get(DailyCounterRecord, date_str)
