"""Serialize / deserialize domain analysis objects to/from plain dicts.

This module is the single place that knows how to turn a
`DirectionalAnalysis` / `MarketOverview` into JSON-storable data and
back. It has ZERO dependency on SQLAlchemy or any I/O library — `db.py`
calls into this to build the JSON columns it persists, and the
reporting layer's Detailed Report path calls the `*_from_dict`
functions to reconstruct a real `MarketAnalysisResult` from a stored
record WITHOUT ever re-running the analysis engine (BALE_REPORTING_
ENGINE_REFACTOR section 10).

Round-tripping through these functions must be lossless for every field
the reports need: scores, per-factor evidence, the Primary POI, risk
levels (including R:R), rejection reasons, HTF alignment, execution
eligibility, and the market overview.
"""

from __future__ import annotations

from datetime import datetime

from app.domain.directional import DirectionalAnalysis, MarketOverview, TimeframeOverview
from app.domain.enums import (
    Direction,
    ExecutionEligibility,
    HTFAlignmentStrength,
    MarketRiskLevel,
    TechnicalStatus,
)
from app.domain.events import POIEvent, ScoreBreakdown, ScoreFactor
from app.domain.models import RiskLevels


def score_breakdown_to_dict(breakdown: ScoreBreakdown) -> dict:
    return {
        "structure": breakdown.structure, "poi": breakdown.poi, "liquidity": breakdown.liquidity,
        "momentum": breakdown.momentum, "mtf": breakdown.mtf, "orderbook": breakdown.orderbook,
        "execution": breakdown.execution, "premium_discount": breakdown.premium_discount,
        "total": breakdown.total,
        "factors": [
            {"factor_id": f.factor_id, "category": f.category, "name": f.name,
             "awarded_points": f.awarded_points, "maximum_points": f.maximum_points,
             "evidence": f.evidence, "event_ids": list(f.event_ids)}
            for f in breakdown.factors
        ],
    }


def score_breakdown_from_dict(d: dict) -> ScoreBreakdown:
    factors = tuple(
        ScoreFactor(
            factor_id=f["factor_id"], category=f["category"], name=f["name"],
            awarded_points=f["awarded_points"], maximum_points=f["maximum_points"],
            evidence=f["evidence"], event_ids=tuple(f.get("event_ids", ())),
        )
        for f in d.get("factors", [])
    )
    return ScoreBreakdown(
        structure=d["structure"], poi=d["poi"], liquidity=d["liquidity"], momentum=d["momentum"],
        mtf=d["mtf"], orderbook=d["orderbook"], execution=d["execution"],
        premium_discount=d["premium_discount"], total=d["total"], factors=factors,
    )


def poi_to_dict(poi: POIEvent | None) -> dict | None:
    if poi is None:
        return None
    return {
        "event_id": poi.event_id, "poi_type": poi.poi_type, "symbol": poi.symbol,
        "timeframe": poi.timeframe, "direction": poi.direction,
        "zone_high": poi.zone_high, "zone_low": poi.zone_low,
        "created_at": poi.created_at.isoformat() if poi.created_at else None,
        "mitigation_status": poi.mitigation_status,
        "structural_event_id": poi.structural_event_id,
    }


def poi_from_dict(d: dict | None) -> POIEvent | None:
    if d is None:
        return None
    return POIEvent(
        event_id=d["event_id"], poi_type=d["poi_type"], symbol=d["symbol"],
        timeframe=d["timeframe"], direction=d["direction"],
        zone_high=d["zone_high"], zone_low=d["zone_low"],
        created_at=datetime.fromisoformat(d["created_at"]) if d.get("created_at") else None,
        mitigation_status=d["mitigation_status"],
        structural_event_id=d.get("structural_event_id"),
    )


def risk_to_dict(risk: RiskLevels | None) -> dict | None:
    if risk is None:
        return None
    return {
        "entry": risk.entry, "stop_loss": risk.stop_loss,
        "tp1": risk.tp1, "tp2": risk.tp2, "tp3": risk.tp3,
        "risk_reward_tp1": risk.risk_reward_tp1, "risk_reward_tp2": risk.risk_reward_tp2,
        "risk_reward_tp3": risk.risk_reward_tp3,
    }


def risk_from_dict(d: dict | None) -> RiskLevels | None:
    if d is None:
        return None
    return RiskLevels(**d)


def directional_analysis_to_dict(da: DirectionalAnalysis) -> dict:
    return {
        "direction": da.direction,
        "status": da.status.value,
        "execution_eligibility": da.execution_eligibility.value,
        "execution_ineligibility_reason": da.execution_ineligibility_reason,
        "score_breakdown": score_breakdown_to_dict(da.score_breakdown),
        "execution_quality": da.execution_quality,
        "market_risk": da.market_risk.value,
        "htf_alignment": da.htf_alignment.value,
        "hard_gates_passed": da.hard_gates_passed,
        "hard_gate_failures": list(da.hard_gate_failures),
        "primary_poi": poi_to_dict(da.primary_poi),
        "risk": risk_to_dict(da.risk),
        "rejection_reasons": list(da.rejection_reasons),
        "early_ltf_entry": da.early_ltf_entry,
    }


def directional_analysis_from_dict(d: dict) -> DirectionalAnalysis:
    return DirectionalAnalysis(
        direction=d["direction"],
        status=TechnicalStatus(d["status"]),
        execution_eligibility=ExecutionEligibility(d["execution_eligibility"]),
        execution_ineligibility_reason=d.get("execution_ineligibility_reason"),
        score_breakdown=score_breakdown_from_dict(d["score_breakdown"]),
        execution_quality=d["execution_quality"],
        market_risk=MarketRiskLevel(d["market_risk"]),
        htf_alignment=HTFAlignmentStrength(d["htf_alignment"]),
        hard_gates_passed=d["hard_gates_passed"],
        hard_gate_failures=tuple(d.get("hard_gate_failures", ())),
        primary_poi=poi_from_dict(d.get("primary_poi")),
        risk=risk_from_dict(d.get("risk")),
        rejection_reasons=tuple(d.get("rejection_reasons", ())),
        early_ltf_entry=d.get("early_ltf_entry", False),
    )


def _tf_overview_to_dict(o: TimeframeOverview) -> dict:
    return {"role": o.role, "timeframe": o.timeframe, "trend": o.trend.value if o.trend else None}


def _tf_overview_from_dict(d: dict) -> TimeframeOverview:
    return TimeframeOverview(
        role=d["role"], timeframe=d["timeframe"],
        trend=Direction(d["trend"]) if d.get("trend") else None,
    )


def market_overview_to_dict(mo: MarketOverview | None) -> dict | None:
    if mo is None:
        return None
    return {
        "htf": _tf_overview_to_dict(mo.htf), "mtf": _tf_overview_to_dict(mo.mtf),
        "ltf": _tf_overview_to_dict(mo.ltf), "execution": _tf_overview_to_dict(mo.execution),
        "price_above_ma200": mo.price_above_ma200.value if mo.price_above_ma200 else None,
        "ma20_above_ma200": mo.ma20_above_ma200,
    }


def market_overview_from_dict(d: dict | None) -> MarketOverview | None:
    if d is None:
        return None
    return MarketOverview(
        htf=_tf_overview_from_dict(d["htf"]), mtf=_tf_overview_from_dict(d["mtf"]),
        ltf=_tf_overview_from_dict(d["ltf"]), execution=_tf_overview_from_dict(d["execution"]),
        price_above_ma200=Direction(d["price_above_ma200"]) if d.get("price_above_ma200") else None,
        ma20_above_ma200=d.get("ma20_above_ma200"),
    )
