"""Signal outcome tracking.

Evaluates OPEN signals against subsequently CLOSED candles only —
never against the currently forming candle. If a single candle's range
contains both a TP and the SL, the deterministic tie-break rule is:

    SL is evaluated first (worst-case / conservative assumption),
    UNLESS the candle's OPEN price is already beyond the TP in the
    signal's favor, in which case TP is assumed hit first.

This conservative default avoids overstating performance from ambiguous
candles. The rule is documented in STRATEGY.md and must not be changed
without updating the docs.
"""

from __future__ import annotations

from app.database.db import Database
from app.database.models import SignalRecord
from app.domain.enums import SignalDecision, SignalStatus
from app.domain.models import Candle


def evaluate_signal(record: SignalRecord, closed_candles_after_signal: list[Candle]) -> tuple[SignalStatus, Candle | None]:
    """Return the first terminal status reached, and the candle it occurred on."""
    is_long = record.decision == SignalDecision.BUY.value

    for candle in closed_candles_after_signal:
        hit_sl = candle.low <= record.stop_loss if is_long else candle.high >= record.stop_loss
        hit_tp3 = candle.high >= record.tp3 if is_long else candle.low <= record.tp3
        hit_tp2 = candle.high >= record.tp2 if is_long else candle.low <= record.tp2
        hit_tp1 = candle.high >= record.tp1 if is_long else candle.low <= record.tp1

        if hit_sl and (hit_tp1 or hit_tp2 or hit_tp3):
            # Ambiguous candle: apply the documented conservative tie-break.
            open_already_past_tp1 = (
                candle.open >= record.tp1 if is_long else candle.open <= record.tp1
            )
            if not open_already_past_tp1:
                return SignalStatus.SL_HIT, candle

        if hit_tp3:
            return SignalStatus.TP3_HIT, candle
        if hit_sl:
            return SignalStatus.SL_HIT, candle
        if hit_tp2:
            return SignalStatus.TP2_HIT, candle
        if hit_tp1:
            return SignalStatus.TP1_HIT, candle

    return SignalStatus.OPEN, None


async def update_open_signals(
    db: Database, closed_candles_by_symbol_tf: dict[tuple[str, str], list[Candle]]
) -> None:
    open_records = await db.get_open_signals()
    for record in open_records:
        key = (record.symbol, record.timeframe)
        candles = closed_candles_by_symbol_tf.get(key, [])
        after_signal = [c for c in candles if c.open_time > record.created_at]
        status, candle = evaluate_signal(record, after_signal)
        if status != SignalStatus.OPEN and candle is not None:
            seconds_to_outcome = int((candle.close_time - record.created_at).total_seconds())
            await db.update_outcome(
                record.id,
                status,
                candle.close_time,
                time_to_target_seconds=(
                    seconds_to_outcome if status in (
                        SignalStatus.TP1_HIT, SignalStatus.TP2_HIT, SignalStatus.TP3_HIT
                    ) else None
                ),
                time_to_stop_seconds=(
                    seconds_to_outcome if status == SignalStatus.SL_HIT else None
                ),
            )


def compute_performance_report(records: list[SignalRecord]) -> dict:
    closed = [r for r in records if r.status != SignalStatus.OPEN.value]
    total = len(closed)
    wins = [r for r in closed if r.status in (
        SignalStatus.TP1_HIT.value, SignalStatus.TP2_HIT.value, SignalStatus.TP3_HIT.value
    )]
    losses = [r for r in closed if r.status == SignalStatus.SL_HIT.value]
    expired = [r for r in closed if r.status == SignalStatus.EXPIRED.value]

    def _pct(sub: list, whole: list) -> float:
        return round(100 * len(sub) / len(whole), 2) if whole else 0.0

    def _group_by(key: str) -> dict[str, dict]:
        groups: dict[str, list[SignalRecord]] = {}
        for r in closed:
            groups.setdefault(getattr(r, key), []).append(r)
        return {
            k: {
                "total": len(v),
                "win_rate": _pct([r for r in v if r in wins], v),
            }
            for k, v in groups.items()
        }

    return {
        "total_signals": len(records),
        "closed_signals": total,
        "winning_signals": len(wins),
        "losing_signals": len(losses),
        "win_rate_pct": _pct(wins, closed),
        "avg_rr": round(sum(r.rr_tp1 for r in closed) / total, 3) if total else 0.0,
        "avg_score": round(sum(r.total_score for r in closed) / total, 2) if total else 0.0,
        "tp1_hit_rate_pct": _pct([r for r in closed if r.status == SignalStatus.TP1_HIT.value], closed),
        "tp2_hit_rate_pct": _pct([r for r in closed if r.status == SignalStatus.TP2_HIT.value], closed),
        "tp3_hit_rate_pct": _pct([r for r in closed if r.status == SignalStatus.TP3_HIT.value], closed),
        "sl_hit_rate_pct": _pct(losses, closed),
        "expired_setups": len(expired),
        "by_symbol": _group_by("symbol"),
        "by_timeframe": _group_by("timeframe"),
        "by_poi_type": _group_by("poi_type"),
        "by_risk_profile": _group_by("risk_profile"),
    }
