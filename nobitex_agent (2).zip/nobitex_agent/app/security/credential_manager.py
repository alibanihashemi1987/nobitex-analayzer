"""Picks a `CredentialStore` backend automatically and exposes named
credential slots. This is what the rest of the app actually imports —
callers never construct `KeyringCredentialStore`/`EncryptedFileCredentialStore`
directly.

Selection order (section 3): try the OS-native keyring first (desktop
Linux/macOS/Windows); if it's unavailable or unusable — the realistic
case for a headless server/Docker deployment, which is how this agent
is most often actually run (see DEPLOYMENT.md) — fall back to the
encrypted-file store. The choice is logged once at startup so an
operator can see which backend is active; it is never silently mixed
mid-run.
"""

from __future__ import annotations

from app.core.logging import get_logger
from app.security.credential_store import CredentialStore, EncryptedFileCredentialStore

logger = get_logger(__name__)

# Named credential slots — the ONLY strings that should be passed as
# `key` to CredentialManager.save/get/delete. Centralized here so a
# typo doesn't silently create a new, unrelated credential slot.
NOBITEX_API_KEY = "nobitex_api_key"
NOBITEX_API_SECRET = "nobitex_api_secret"
BALE_BOT_TOKEN = "bale_bot_token"
BALE_CHAT_ID = "bale_chat_id"


def _construct_keyring_store() -> CredentialStore | None:
    try:
        from app.security.credential_store import KeyringCredentialStore

        return KeyringCredentialStore()
    except Exception as exc:  # noqa: BLE001 - deliberately broad: any
        # keyring backend failure should fall back, not crash startup.
        logger.info("keyring_backend_unavailable", reason=str(exc))
        return None


class CredentialManager:
    def __init__(self, data_dir: str = "./data") -> None:
        self._data_dir = data_dir
        self._store: CredentialStore | None = None
        self._backend_name: str = "uninitialized"
        self._keyring_failed = False

    def _ensure_store(self) -> CredentialStore:
        if self._store is not None:
            return self._store
        keyring_store = None if self._keyring_failed else _construct_keyring_store()
        if keyring_store is not None:
            self._store = keyring_store
            self._backend_name = "keyring"
        else:
            self._store = EncryptedFileCredentialStore(self._data_dir)
            self._backend_name = "encrypted_file"
        logger.info("credential_backend_selected", backend=self._backend_name)
        return self._store

    def _fallback_to_encrypted_file(self, reason: str) -> CredentialStore:
        """Called when the keyring backend fails at actual use time (e.g.
        no Secret Service session on a headless Linux server — python-keyring
        often only surfaces this on first real call, not at construction).
        Downgrades permanently for this process's lifetime."""
        logger.warning("keyring_backend_failed_at_runtime", reason=reason)
        self._keyring_failed = True
        self._store = EncryptedFileCredentialStore(self._data_dir)
        self._backend_name = "encrypted_file"
        return self._store

    @property
    def backend_name(self) -> str:
        self._ensure_store()
        return self._backend_name

    async def save(self, key: str, value: str) -> None:
        store = self._ensure_store()
        try:
            await store.save(key, value)
        except Exception as exc:  # noqa: BLE001
            if self._backend_name == "keyring":
                store = self._fallback_to_encrypted_file(str(exc))
                await store.save(key, value)
            else:
                raise

    async def get(self, key: str) -> str | None:
        store = self._ensure_store()
        try:
            return await store.get(key)
        except Exception as exc:  # noqa: BLE001
            if self._backend_name == "keyring":
                store = self._fallback_to_encrypted_file(str(exc))
                return await store.get(key)
            raise

    async def delete(self, key: str) -> None:
        store = self._ensure_store()
        try:
            await store.delete(key)
        except Exception as exc:  # noqa: BLE001
            if self._backend_name == "keyring":
                self._fallback_to_encrypted_file(str(exc))
                # deletion is idempotent — nothing to retry on the new backend
            else:
                raise

    async def save_nobitex_credentials(self, api_key: str, api_secret: str) -> None:
        await self.save(NOBITEX_API_KEY, api_key)
        await self.save(NOBITEX_API_SECRET, api_secret)

    async def get_nobitex_credentials(self) -> tuple[str | None, str | None]:
        return await self.get(NOBITEX_API_KEY), await self.get(NOBITEX_API_SECRET)

    async def save_bale_credentials(self, bot_token: str, chat_id: str) -> None:
        await self.save(BALE_BOT_TOKEN, bot_token)
        await self.save(BALE_CHAT_ID, chat_id)

    async def get_bale_credentials(self) -> tuple[str | None, str | None]:
        return await self.get(BALE_BOT_TOKEN), await self.get(BALE_CHAT_ID)

    async def clear_all(self) -> None:
        for key in (NOBITEX_API_KEY, NOBITEX_API_SECRET, BALE_BOT_TOKEN, BALE_CHAT_ID):
            await self.delete(key)
