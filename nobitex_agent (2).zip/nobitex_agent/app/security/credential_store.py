"""Secure credential storage (ADDITIONAL_MODULE: FIRST-RUN_SETUP &
CREDENTIAL_MANAGEMENT section 3).

Nobitex API keys and the Bale bot token are NEVER written to SQLite (or
anywhere else) as plaintext. Two backends implement the same
`CredentialStore` protocol:

- `KeyringCredentialStore`: the OS's native secure storage (macOS
  Keychain / Windows Credential Manager / Linux Secret Service), via the
  optional `keyring` package. Used automatically when both the package
  AND a working backend are available.
- `EncryptedFileCredentialStore`: a Fernet-encrypted (AES-128-CBC + HMAC,
  via the `cryptography` package) local file, used whenever a working OS
  keyring isn't available — e.g. a headless Linux container with no
  Secret Service daemon running. The encryption key is itself stored in
  a separate file with restrictive (owner-only) permissions; this is
  materially better than plaintext but is NOT equivalent to a real OS
  keychain (documented honestly in DEPLOYMENT.md) — it protects against
  casual disk inspection / accidental commits, not a determined local
  attacker with the same OS-user privileges as the running process.

`get_default_credential_store()` picks whichever backend actually works
at runtime, trying keyring first.
"""

from __future__ import annotations

import stat
from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class CredentialStore(Protocol):
    async def save(self, key: str, value: str) -> None: ...
    async def get(self, key: str) -> str | None: ...
    async def delete(self, key: str) -> None: ...


_SERVICE_NAME = "nobitex-trading-agent"


class KeyringCredentialStore:
    """Wraps the optional `keyring` package. `keyring` is a synchronous
    library; calls are offloaded to a thread so this class still
    satisfies the async `CredentialStore` protocol without blocking the
    event loop."""

    def __init__(self) -> None:
        import keyring  # noqa: F401  -- raises ImportError if not installed
        self._keyring = keyring

    async def save(self, key: str, value: str) -> None:
        import asyncio
        await asyncio.to_thread(self._keyring.set_password, _SERVICE_NAME, key, value)

    async def get(self, key: str) -> str | None:
        import asyncio
        return await asyncio.to_thread(self._keyring.get_password, _SERVICE_NAME, key)

    async def delete(self, key: str) -> None:
        import asyncio
        try:
            await asyncio.to_thread(self._keyring.delete_password, _SERVICE_NAME, key)
        except Exception:
            pass  # already absent — deleting a nonexistent credential is not an error

    @staticmethod
    def is_available() -> bool:
        """True only if `keyring` is importable AND a real backend
        responds (not the library's own no-op `fail.Keyring` fallback,
        which raises on every call)."""
        try:
            import keyring
            backend = keyring.get_keyring()
            return backend.__class__.__module__ != "keyring.backends.fail"
        except Exception:
            return False


class EncryptedFileCredentialStore:
    """Fernet-encrypted JSON file fallback. `storage_dir` holds two files:
    `credentials.enc` (the encrypted key/value store) and `credentials.key`
    (the Fernet key, `0600` permissions on POSIX)."""

    def __init__(self, storage_dir: str | Path) -> None:
        self._dir = Path(storage_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._key_path = self._dir / "credentials.key"
        self._data_path = self._dir / "credentials.enc"
        self._fernet = self._load_or_create_fernet()

    def _load_or_create_fernet(self):
        from cryptography.fernet import Fernet

        if self._key_path.exists():
            key = self._key_path.read_bytes()
        else:
            key = Fernet.generate_key()
            self._key_path.write_bytes(key)
            try:
                self._key_path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0600, owner read/write only
            except (OSError, NotImplementedError):
                pass  # best-effort on platforms without POSIX chmod (e.g. some Windows setups)
        return Fernet(key)

    def _read_all(self) -> dict[str, str]:
        import json

        if not self._data_path.exists():
            return {}
        encrypted = self._data_path.read_bytes()
        if not encrypted:
            return {}
        decrypted = self._fernet.decrypt(encrypted)
        return json.loads(decrypted.decode("utf-8"))

    def _write_all(self, data: dict[str, str]) -> None:
        import json

        encrypted = self._fernet.encrypt(json.dumps(data).encode("utf-8"))
        self._data_path.write_bytes(encrypted)
        try:
            self._data_path.chmod(stat.S_IRUSR | stat.S_IWUSR)
        except (OSError, NotImplementedError):
            pass

    async def save(self, key: str, value: str) -> None:
        data = self._read_all()
        data[key] = value
        self._write_all(data)

    async def get(self, key: str) -> str | None:
        return self._read_all().get(key)

    async def delete(self, key: str) -> None:
        data = self._read_all()
        if key in data:
            del data[key]
            self._write_all(data)


def get_default_credential_store(storage_dir: str | Path = "./data") -> CredentialStore:
    """Prefer the OS keyring; fall back to the encrypted file store when
    no working keyring backend is present (the common case in a headless
    server/container deployment)."""
    if KeyringCredentialStore.is_available():
        try:
            return KeyringCredentialStore()
        except ImportError:
            pass
    return EncryptedFileCredentialStore(storage_dir)
