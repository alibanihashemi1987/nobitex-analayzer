"""Liquidity Sweep detection.

A liquidity sweep occurs when a candle's wick trades beyond a confirmed
swing point (taking the resting liquidity there) and the candle's CLOSE
reverses back to the opposite side of that level within a configurable
number of subsequent closed candles (`confirmation_candles`), confirming
rejection rather than genuine continuation.

- Bullish sweep: wick trades below a confirmed swing LOW, close reverses
  back above it -> sell-side liquidity swept, bullish reversal signal.
- Bearish sweep: wick trades above a confirmed swing HIGH, close reverses
  back below it -> buy-side liquidity swept, bearish reversal signal.
"""

from __future__ import annotations

from app.domain.enums import Direction
from app.domain.models import Candle, LiquiditySweep, SwingPoint
from app.indicators.swings import detect_swings, swing_highs, swing_lows


def detect_liquidity_sweeps(
    closed_candles: list[Candle],
    swing_lookback: int = 2,
    confirmation_candles: int = 3,
) -> list[LiquiditySweep]:
    swings = detect_swings(closed_candles, lookback=swing_lookback)
    highs = swing_highs(swings)
    lows = swing_lows(swings)

    sweeps: list[LiquiditySweep] = []
    sweeps.extend(_scan(closed_candles, lows, confirmation_candles, sweeping_low=True))
    sweeps.extend(_scan(closed_candles, highs, confirmation_candles, sweeping_low=False))
    sweeps.sort(key=lambda s: s.sweep_candle_index)
    return sweeps


def _scan(
    closed_candles: list[Candle],
    swings: list[SwingPoint],
    confirmation_candles: int,
    sweeping_low: bool,
) -> list[LiquiditySweep]:
    results: list[LiquiditySweep] = []
    for swing in swings:
        for i in range(swing.index + 1, len(closed_candles)):
            c = closed_candles[i]
            wick_beyond = c.low < swing.price if sweeping_low else c.high > swing.price
            if not wick_beyond:
                continue

            reversal_confirmed = False
            for k in range(i, min(i + confirmation_candles, len(closed_candles))):
                confirm_candle = closed_candles[k]
                if sweeping_low and confirm_candle.close > swing.price:
                    reversal_confirmed = True
                    break
                if not sweeping_low and confirm_candle.close < swing.price:
                    reversal_confirmed = True
                    break

            results.append(
                LiquiditySweep(
                    direction=Direction.BULLISH if sweeping_low else Direction.BEARISH,
                    swept_level=swing.price,
                    swept_swing=swing,
                    sweep_candle_index=i,
                    sweep_time=c.open_time,
                    reversal_confirmed=reversal_confirmed,
                )
            )
            break  # only report the first sweep of a given swing point
    return results
