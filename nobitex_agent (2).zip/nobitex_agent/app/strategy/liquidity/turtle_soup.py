"""Turtle Soup: a failed breakout of a prior N-candle high/low that closes
back inside the prior range on the very next closed candle. This is a
stricter, single-candle-confirmation subset of a general liquidity sweep.
"""

from __future__ import annotations

from app.domain.enums import Direction
from app.domain.models import Candle, TurtleSoup


def detect_turtle_soups(closed_candles: list[Candle], lookback_period: int = 20) -> list[TurtleSoup]:
    results: list[TurtleSoup] = []
    n = len(closed_candles)

    for i in range(lookback_period, n):
        window = closed_candles[i - lookback_period : i]
        prior_high = max(c.high for c in window)
        prior_low = min(c.low for c in window)
        c = closed_candles[i]

        if c.high > prior_high and c.close < prior_high:
            results.append(
                TurtleSoup(
                    direction=Direction.BEARISH,
                    failed_breakout_level=prior_high,
                    candle_index=i,
                    time=c.open_time,
                )
            )
        elif c.low < prior_low and c.close > prior_low:
            results.append(
                TurtleSoup(
                    direction=Direction.BULLISH,
                    failed_breakout_level=prior_low,
                    candle_index=i,
                    time=c.open_time,
                )
            )

    return results
