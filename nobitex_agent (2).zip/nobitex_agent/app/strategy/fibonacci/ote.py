"""OTE (Optimal Trade Entry) zone: the 0.618-0.79 retracement of the most
recent confirmed impulse leg (last swing-low-to-swing-high or vice versa).
"""

from __future__ import annotations

from app.domain.enums import Direction
from app.domain.models import Candle, OTEZone
from app.indicators.swings import detect_swings


def detect_ote_zone(closed_candles: list[Candle], swing_lookback: int = 2) -> OTEZone | None:
    swings = detect_swings(closed_candles, lookback=swing_lookback)
    if len(swings) < 2:
        return None

    a, b = swings[-2], swings[-1]
    if a.direction == b.direction:
        return None  # need an alternating low->high or high->low leg

    if a.direction.value == "BULLISH":  # low -> high => bullish leg, retrace for longs
        leg_start, leg_end = a.price, b.price
        direction = Direction.BULLISH
        rng = leg_end - leg_start
        fib_618 = leg_end - 0.618 * rng
        fib_705 = leg_end - 0.705 * rng
        fib_79 = leg_end - 0.79 * rng
    else:  # high -> low => bearish leg, retrace for shorts
        leg_start, leg_end = a.price, b.price
        direction = Direction.BEARISH
        rng = leg_start - leg_end
        fib_618 = leg_end + 0.618 * rng
        fib_705 = leg_end + 0.705 * rng
        fib_79 = leg_end + 0.79 * rng

    current_price = closed_candles[-1].close
    low_bound, high_bound = sorted((fib_618, fib_79))
    in_zone = low_bound <= current_price <= high_bound

    return OTEZone(
        direction=direction,
        fib_618=fib_618,
        fib_705=fib_705,
        fib_79=fib_79,
        leg_start=leg_start,
        leg_end=leg_end,
        in_zone=in_zone,
    )
