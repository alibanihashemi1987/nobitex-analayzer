"""Premium / Discount zone relative to the current dealing range.

Dealing range = highest high / lowest low over the last `range_period`
CLOSED candles. Equilibrium = 50% of that range.

Price above equilibrium -> PREMIUM (favor shorts / distribution).
Price below equilibrium -> DISCOUNT (favor longs / accumulation).
Within +/-`equilibrium_band_pct` of equilibrium -> EQUILIBRIUM (neutral).
"""

from __future__ import annotations

from app.domain.enums import ZoneType
from app.domain.models import Candle, PremiumDiscountZone


def detect_premium_discount(
    closed_candles: list[Candle],
    range_period: int = 50,
    equilibrium_band_pct: float = 0.05,
) -> PremiumDiscountZone | None:
    if len(closed_candles) < range_period:
        return None

    window = closed_candles[-range_period:]
    range_high = max(c.high for c in window)
    range_low = min(c.low for c in window)
    equilibrium = (range_high + range_low) / 2
    current_price = closed_candles[-1].close

    band = (range_high - range_low) * equilibrium_band_pct
    if abs(current_price - equilibrium) <= band:
        zone = ZoneType.EQUILIBRIUM
    elif current_price > equilibrium:
        zone = ZoneType.PREMIUM
    else:
        zone = ZoneType.DISCOUNT

    return PremiumDiscountZone(
        range_high=range_high,
        range_low=range_low,
        equilibrium=equilibrium,
        current_zone=zone,
        current_price=current_price,
    )
