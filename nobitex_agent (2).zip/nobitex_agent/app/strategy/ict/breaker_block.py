"""Breaker Block detection.

A Breaker Block forms when an Order Block reaches MitigationState.INVALIDATED
(price closed fully through it) — it then flips role: a former bullish OB
that is invalidated becomes a bearish breaker (resistance), and vice versa.
A retest is recorded the first time price returns into the breaker's zone
after the invalidation candle.
"""

from __future__ import annotations

from app.domain.enums import Direction, MitigationState
from app.domain.models import BreakerBlock, Candle, OrderBlock


def detect_breaker_blocks(
    closed_candles: list[Candle], order_blocks: list[OrderBlock]
) -> list[BreakerBlock]:
    breakers: list[BreakerBlock] = []

    for ob in order_blocks:
        if ob.mitigation_state != MitigationState.INVALIDATED:
            continue

        invalidation_idx = _find_invalidation_index(closed_candles, ob)
        if invalidation_idx is None:
            continue

        new_direction = (
            Direction.BEARISH if ob.direction == Direction.BULLISH else Direction.BULLISH
        )

        retested, retest_time = _find_retest(closed_candles, ob, invalidation_idx)

        breakers.append(
            BreakerBlock(
                original_ob=ob,
                invalidation_time=closed_candles[invalidation_idx].open_time,
                invalidation_candle_index=invalidation_idx,
                new_direction=new_direction,
                retested=retested,
                retest_time=retest_time,
            )
        )

    return breakers


def _find_invalidation_index(closed_candles: list[Candle], ob: OrderBlock) -> int | None:
    for i in range(ob.origin_candle_index + 1, len(closed_candles)):
        c = closed_candles[i]
        if ob.direction == Direction.BULLISH and c.close < ob.zone_lower:
            return i
        if ob.direction == Direction.BEARISH and c.close > ob.zone_upper:
            return i
    return None


def _find_retest(
    closed_candles: list[Candle], ob: OrderBlock, invalidation_idx: int
) -> tuple[bool, object | None]:
    for c in closed_candles[invalidation_idx + 1 :]:
        if ob.zone_lower <= c.high and ob.zone_upper >= c.low:
            return True, c.open_time
    return False, None
