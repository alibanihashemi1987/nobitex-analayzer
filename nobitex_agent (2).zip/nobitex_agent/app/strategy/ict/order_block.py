"""Order Block (OB) detection.

Definitions (deterministic, see STRATEGY.md):

- Bullish OB: the last BEARISH candle immediately preceding a BOS/CHoCH to
  the upside, PROVIDED the impulse leg that produced the break is "strong".
- Bearish OB: the last BULLISH candle immediately preceding a BOS/CHoCH to
  the downside, provided the impulse leg is "strong".

"Strong" is defined measurably: the impulse leg (from the OB candle's
close to the breaking candle's close) must have a range >=
`atr_multiplier` * ATR(14) evaluated at the breaking candle. This replaces
vague "strong move" language with an explicit, testable threshold.
"""

from __future__ import annotations

from app.domain.enums import Direction, MitigationState, StructureEvent
from app.domain.models import Candle, OrderBlock, StructureBreak
from app.indicators.atr import compute_atr_series


def detect_order_blocks(
    closed_candles: list[Candle],
    structure_breaks: list[StructureBreak],
    atr_multiplier: float = 1.5,
    atr_period: int = 14,
) -> list[OrderBlock]:
    atr_series = compute_atr_series(closed_candles, atr_period)
    order_blocks: list[OrderBlock] = []

    for sb in structure_breaks:
        break_idx = sb.breaking_candle_index
        atr_at_break = atr_series[break_idx]
        if atr_at_break is None:
            continue

        origin_idx = _find_origin_candle(closed_candles, break_idx, sb.direction)
        if origin_idx is None:
            continue

        origin_candle = closed_candles[origin_idx]
        breaking_candle = closed_candles[break_idx]
        impulse_range = abs(breaking_candle.close - origin_candle.close)
        strength_raw = impulse_range / atr_at_break if atr_at_break > 0 else 0.0

        if strength_raw < atr_multiplier:
            continue  # not "strong" enough to qualify as an OB-producing move

        strength_score = min(1.0, strength_raw / (atr_multiplier * 2))

        order_blocks.append(
            OrderBlock(
                direction=sb.direction,
                zone_upper=origin_candle.high,
                zone_lower=origin_candle.low,
                origin_candle_index=origin_idx,
                origin_time=origin_candle.open_time,
                structure_event=sb.event,
                strength_score=round(strength_score, 3),
                active=True,
                mitigation_state=_current_mitigation(
                    closed_candles, origin_idx, origin_candle, sb.direction
                ),
            )
        )

    return order_blocks


def _find_origin_candle(
    closed_candles: list[Candle], break_idx: int, direction: Direction
) -> int | None:
    """Walk backward from the breaking candle to find the last opposite-colored candle."""
    for j in range(break_idx - 1, -1, -1):
        c = closed_candles[j]
        is_bearish_candle = c.close < c.open
        is_bullish_candle = c.close > c.open
        if direction == Direction.BULLISH and is_bearish_candle:
            return j
        if direction == Direction.BEARISH and is_bullish_candle:
            return j
    return None


def _current_mitigation(
    closed_candles: list[Candle], origin_idx: int, origin_candle: Candle, direction: Direction
) -> MitigationState:
    zone_upper, zone_lower = origin_candle.high, origin_candle.low
    touched = False
    fully_closed_through = False
    for c in closed_candles[origin_idx + 1 :]:
        if direction == Direction.BULLISH:
            if c.low <= zone_upper:
                touched = True
            if c.close < zone_lower:
                fully_closed_through = True
        else:
            if c.high >= zone_lower:
                touched = True
            if c.close > zone_upper:
                fully_closed_through = True

    if fully_closed_through:
        return MitigationState.INVALIDATED
    if touched:
        return MitigationState.PARTIALLY_MITIGATED
    return MitigationState.ACTIVE
