"""Volume Imbalance (VI) detection.

Distinct from an FVG: a VI is a gap between the BODY of one candle and the
body of the next (close[i-1] vs open[i]), rather than the wick-based
3-candle FVG rule. It marks an area with little-to-no traded volume
between two consecutive candle bodies.

Bullish VI: open[i] > close[i-1]  (gap up between bodies)
Bearish VI: open[i] < close[i-1]  (gap down between bodies)
"""

from __future__ import annotations

from app.domain.enums import Direction
from app.domain.models import Candle, VolumeImbalance


def detect_volume_imbalances(closed_candles: list[Candle]) -> list[VolumeImbalance]:
    results: list[VolumeImbalance] = []
    for i in range(1, len(closed_candles)):
        prev, cur = closed_candles[i - 1], closed_candles[i]
        if cur.open > prev.close:
            results.append(
                VolumeImbalance(
                    direction=Direction.BULLISH,
                    upper=cur.open,
                    lower=prev.close,
                    candle_index=i,
                    time=cur.open_time,
                )
            )
        elif cur.open < prev.close:
            results.append(
                VolumeImbalance(
                    direction=Direction.BEARISH,
                    upper=prev.close,
                    lower=cur.open,
                    candle_index=i,
                    time=cur.open_time,
                )
            )
    return results
