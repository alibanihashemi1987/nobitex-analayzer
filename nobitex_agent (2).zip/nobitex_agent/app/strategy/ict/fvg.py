"""Fair Value Gap (FVG) detection.

Bullish FVG at candle i (i >= 2):  Low[i] > High[i-2]   -> gap = (High[i-2], Low[i])
Bearish FVG at candle i (i >= 2):  High[i] < Low[i-2]   -> gap = (High[i], Low[i-2])

Only formed using three consecutive CLOSED candles (i-2, i-1, i), so a gap
is never reported until candle i has actually closed.

Invalidation (configurable): once price closes beyond `invalidation_pct`
(default 50%) into the gap from the far side, mitigation_state becomes
MITIGATED and active=False. Between 0% and invalidation_pct it is
PARTIALLY_MITIGATED.
"""

from __future__ import annotations

from dataclasses import replace

from app.domain.enums import Direction, MitigationState
from app.domain.models import FVG, Candle


def detect_fvgs(closed_candles: list[Candle], invalidation_pct: float = 0.5) -> list[FVG]:
    fvgs: list[FVG] = []
    n = len(closed_candles)

    for i in range(2, n):
        c0, c2 = closed_candles[i - 2], closed_candles[i]

        if c2.low > c0.high:
            upper, lower = c2.low, c0.high
            fvgs.append(
                FVG(
                    direction=Direction.BULLISH,
                    upper=upper,
                    lower=lower,
                    size=upper - lower,
                    created_time=c2.open_time,
                    created_candle_index=i,
                    mitigation_state=MitigationState.ACTIVE,
                )
            )
        elif c2.high < c0.low:
            upper, lower = c0.low, c2.high
            fvgs.append(
                FVG(
                    direction=Direction.BEARISH,
                    upper=upper,
                    lower=lower,
                    size=upper - lower,
                    created_time=c2.open_time,
                    created_candle_index=i,
                    mitigation_state=MitigationState.ACTIVE,
                )
            )

    return [_apply_mitigation(fvg, closed_candles, invalidation_pct) for fvg in fvgs]


def _apply_mitigation(fvg: FVG, closed_candles: list[Candle], invalidation_pct: float) -> FVG:
    """Replay candles AFTER the FVG's creation to determine current mitigation state.

    Only candles with index > created_candle_index are considered, preserving
    chronological ordering (no lookahead into the gap's own formation).
    """
    gap_size = fvg.upper - fvg.lower
    if gap_size <= 0:
        return fvg

    max_penetration_pct = 0.0
    for c in closed_candles[fvg.created_candle_index + 1 :]:
        if fvg.direction == Direction.BULLISH:
            # Price re-entering from above; penetration measured from top (upper) downward.
            penetration = max(0.0, fvg.upper - max(c.low, fvg.lower))
        else:
            penetration = max(0.0, min(c.high, fvg.upper) - fvg.lower)
        pct = penetration / gap_size
        max_penetration_pct = max(max_penetration_pct, pct)

    if max_penetration_pct >= 1.0:
        state = MitigationState.MITIGATED
        active = False
    elif max_penetration_pct >= invalidation_pct:
        state = MitigationState.MITIGATED
        active = False
    elif max_penetration_pct > 0:
        state = MitigationState.PARTIALLY_MITIGATED
        active = True
    else:
        state = MitigationState.ACTIVE
        active = True

    return replace(
        fvg,
        mitigation_state=state,
        mitigation_pct=round(max_penetration_pct * 100, 2),
        active=active,
    )
