"""Mitigation Block detection.

Distinguished from an Order Block by an explicit, deterministic rule:
both are the last opposite-colored candle before a structural break, but
a Mitigation Block is produced by an impulse leg WEAKER than the
`atr_multiplier` threshold used for Order Blocks (i.e. it failed the OB
"strong move" test). This gives every zone exactly one classification —
never both — removing ambiguity between the two concepts.
"""

from __future__ import annotations

from app.domain.enums import Direction, MitigationState
from app.domain.models import Candle, MitigationBlock, StructureBreak
from app.indicators.atr import compute_atr_series
from app.strategy.ict.order_block import _find_origin_candle


def detect_mitigation_blocks(
    closed_candles: list[Candle],
    structure_breaks: list[StructureBreak],
    atr_multiplier: float = 1.5,
    atr_period: int = 14,
) -> list[MitigationBlock]:
    atr_series = compute_atr_series(closed_candles, atr_period)
    blocks: list[MitigationBlock] = []

    for sb in structure_breaks:
        break_idx = sb.breaking_candle_index
        atr_at_break = atr_series[break_idx]
        if atr_at_break is None or atr_at_break == 0:
            continue

        origin_idx = _find_origin_candle(closed_candles, break_idx, sb.direction)
        if origin_idx is None:
            continue

        origin_candle = closed_candles[origin_idx]
        breaking_candle = closed_candles[break_idx]
        impulse_range = abs(breaking_candle.close - origin_candle.close)
        strength_raw = impulse_range / atr_at_break

        if strength_raw >= atr_multiplier:
            continue  # this qualifies as an Order Block instead

        state = _mitigation_state(closed_candles, origin_idx, origin_candle, sb.direction)

        blocks.append(
            MitigationBlock(
                direction=sb.direction,
                zone_upper=origin_candle.high,
                zone_lower=origin_candle.low,
                origin_candle_index=origin_idx,
                origin_time=origin_candle.open_time,
                mitigation_state=state,
            )
        )

    return blocks


def _mitigation_state(
    closed_candles: list[Candle], origin_idx: int, origin_candle: Candle, direction: Direction
) -> MitigationState:
    zone_upper, zone_lower = origin_candle.high, origin_candle.low
    touched = False
    for c in closed_candles[origin_idx + 1 :]:
        if direction == Direction.BULLISH and c.low <= zone_upper:
            touched = True
        elif direction == Direction.BEARISH and c.high >= zone_lower:
            touched = True
    return MitigationState.MITIGATED if touched else MitigationState.ACTIVE
