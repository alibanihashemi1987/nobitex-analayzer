"""BOS / CHoCH detection built purely on confirmed swing points.

Deterministic rules:

- Trend state is tracked as BULLISH, BEARISH or UNKNOWN based on the
  sequence of confirmed swing highs/lows (higher-highs/higher-lows vs
  lower-highs/lower-lows).
- BOS (Break of Structure): a close beyond the most recent swing point
  IN THE DIRECTION of the current trend -> trend continuation.
- CHoCH (Change of Character): a close beyond the most recent swing point
  AGAINST the current trend -> first sign of potential reversal.
- Only CLOSED candles and already-CONFIRMED swings are used, so no future
  information leaks into a historical structure event.
"""

from __future__ import annotations

from app.domain.enums import Direction, StructureEvent
from app.domain.models import Candle, StructureBreak, SwingPoint
from app.indicators.swings import detect_swings, swing_highs, swing_lows


def detect_structure_breaks(
    closed_candles: list[Candle], swing_lookback: int = 2
) -> list[StructureBreak]:
    swings = detect_swings(closed_candles, lookback=swing_lookback)
    highs = swing_highs(swings)
    lows = swing_lows(swings)

    breaks: list[StructureBreak] = []
    trend: Direction | None = None

    last_broken_high: SwingPoint | None = None
    last_broken_low: SwingPoint | None = None

    # Walk candle-by-candle so that a swing is only usable for detecting a
    # break AFTER it has been confirmed (its index < current candle index).
    for i, candle in enumerate(closed_candles):
        available_highs = [s for s in highs if s.index < i]
        available_lows = [s for s in lows if s.index < i]
        if not available_highs or not available_lows:
            continue

        nearest_high = available_highs[-1]
        nearest_low = available_lows[-1]

        broke_up = candle.close > nearest_high.price and nearest_high is not last_broken_high
        broke_down = candle.close < nearest_low.price and nearest_low is not last_broken_low

        if broke_up:
            event = StructureEvent.BOS if trend == Direction.BULLISH else StructureEvent.CHOCH
            breaks.append(
                StructureBreak(
                    event=event,
                    direction=Direction.BULLISH,
                    time=candle.open_time,
                    broken_swing=nearest_high,
                    breaking_candle_index=i,
                )
            )
            trend = Direction.BULLISH
            last_broken_high = nearest_high

        elif broke_down:
            event = StructureEvent.BOS if trend == Direction.BEARISH else StructureEvent.CHOCH
            breaks.append(
                StructureBreak(
                    event=event,
                    direction=Direction.BEARISH,
                    time=candle.open_time,
                    broken_swing=nearest_low,
                    breaking_candle_index=i,
                )
            )
            trend = Direction.BEARISH
            last_broken_low = nearest_low

    return breaks


def current_trend(structure_breaks: list[StructureBreak]) -> Direction | None:
    if not structure_breaks:
        return None
    return structure_breaks[-1].direction
