"""Category H — Premium/Discount Location (max 5 points), using the
Equilibrium Buffer defined in sections 8-9 (not a rigid 50% boundary).
"""

from __future__ import annotations

from app.domain.enums import Direction, ZoneType
from app.domain.events import ScoreFactor
from app.domain.models import PremiumDiscountZone

_MAX_H = 5.0


def score_premium_discount(
    direction: Direction, pd_zone: PremiumDiscountZone | None
) -> tuple[float, list[ScoreFactor], bool]:
    """Returns (points, factors, gate_failed).

    gate_failed=True means the price is in the WRONG zone for this
    direction (Premium for LONG, Discount for SHORT) — Gate 4 must fail
    in that case regardless of the score returned here.
    """
    if pd_zone is None:
        factor = ScoreFactor("H1", "premium_discount", "Premium/Discount Location", 0.0, _MAX_H,
                              "Premium/Discount range unavailable (insufficient candles).")
        return 0.0, [factor], False

    wrong_zone = (
        (direction == Direction.BULLISH and pd_zone.current_zone == ZoneType.PREMIUM)
        or (direction == Direction.BEARISH and pd_zone.current_zone == ZoneType.DISCOUNT)
    )
    preferred_zone = (
        (direction == Direction.BULLISH and pd_zone.current_zone == ZoneType.DISCOUNT)
        or (direction == Direction.BEARISH and pd_zone.current_zone == ZoneType.PREMIUM)
    )

    if wrong_zone:
        points = 0.0
        evidence = f"Price is in {pd_zone.current_zone.value} — invalid zone for {direction.value}."
        gate_failed = True
    elif preferred_zone:
        points = 5.0
        evidence = f"Price is in the preferred {pd_zone.current_zone.value} zone."
        gate_failed = False
    else:  # EQUILIBRIUM
        points = 2.0
        evidence = "Price is within the Equilibrium Buffer — permitted but lower quality."
        gate_failed = False

    factor = ScoreFactor("H1", "premium_discount", "Premium/Discount Location", points, _MAX_H, evidence)
    return points, [factor], gate_failed
