"""Hard Gates (sections 4-8). These are pass/fail validity checks,
completely separate from the point-scoring categories. A failed gate
invalidates the setup regardless of how high the confluence score is —
see REPLACEMENT_MODULE section 4: "A failed Hard Gate invalidates the
trade regardless of score."
"""

from __future__ import annotations

from dataclasses import dataclass

from app.domain.context import MarketContext
from app.domain.enums import DataValidity, Direction
from app.domain.events import POIEvent
from app.domain.models import RiskLevels


@dataclass(frozen=True, slots=True)
class GateResult:
    gate_id: str
    name: str
    passed: bool
    reason: str


def gate_1_data_validity(context: MarketContext) -> GateResult:
    passed = context.data_validity == DataValidity.VALID
    reason = context.data_validity_reason or "Data is valid."
    return GateResult("GATE_1", "Data Validity", passed, reason)


def gate_2_htf_structure_confirmed(context: MarketContext) -> GateResult:
    htf = context.timeframes.get("HTF")
    if htf is None:
        return GateResult("GATE_2", "HTF Structure Confirmed", False, "No HTF timeframe data available.")
    if len(htf.structure.swings) < 2:
        return GateResult("GATE_2", "HTF Structure Confirmed", False,
                           "HTF structure is unclear: fewer than 2 confirmed swing points.")
    return GateResult("GATE_2", "HTF Structure Confirmed", True,
                       f"HTF structure established from {len(htf.structure.swings)} confirmed swings "
                       f"and {len(htf.structure.breaks)} structural break(s).")


def gate_3_valid_htf_poi(primary_poi: POIEvent | None) -> GateResult:
    if primary_poi is None:
        return GateResult("GATE_3", "Valid HTF POI", False, "No valid, active HTF POI found for this direction.")
    return GateResult("GATE_3", "Valid HTF POI", True, f"Primary POI: {primary_poi.poi_type}.")


def gate_4_premium_discount_direction(pd_gate_failed: bool, direction: Direction) -> GateResult:
    if pd_gate_failed:
        wrong = "Premium" if direction == Direction.BULLISH else "Discount"
        return GateResult("GATE_4", "Premium/Discount Direction", False,
                           f"Price is in {wrong}, which is invalid for {direction.value}.")
    return GateResult("GATE_4", "Premium/Discount Direction", True, "Price is in a valid zone for this direction.")


def gate_5_valid_risk_setup(risk: RiskLevels | None, minimum_risk_reward: float) -> GateResult:
    if risk is None:
        return GateResult("GATE_5", "Valid SL/TP & R:R", False, "No valid Entry/SL/TP could be computed.")
    if risk.risk_reward_tp1 < minimum_risk_reward:
        return GateResult("GATE_5", "Valid SL/TP & R:R", False,
                           f"R:R to TP1 ({risk.risk_reward_tp1}) is below the minimum ({minimum_risk_reward}).")
    return GateResult("GATE_5", "Valid SL/TP & R:R", True, f"R:R to TP1 = {risk.risk_reward_tp1}.")


def run_hard_gates(
    context: MarketContext,
    direction: Direction,
    primary_poi: POIEvent | None,
    pd_gate_failed: bool,
    risk: RiskLevels | None,
    minimum_risk_reward: float,
) -> tuple[bool, list[GateResult]]:
    results = [
        gate_1_data_validity(context),
        gate_2_htf_structure_confirmed(context),
        gate_3_valid_htf_poi(primary_poi),
        gate_4_premium_discount_direction(pd_gate_failed, direction),
        gate_5_valid_risk_setup(risk, minimum_risk_reward),
    ]
    all_passed = all(r.passed for r in results)
    return all_passed, results
