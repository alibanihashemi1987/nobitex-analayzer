"""HTF alignment strength (ADDITIONAL_ARCHITECTURE_REQUIREMENTS section
13). Used both for informational reporting and as an input to the
resolver's conditional tie-breaker (section 11-16)."""

from __future__ import annotations

from app.domain.context import StructureState
from app.domain.enums import Direction, HTFAlignmentStrength
from app.strategy.scoring.category_structure import _htf_direction_chain_length


def classify_htf_alignment(direction: Direction, htf_structure: StructureState) -> HTFAlignmentStrength:
    if htf_structure.trend is None:
        return HTFAlignmentStrength.NEUTRAL
    if htf_structure.trend != direction:
        return HTFAlignmentStrength.OPPOSITE

    chain = _htf_direction_chain_length(htf_structure.breaks, direction)
    if chain is None:
        return HTFAlignmentStrength.NEUTRAL
    if chain >= 3:
        return HTFAlignmentStrength.STRONG
    if chain >= 1:
        return HTFAlignmentStrength.MODERATE
    return HTFAlignmentStrength.WEAK


def htf_direction(htf_structure: StructureState) -> Direction | None:
    """The overall HTF_DIRECTION used by the resolver's tie-breaker
    (BULLISH / BEARISH / None-for-NEUTRAL)."""
    return htf_structure.trend
