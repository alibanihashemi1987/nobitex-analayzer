"""Category B — POI Quality (max 25 points). Section 14.

Selects the Primary POI (priority: Liquidity Sweep+Shift > OB/Breaker >
FVG > OTE > Mitigation Block > Volume Imbalance > Dynamic MA) and scores
its strength, freshness, structural association, and reaction quality.
"""

from __future__ import annotations

from app.domain.context import LiquidityContext, POIContext, StructureState
from app.domain.enums import Direction, MitigationState, POIType
from app.domain.events import POIEvent, ScoreFactor
from app.strategy.scoring.primary_poi import primary_poi_strength_points, select_primary_poi

_MAX_B1 = 12.0
_MAX_B2 = 5.0
_MAX_B3 = 5.0
_MAX_B4 = 3.0

_FRESHNESS_POINTS = {
    MitigationState.ACTIVE.value: (5.0, "Untouched"),
    MitigationState.PARTIALLY_MITIGATED.value: (3.0, "Lightly mitigated"),
    MitigationState.MITIGATED.value: (1.0, "Heavily mitigated but structurally still referenced"),
    MitigationState.INVALIDATED.value: (0.0, "Invalidated"),
}


def select_primary_poi_with_liquidity(
    direction: Direction, pois: POIContext, liquidity: LiquidityContext, structure: StructureState
) -> POIEvent | None:
    """Extends select_primary_poi with priority-1 (Liquidity Sweep +
    Structural Shift): a confirmed sweep whose direction matches AND
    which is followed by a same-direction structure break (the "shift")."""
    for sweep in reversed(liquidity.sweeps):
        if sweep.direction != direction or not sweep.reversal_confirmed:
            continue
        has_following_shift = any(
            b.direction == direction and b.breaking_candle_index >= sweep.sweep_candle_index
            for b in structure.breaks
        )
        if not has_following_shift:
            continue
        return POIEvent(
            event_id=f"sweep_shift:{sweep.sweep_candle_index}",
            poi_type=POIType.LIQUIDITY_SWEEP_STRUCTURAL_SHIFT.value,
            symbol="", timeframe="", direction=direction.value,
            zone_high=sweep.swept_level, zone_low=sweep.swept_level,
            created_at=sweep.sweep_time, mitigation_status=MitigationState.ACTIVE.value,
        )
    return select_primary_poi(direction, pois)


def score_poi(
    direction: Direction,
    primary_poi: POIEvent | None,
    structure: StructureState,
) -> tuple[float, list[ScoreFactor], POIEvent | None]:
    factors: list[ScoreFactor] = []

    # B1: Primary POI strength
    b1 = primary_poi_strength_points(primary_poi)
    evidence1 = f"Primary POI type: {primary_poi.poi_type}" if primary_poi else "No valid POI found."
    factors.append(ScoreFactor("B1", "poi", "Primary POI Strength", b1, _MAX_B1, evidence1,
                                (primary_poi.event_id,) if primary_poi else ()))

    # B2: Freshness
    if primary_poi is None:
        b2 = 0.0
        evidence2 = "No POI to evaluate freshness for."
    else:
        b2, label = _FRESHNESS_POINTS.get(primary_poi.mitigation_status, (0.0, "Unknown"))
        evidence2 = f"POI freshness: {label} ({primary_poi.mitigation_status})."
    factors.append(ScoreFactor("B2", "poi", "POI Freshness", b2, _MAX_B2, evidence2))

    # B3: Structural association
    if primary_poi is None:
        b3 = 0.0
        evidence3 = "No POI to evaluate structural association for."
    elif primary_poi.poi_type in (POIType.ORDER_BLOCK.value, POIType.BREAKER_BLOCK.value,
                                    POIType.LIQUIDITY_SWEEP_STRUCTURAL_SHIFT.value):
        b3 = 5.0
        evidence3 = "POI is directly produced by a BOS/CHoCH structural event."
    elif structure.breaks:
        b3 = 3.0
        evidence3 = "POI coincides with recently confirmed structure."
    else:
        b3 = 1.0
        evidence3 = "POI has weak/no structural association."
    factors.append(ScoreFactor("B3", "poi", "Structural Association", b3, _MAX_B3, evidence3))

    # B4: Reaction quality (approximated via zone width as a proxy for
    # displacement strength when no explicit strength_score is available;
    # Order Blocks carry an ATR-based strength_score which is the primary
    # signal when present).
    if primary_poi is None:
        b4 = 0.0
        evidence4 = "No POI to evaluate reaction quality for."
    else:
        zone_size = abs(primary_poi.zone_high - primary_poi.zone_low)
        mid = (primary_poi.zone_high + primary_poi.zone_low) / 2 or 1.0
        relative_size = zone_size / abs(mid) if mid else 0.0
        if relative_size > 0.01:
            b4, evidence4 = 3.0, "Strong displacement (large zone relative to price)."
        elif relative_size > 0.003:
            b4, evidence4 = 2.0, "Moderate displacement."
        elif relative_size > 0:
            b4, evidence4 = 1.0, "Weak displacement."
        else:
            b4, evidence4 = 0.0, "No measurable displacement."
    factors.append(ScoreFactor("B4", "poi", "POI Reaction Quality", b4, _MAX_B4, evidence4))

    total = b1 + b2 + b3 + b4
    return total, factors, primary_poi
