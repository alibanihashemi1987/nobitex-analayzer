"""Category G — Execution Quality (max 5 points), sections 20-21."""

from __future__ import annotations

from app.domain.events import ScoreFactor
from app.domain.models import RiskLevels

_MAX_G = 5.0


def score_execution(
    risk: RiskLevels | None,
    minimum_risk_reward: float,
    spread_pct: float | None,
    early_ltf_entry: bool,
    early_ltf_penalty: int,
) -> tuple[float, list[ScoreFactor], bool]:
    """Returns (points, factors, penalty_applied)."""
    if risk is None:
        factor = ScoreFactor("G1", "execution", "Execution Quality", 0.0, _MAX_G, "No valid risk setup to evaluate.")
        return 0.0, [factor], False

    quality = 5.0
    notes: list[str] = []

    if risk.risk_reward_tp1 < minimum_risk_reward:
        quality -= 2.0
        notes.append(f"R:R to TP1 ({risk.risk_reward_tp1}) below minimum ({minimum_risk_reward}).")

    if spread_pct is not None and spread_pct > 0.5:
        quality -= 1.0
        notes.append(f"Elevated spread ({spread_pct:.2f}%).")

    penalty_applied = False
    if early_ltf_entry:
        quality -= early_ltf_penalty
        penalty_applied = True
        notes.append(f"Early LTF entry penalty (-{early_ltf_penalty}).")

    quality = max(0.0, min(_MAX_G, quality))
    evidence = "; ".join(notes) if notes else "No execution-quality penalties applied."
    factor = ScoreFactor("G1", "execution", "Execution Quality", quality, _MAX_G, evidence)
    return quality, [factor], penalty_applied
