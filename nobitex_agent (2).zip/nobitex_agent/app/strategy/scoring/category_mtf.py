"""Category E — Multi-Timeframe Alignment (max 10 points). Section 17."""

from __future__ import annotations

from app.domain.context import LiquidityContext, POIContext, StructureState
from app.domain.enums import Direction
from app.domain.events import ScoreFactor

_MAX_E1 = 6.0
_MAX_E2 = 4.0


def score_mtf(
    direction: Direction,
    htf_structure: StructureState,
    mtf_structure: StructureState | None,
    ltf_structure: StructureState | None,
    ltf_liquidity: LiquidityContext | None,
    ltf_pois: POIContext | None,
) -> tuple[float, list[ScoreFactor]]:
    factors: list[ScoreFactor] = []

    # E1: HTF + MTF alignment
    htf_aligned = htf_structure.trend == direction
    mtf_trend = mtf_structure.trend if mtf_structure else None
    if not htf_aligned:
        e1 = 0.0
        evidence1 = "HTF is not aligned with the candidate direction."
    elif mtf_trend == direction:
        e1 = 6.0
        evidence1 = "HTF and MTF both aligned with the candidate direction."
    elif mtf_trend is None:
        e1 = 4.0
        evidence1 = "HTF aligned; MTF trend is neutral/undetermined."
    else:
        e1 = 1.0
        evidence1 = "HTF aligned; MTF is counter-trend."
    factors.append(ScoreFactor("E1", "mtf", "HTF + MTF Alignment", e1, _MAX_E1, evidence1))

    # E2: LTF confirmation
    if ltf_structure is not None and ltf_structure.breaks and ltf_structure.breaks[-1].direction == direction:
        e2 = 4.0
        evidence2 = "Strong LTF confirmation: recent same-direction structure break."
    elif ltf_liquidity is not None and any(s.direction == direction for s in ltf_liquidity.sweeps):
        e2 = 3.0
        evidence2 = "Moderate LTF confirmation: matching liquidity sweep."
    elif ltf_pois is not None and any(f.direction == direction and f.active for f in ltf_pois.fvgs):
        e2 = 1.0
        evidence2 = "Weak LTF confirmation: matching active FVG only."
    else:
        e2 = 0.0
        evidence2 = "No LTF confirmation."
    factors.append(ScoreFactor("E2", "mtf", "LTF Confirmation", e2, _MAX_E2, evidence2))

    return e1 + e2, factors
