"""Category A — Market Structure (max 20 points). Section 13."""

from __future__ import annotations

from app.domain.context import StructureState
from app.domain.enums import CrossType, Direction
from app.domain.events import ScoreFactor
from app.domain.models import MovingAverageResult, StructureBreak

_MAX_A1 = 10.0
_MAX_A2 = 5.0
_MAX_A3 = 3.0
_MAX_A4 = 2.0


def _htf_direction_chain_length(breaks: tuple[StructureBreak, ...], direction: Direction) -> int | None:
    """Length of the current same-direction BOS run at the end of the
    break sequence, or None if the trend doesn't match `direction` at all.
    A CHoCH that just flipped trend into `direction` counts as chain 0
    (weak — the reversal just happened, not yet confirmed by a BOS)."""
    if not breaks or breaks[-1].direction != direction:
        return None
    chain = 0
    for b in reversed(breaks):
        if b.direction != direction:
            break
        if b.event.value == "CHOCH":
            break
        chain += 1
    return chain


def score_structure(direction: Direction, structure: StructureState, ma: MovingAverageResult, ma20_slope_pct: float | None) -> tuple[float, list[ScoreFactor]]:
    factors: list[ScoreFactor] = []

    # A1: HTF structural direction (10 pts)
    chain = _htf_direction_chain_length(structure.breaks, direction)
    if chain is None:
        a1 = 0.0
        evidence = "HTF trend does not align with candidate direction, or is unknown."
    elif chain >= 3:
        a1 = 10.0
        evidence = f"Strong aligned structure: {chain} consecutive same-direction BOS events."
    elif chain >= 1:
        a1 = 7.0
        evidence = f"Moderate aligned structure: {chain} consecutive same-direction BOS event(s)."
    else:
        a1 = 4.0
        evidence = "Weak aligned structure: trend just changed via CHoCH, no confirming BOS yet."
    event_ids = tuple(f"break:{b.breaking_candle_index}" for b in structure.breaks[-3:]) if structure.breaks else ()
    factors.append(ScoreFactor("A1", "structure", "HTF Structural Direction", a1, _MAX_A1, evidence, event_ids))

    # A2: MA200 macro bias (5 pts)
    if ma.price_vs_ma200 is None:
        a2 = 0.0
        evidence2 = "MA200 unavailable (insufficient candles)."
    elif ma.price_vs_ma200 == direction:
        a2 = 5.0
        evidence2 = f"Price is on the {direction.value.lower()} side of MA200."
    else:
        a2 = 0.0
        evidence2 = f"Price is NOT on the {direction.value.lower()} side of MA200."
    factors.append(ScoreFactor("A2", "structure", "MA200 Macro Bias", a2, _MAX_A2, evidence2))

    # A3: MA20 slope (3 pts)
    if ma20_slope_pct is None:
        a3 = 0.0
        evidence3 = "MA20 slope unavailable."
    else:
        wants_positive = direction == Direction.BULLISH
        slope_is_positive = ma20_slope_pct > 0.0005
        slope_is_negative = ma20_slope_pct < -0.0005
        if wants_positive:
            a3 = 3.0 if slope_is_positive else (1.0 if not slope_is_negative else 0.0)
        else:
            a3 = 3.0 if slope_is_negative else (1.0 if not slope_is_positive else 0.0)
        evidence3 = f"MA20 slope = {ma20_slope_pct:.4%}."
    factors.append(ScoreFactor("A3", "structure", "MA20 Direction", a3, _MAX_A3, evidence3))

    # A4: MA20/MA200 relationship (2 pts)
    if ma.ma20 is None or ma.ma200 is None:
        a4 = 0.0
        evidence4 = "MA20/MA200 unavailable."
    else:
        bullish_stack = ma.ma20 > ma.ma200
        if direction == Direction.BULLISH:
            if bullish_stack:
                a4 = 2.0
                evidence4 = "MA20 > MA200."
            elif ma.cross_type == CrossType.GOLDEN_FRESH:
                a4 = 1.0
                evidence4 = "MA20 just crossed above MA200 (fresh golden cross)."
            else:
                a4 = 0.0
                evidence4 = "MA20 <= MA200."
        else:
            if not bullish_stack:
                a4 = 2.0
                evidence4 = "MA20 < MA200."
            elif ma.cross_type == CrossType.DEATH_FRESH:
                a4 = 1.0
                evidence4 = "MA20 just crossed below MA200 (fresh death cross)."
            else:
                a4 = 0.0
                evidence4 = "MA20 >= MA200."
    factors.append(ScoreFactor("A4", "structure", "MA20/MA200 Relationship", a4, _MAX_A4, evidence4))

    total = a1 + a2 + a3 + a4
    return total, factors
