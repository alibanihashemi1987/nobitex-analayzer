"""Category D — Momentum (max 10 points). Section 16."""

from __future__ import annotations

from app.domain.enums import Direction, DivergenceType
from app.domain.events import ScoreFactor
from app.domain.models import MFIResult, RSIResult

_MAX_D1 = 5.0
_MAX_D2 = 5.0

_OVERSOLD_RSI = 30.0
_OVERBOUGHT_RSI = 70.0


def _momentum_subscore(
    direction: Direction,
    value: float | None,
    divergences: list[DivergenceType],
    oversold: bool,
    overbought: bool,
) -> tuple[float, str]:
    regular_wanted = (
        DivergenceType.REGULAR_BULLISH if direction == Direction.BULLISH else DivergenceType.REGULAR_BEARISH
    )
    hidden_wanted = (
        DivergenceType.HIDDEN_BULLISH if direction == Direction.BULLISH else DivergenceType.HIDDEN_BEARISH
    )
    extreme = oversold if direction == Direction.BULLISH else overbought

    if regular_wanted in divergences:
        return 5.0, f"Regular {direction.value.lower()} divergence confirmed."
    if hidden_wanted in divergences:
        return 4.0, f"Hidden {direction.value.lower()} divergence present."
    if extreme:
        return 3.0, "Oscillator at an extreme with a supportive reaction."
    if value is None:
        return 0.0, "Oscillator value unavailable."

    supportive = value > 50 if direction == Direction.BULLISH else value < 50
    if supportive:
        return 2.0, "Oscillator on the supportive side of the midline."
    neutral_band = 45 <= value <= 55
    if neutral_band:
        return 1.0, "Oscillator near neutral."
    return 0.0, "Oscillator opposes the candidate direction."


def score_momentum(
    direction: Direction, mfi: MFIResult, rsi: RSIResult
) -> tuple[float, list[ScoreFactor]]:
    factors: list[ScoreFactor] = []

    d1, evidence1 = _momentum_subscore(direction, mfi.value, mfi.divergences, mfi.oversold, mfi.overbought)
    factors.append(ScoreFactor("D1", "momentum", "MFI10", d1, _MAX_D1, evidence1))

    rsi_oversold = rsi.value is not None and rsi.value < _OVERSOLD_RSI
    rsi_overbought = rsi.value is not None and rsi.value > _OVERBOUGHT_RSI
    d2, evidence2 = _momentum_subscore(direction, rsi.value, rsi.divergences, rsi_oversold, rsi_overbought)
    factors.append(ScoreFactor("D2", "momentum", "RSI14", d2, _MAX_D2, evidence2))

    return d1 + d2, factors
