"""Primary POI selection (REPLACEMENT_MODULE section 14).

The engine must identify all valid POIs on the HTF snapshot but select
exactly ONE as the Primary POI, using this priority order:

    1. Liquidity Sweep + Structural Shift
    2. Order Block / Breaker Block
    3. FVG
    4. OTE
    5. Mitigation Block
    6. Volume Imbalance
    7. Dynamic MA   (not implemented in this build — see note below)

This same selection is used by Gate 3 (a valid HTF POI must exist) and
by Category B1 (Primary POI Strength) — computing it once and sharing it
is itself an anti-double-counting measure: we never let two different
code paths pick two different "primary" POIs for the same cycle.

NOTE on Dynamic MA: this build does not yet implement a "Dynamic MA as
POI" detector (e.g. price reacting off a moving average as a discrete
zone). It is included in the priority list/enum for forward
compatibility but never selected. See STRATEGY.md's known-limitations
section.
"""

from __future__ import annotations

from app.domain.context import POIContext
from app.domain.enums import Direction, MitigationState, POIType
from app.domain.events import POIEvent


def select_primary_poi(direction: Direction, pois: POIContext) -> POIEvent | None:
    # 1. Liquidity Sweep + Structural Shift is selected by the caller
    #    (evaluate_long/evaluate_short) since it needs the LiquidityContext
    #    too; this function handles priorities 2-6 which live entirely on
    #    POIContext. The caller merges both and applies final priority.
    candidates: list[tuple[int, POIEvent]] = []

    for ob in pois.order_blocks:
        if ob.direction == direction and ob.active and ob.mitigation_state != MitigationState.INVALIDATED:
            candidates.append((2, POIEvent(
                event_id=f"ob:{ob.origin_candle_index}",
                poi_type=POIType.ORDER_BLOCK.value,
                symbol="", timeframe="", direction=direction.value,
                zone_high=ob.zone_upper, zone_low=ob.zone_lower,
                created_at=ob.origin_time, mitigation_status=ob.mitigation_state.value,
            )))

    for br in pois.breaker_blocks:
        if br.new_direction == direction:
            candidates.append((2, POIEvent(
                event_id=f"breaker:{br.invalidation_candle_index}",
                poi_type=POIType.BREAKER_BLOCK.value,
                symbol="", timeframe="", direction=direction.value,
                zone_high=br.original_ob.zone_upper, zone_low=br.original_ob.zone_lower,
                created_at=br.invalidation_time,
                mitigation_status=MitigationState.ACTIVE.value if not br.retested else MitigationState.PARTIALLY_MITIGATED.value,
            )))

    for fvg in pois.fvgs:
        if fvg.direction == direction and fvg.active:
            candidates.append((3, POIEvent(
                event_id=f"fvg:{fvg.created_candle_index}",
                poi_type=POIType.FVG.value,
                symbol="", timeframe="", direction=direction.value,
                zone_high=fvg.upper, zone_low=fvg.lower,
                created_at=fvg.created_time, mitigation_status=fvg.mitigation_state.value,
            )))

    if pois.ote_zone is not None and pois.ote_zone.direction == direction and pois.ote_zone.in_zone:
        candidates.append((4, POIEvent(
            event_id="ote:latest",
            poi_type=POIType.OTE.value,
            symbol="", timeframe="", direction=direction.value,
            zone_high=max(pois.ote_zone.fib_618, pois.ote_zone.fib_79),
            zone_low=min(pois.ote_zone.fib_618, pois.ote_zone.fib_79),
            created_at=None,  # type: ignore[arg-type]
            mitigation_status=MitigationState.ACTIVE.value,
        )))

    for mb in pois.mitigation_blocks:
        if mb.direction == direction and mb.mitigation_state == MitigationState.ACTIVE:
            candidates.append((5, POIEvent(
                event_id=f"mitigation:{mb.origin_candle_index}",
                poi_type=POIType.MITIGATION_BLOCK.value,
                symbol="", timeframe="", direction=direction.value,
                zone_high=mb.zone_upper, zone_low=mb.zone_lower,
                created_at=mb.origin_time, mitigation_status=mb.mitigation_state.value,
            )))

    for vi in pois.volume_imbalances:
        if vi.direction == direction:
            candidates.append((6, POIEvent(
                event_id=f"vi:{vi.candle_index}",
                poi_type=POIType.VOLUME_IMBALANCE.value,
                symbol="", timeframe="", direction=direction.value,
                zone_high=vi.upper, zone_low=vi.lower,
                created_at=vi.time, mitigation_status=MitigationState.ACTIVE.value,
            )))

    if not candidates:
        return None

    candidates.sort(key=lambda pair: pair[0])
    return candidates[0][1]


_STRENGTH_POINTS = {
    POIType.LIQUIDITY_SWEEP_STRUCTURAL_SHIFT.value: 12,
    POIType.ORDER_BLOCK.value: 10,
    POIType.BREAKER_BLOCK.value: 10,
    POIType.FVG.value: 8,
    POIType.OTE.value: 7,
    POIType.MITIGATION_BLOCK.value: 6,
    POIType.VOLUME_IMBALANCE.value: 5,
    POIType.DYNAMIC_MA.value: 4,
}


def primary_poi_strength_points(poi: POIEvent | None) -> float:
    if poi is None:
        return 0.0
    return float(_STRENGTH_POINTS.get(poi.poi_type, 0))
