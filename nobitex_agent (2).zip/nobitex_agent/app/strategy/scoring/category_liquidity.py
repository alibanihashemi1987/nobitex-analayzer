"""Category C — Liquidity & Price Action (max 15 points). Section 15."""

from __future__ import annotations

from app.domain.context import LiquidityContext, StructureState
from app.domain.enums import Direction
from app.domain.events import ScoreFactor

_MAX_C1 = 7.0
_MAX_C2 = 4.0
_MAX_C3 = 4.0


def score_liquidity(
    direction: Direction,
    liquidity: LiquidityContext,
    structure: StructureState,
    current_price: float,
) -> tuple[float, list[ScoreFactor]]:
    factors: list[ScoreFactor] = []

    # C1: Liquidity sweep
    matching_sweeps = [s for s in liquidity.sweeps if s.direction == direction]
    latest_sweep = matching_sweeps[-1] if matching_sweeps else None
    if latest_sweep is not None and latest_sweep.reversal_confirmed:
        c1 = 7.0
        evidence1 = "Confirmed liquidity sweep with reversal (SSL/BSL sweep + rejection)."
        c1_events = (f"sweep:{latest_sweep.sweep_candle_index}",)
    elif latest_sweep is not None:
        c1 = 4.0
        evidence1 = "Liquidity sweep detected but reversal not yet confirmed."
        c1_events = (f"sweep:{latest_sweep.sweep_candle_index}",)
    else:
        c1 = 0.0
        evidence1 = "No valid liquidity sweep."
        c1_events = ()
    factors.append(ScoreFactor("C1", "liquidity", "Liquidity Sweep", c1, _MAX_C1, evidence1, c1_events))

    # C2: Structural reaction (BOS/CHoCH), independent of C1's sweep event
    matching_breaks = [b for b in structure.breaks if b.direction == direction]
    latest_break = matching_breaks[-1] if matching_breaks else None
    if latest_break is not None and latest_break.event.value in ("BOS", "CHOCH"):
        c2 = 4.0
        evidence2 = f"Confirmed directional {latest_break.event.value}."
        c2_events = (f"break:{latest_break.breaking_candle_index}",)
    else:
        c2 = 0.0
        evidence2 = "No confirmed directional structural break."
        c2_events = ()
    factors.append(ScoreFactor("C2", "liquidity", "Structural Reaction", c2, _MAX_C2, evidence2, c2_events))

    # C3: Liquidity target quality — external target = an opposite-direction
    # confirmed swing beyond the current price that has NOT yet been swept.
    swept_prices = {s.swept_level for s in liquidity.sweeps}
    opposite_swings = [
        sw for sw in structure.swings
        if (sw.direction != direction) and sw.price not in swept_prices
    ]
    if direction == Direction.BULLISH:
        external_targets = [sw for sw in opposite_swings if sw.price > current_price]
    else:
        external_targets = [sw for sw in opposite_swings if sw.price < current_price]

    if external_targets:
        c3 = 4.0
        evidence3 = f"Clear external liquidity target at {external_targets[-1].price}."
    elif opposite_swings:
        c3 = 3.0
        evidence3 = "Internal liquidity target available (unswept opposite swing nearby)."
    elif structure.swings:
        c3 = 1.0
        evidence3 = "Only weak/ambiguous liquidity target available."
    else:
        c3 = 0.0
        evidence3 = "No meaningful liquidity target."
    factors.append(ScoreFactor("C3", "liquidity", "Liquidity Target Quality", c3, _MAX_C3, evidence3))

    total = c1 + c2 + c3
    return total, factors
