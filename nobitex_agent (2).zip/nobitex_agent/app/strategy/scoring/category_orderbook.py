"""Category F — Order Book & Market Depth (max 10 points), plus the
separate Order Book Risk filter. Sections 18-19."""

from __future__ import annotations

from app.domain.enums import Direction, MarketRiskLevel
from app.domain.events import ScoreFactor
from app.domain.models import OrderBookAnalysis

_MAX_F1 = 5.0
_MAX_F2 = 5.0


def score_orderbook(
    direction: Direction, analysis: OrderBookAnalysis | None
) -> tuple[float, list[ScoreFactor]]:
    factors: list[ScoreFactor] = []

    if analysis is None:
        factors.append(ScoreFactor("F1", "orderbook", "Directional Liquidity Support", 0.0, _MAX_F1, "No order book data."))
        factors.append(ScoreFactor("F2", "orderbook", "Liquidity Path Quality", 0.0, _MAX_F2, "No order book data."))
        return 0.0, factors

    signed_imbalance = analysis.imbalance_ratio if direction == Direction.BULLISH else -analysis.imbalance_ratio
    if signed_imbalance >= 0.3:
        f1, evidence1 = 5.0, "Strong supportive liquidity imbalance."
    elif signed_imbalance >= 0.1:
        f1, evidence1 = 4.0, "Moderate supportive liquidity imbalance."
    elif signed_imbalance >= -0.1:
        f1, evidence1 = 2.0, "Neutral liquidity imbalance."
    elif signed_imbalance >= -0.3:
        f1, evidence1 = 1.0, "Weak/adverse liquidity imbalance."
    else:
        f1, evidence1 = 0.0, "Strongly adverse liquidity imbalance."
    factors.append(ScoreFactor("F1", "orderbook", "Directional Liquidity Support", f1, _MAX_F1, evidence1))

    walls_toward_target = analysis.walls_ask if direction == Direction.BULLISH else analysis.walls_bid
    walls_toward_entry_adverse = analysis.walls_bid if direction == Direction.BULLISH else analysis.walls_ask

    if not walls_toward_target and not walls_toward_entry_adverse:
        f2, evidence2 = 4.0, "Good liquidity path: no significant walls detected either side."
    elif len(walls_toward_target) == 0:
        f2, evidence2 = 5.0, "Very clean liquidity path toward target."
    elif len(walls_toward_target) == 1:
        f2, evidence2 = 3.0, "Acceptable liquidity path: one wall toward target."
    else:
        f2, evidence2 = 1.0, "Obstructed liquidity path: multiple walls toward target."
    factors.append(ScoreFactor("F2", "orderbook", "Liquidity Path Quality", f2, _MAX_F2, evidence2))

    return f1 + f2, factors


def classify_orderbook_risk(
    analysis: OrderBookAnalysis | None, spread_pct: float | None, direction: Direction
) -> tuple[MarketRiskLevel, list[str]]:
    reasons: list[str] = []

    if analysis is None:
        return MarketRiskLevel.MEDIUM, ["Order book data unavailable — risk cannot be fully assessed."]

    if analysis.liquidity_near_entry == 0 and analysis.liquidity_near_sl == 0:
        reasons.append("No measurable liquidity near entry or stop loss.")
        return MarketRiskLevel.CRITICAL, reasons

    signed_imbalance = analysis.imbalance_ratio if direction == Direction.BULLISH else -analysis.imbalance_ratio
    if signed_imbalance < -0.5:
        reasons.append("Severe liquidity imbalance against the trade direction.")
        return MarketRiskLevel.CRITICAL, reasons

    if spread_pct is not None and spread_pct > 1.0:
        reasons.append(f"Abnormal spread: {spread_pct:.2f}%.")
        return MarketRiskLevel.CRITICAL, reasons

    walls_toward_target = analysis.walls_ask if direction == Direction.BULLISH else analysis.walls_bid
    if len(walls_toward_target) >= 2:
        reasons.append("Multiple large walls obstruct the path to target.")
        return MarketRiskLevel.HIGH, reasons

    if spread_pct is not None and spread_pct > 0.5:
        reasons.append(f"Elevated spread: {spread_pct:.2f}%.")
        return MarketRiskLevel.MEDIUM, reasons

    if walls_toward_target:
        reasons.append("A liquidity wall exists toward the target; monitor for obstruction.")
        return MarketRiskLevel.MEDIUM, reasons

    return MarketRiskLevel.LOW, reasons
