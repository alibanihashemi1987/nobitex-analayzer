"""Aggregate Market Risk classification (section 35). Combines the
Order Book Risk filter (section 19) with additional factors: execution
quality, early LTF entry, and HTF/LTF conflict."""

from __future__ import annotations

from app.domain.enums import HTFAlignmentStrength, MarketRiskLevel

_ORDER = {MarketRiskLevel.LOW: 0, MarketRiskLevel.MEDIUM: 1, MarketRiskLevel.HIGH: 2, MarketRiskLevel.CRITICAL: 3}
_REVERSE = {v: k for k, v in _ORDER.items()}


def classify_market_risk(
    orderbook_risk: MarketRiskLevel,
    orderbook_risk_reasons: list[str],
    execution_quality: float,
    early_ltf_entry: bool,
    htf_alignment: HTFAlignmentStrength,
) -> tuple[MarketRiskLevel, list[str]]:
    level_index = _ORDER[orderbook_risk]
    reasons = list(orderbook_risk_reasons)

    if execution_quality < 2:
        level_index = max(level_index, _ORDER[MarketRiskLevel.HIGH])
        reasons.append(f"Execution quality is low ({execution_quality}/5).")
    elif execution_quality < 3:
        level_index = max(level_index, _ORDER[MarketRiskLevel.MEDIUM])
        reasons.append(f"Execution quality below the standard minimum ({execution_quality}/5).")

    if early_ltf_entry:
        level_index = max(level_index, _ORDER[MarketRiskLevel.MEDIUM])
        reasons.append("Early LTF execution ahead of HTF candle confirmation.")

    if htf_alignment == HTFAlignmentStrength.OPPOSITE:
        level_index = max(level_index, _ORDER[MarketRiskLevel.HIGH])
        reasons.append("HTF structure is counter-trend to this direction (HTF/LTF conflict).")

    return _REVERSE[level_index], reasons
