"""Final Direction Resolver (MANDATORY_ARCHITECTURE_CHANGE sections 5-19,
ADDITIONAL_ARCHITECTURE_REQUIREMENTS sections 9-19).

This module's ONLY responsibility is to compare two already-completed
`DirectionalAnalysis` objects and determine the final state. It must
NEVER perform technical analysis itself (no candle/indicator access).
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from app.config.scoring_config import DecisionConfig
from app.domain.directional import DirectionalAnalysis, MarketAnalysisResult
from app.domain.enums import (
    ExecutionEligibility,
    ExecutionMode,
    FinalDecision,
    HTFAlignmentStrength,
    MarketRiskLevel,
    TechnicalStatus,
)

_ALIGNMENT_RANK = {
    HTFAlignmentStrength.STRONG: 4,
    HTFAlignmentStrength.MODERATE: 3,
    HTFAlignmentStrength.WEAK: 2,
    HTFAlignmentStrength.NEUTRAL: 1,
    HTFAlignmentStrength.OPPOSITE: 0,
}


def _apply_execution_eligibility(
    analysis: DirectionalAnalysis, direction: str, execution_mode: ExecutionMode
) -> DirectionalAnalysis:
    """Section 5-8 / 17: eligibility is a platform-capability question,
    computed AFTER and independently of technical validity."""
    if execution_mode == ExecutionMode.SPOT and direction == "SHORT":
        eligibility = ExecutionEligibility.NOT_ELIGIBLE
        reason = "Current execution mode is SPOT. SHORT positions are not supported."
    else:
        eligibility = ExecutionEligibility.ELIGIBLE
        reason = None
    return replace(analysis, execution_eligibility=eligibility, execution_ineligibility_reason=reason)


def resolve_final_decision(
    long_analysis: DirectionalAnalysis,
    short_analysis: DirectionalAnalysis,
    execution_mode: ExecutionMode,
    decision_config: DecisionConfig,
    symbol: str,
    timestamp: datetime,
) -> MarketAnalysisResult:
    long_analysis = _apply_execution_eligibility(long_analysis, "LONG", execution_mode)
    short_analysis = _apply_execution_eligibility(short_analysis, "SHORT", execution_mode)

    long_ready = long_analysis.status == TechnicalStatus.READY
    short_ready = short_analysis.status == TechnicalStatus.READY

    # --- Both NOT ready (or INVALID) -> WAIT, technical absence of setup ---
    if not long_ready and not short_ready:
        reason = (
            "LONG was evaluated but did not qualify. "
            "SHORT was evaluated but did not qualify. "
            "No executable directional setup currently exists."
        )
        return MarketAnalysisResult(
            symbol=symbol, timestamp=timestamp, long_analysis=long_analysis, short_analysis=short_analysis,
            final_decision=FinalDecision.WAIT, execution_mode=execution_mode, final_reason=reason,
        )

    # --- Only one side ready ---
    if long_ready and not short_ready:
        return _finalize_single_winner("LONG", long_analysis, short_analysis, execution_mode, symbol, timestamp)
    if short_ready and not long_ready:
        return _finalize_single_winner("SHORT", long_analysis, short_analysis, execution_mode, symbol, timestamp)

    # --- Both ready: compare scores ---
    diff = round(abs(long_analysis.score - short_analysis.score), 3)
    higher_is_long = long_analysis.score >= short_analysis.score

    if diff >= decision_config.minimum_directional_score_difference:
        winner = "LONG" if higher_is_long else "SHORT"
        return _finalize_single_winner(
            winner, long_analysis, short_analysis, execution_mode, symbol, timestamp,
            score_difference=diff,
            reason_prefix=f"{winner} outperformed the other direction by {diff} points "
                          f"(>= configured minimum of {decision_config.minimum_directional_score_difference}).",
        )

    # --- Score difference below threshold: CONFLICT candidate; try the HTF tie-breaker ---
    tie_break_winner = _try_htf_tie_break(long_analysis, short_analysis)
    if tie_break_winner is not None:
        return _finalize_single_winner(
            tie_break_winner, long_analysis, short_analysis, execution_mode, symbol, timestamp,
            score_difference=diff, htf_tie_break_used=True,
            reason_prefix=(
                f"Both directions passed technical validation with a score difference of only {diff} "
                f"(below the {decision_config.minimum_directional_score_difference}-point minimum), "
                f"but {tie_break_winner} has clearly stronger HTF structural alignment."
            ),
        )

    reason = (
        f"Both LONG ({long_analysis.score}) and SHORT ({short_analysis.score}) are technically READY "
        f"with a score difference of {diff}, below the configured minimum of "
        f"{decision_config.minimum_directional_score_difference}. No HTF tie-breaker could be safely applied. "
        "The system prioritizes structural clarity over forcing a trade."
    )
    return MarketAnalysisResult(
        symbol=symbol, timestamp=timestamp, long_analysis=long_analysis, short_analysis=short_analysis,
        final_decision=FinalDecision.CONFLICT, execution_mode=execution_mode, final_reason=reason,
        score_difference=diff,
    )


def _try_htf_tie_break(
    long_analysis: DirectionalAnalysis, short_analysis: DirectionalAnalysis
) -> str | None:
    """Section 11-16 / ADDITIONAL_ARCHITECTURE_REQUIREMENTS. HTF alignment
    may ONLY break a tie when ALL of these hold:
      1. Both READY (guaranteed by caller).
      2. Both passed all Hard Gates.
      3. Neither has CRITICAL Market Risk.
      4. One direction has a STRICTLY stronger HTF alignment rank than the other.
    """
    if not (long_analysis.hard_gates_passed and short_analysis.hard_gates_passed):
        return None
    if long_analysis.market_risk == MarketRiskLevel.CRITICAL or short_analysis.market_risk == MarketRiskLevel.CRITICAL:
        return None

    long_rank = _ALIGNMENT_RANK[long_analysis.htf_alignment]
    short_rank = _ALIGNMENT_RANK[short_analysis.htf_alignment]

    if long_rank > short_rank:
        return "LONG"
    if short_rank > long_rank:
        return "SHORT"
    return None  # equal alignment strength (e.g. both STRONG) -> do not force; CONFLICT


def _finalize_single_winner(
    winner: str,
    long_analysis: DirectionalAnalysis,
    short_analysis: DirectionalAnalysis,
    execution_mode: ExecutionMode,
    symbol: str,
    timestamp: datetime,
    score_difference: float | None = None,
    htf_tie_break_used: bool = False,
    reason_prefix: str | None = None,
) -> MarketAnalysisResult:
    winning_analysis = long_analysis if winner == "LONG" else short_analysis
    decision_symbol = FinalDecision.BUY if winner == "LONG" else FinalDecision.SELL

    if winning_analysis.execution_eligibility == ExecutionEligibility.NOT_ELIGIBLE:
        reason = (
            f"{winner} is technically READY ({winning_analysis.score}/100), "
            f"but cannot be executed under {execution_mode.value} mode: "
            f"{winning_analysis.execution_ineligibility_reason}"
        )
        return MarketAnalysisResult(
            symbol=symbol, timestamp=timestamp, long_analysis=long_analysis, short_analysis=short_analysis,
            final_decision=FinalDecision.WAIT, execution_mode=execution_mode, final_reason=reason,
            directional_winner=winner, score_difference=score_difference, htf_tie_break_used=htf_tie_break_used,
        )

    reason = reason_prefix or (
        f"{winner} passed all mandatory gates, met the configured risk threshold, "
        f"and is executable under {execution_mode.value} mode."
    )
    return MarketAnalysisResult(
        symbol=symbol, timestamp=timestamp, long_analysis=long_analysis, short_analysis=short_analysis,
        final_decision=decision_symbol, execution_mode=execution_mode, final_reason=reason,
        directional_winner=winner, score_difference=score_difference, htf_tie_break_used=htf_tie_break_used,
    )
