"""Core direction-parameterized evaluation logic.

`evaluate_long` and `evaluate_short` are thin wrappers around
`_evaluate_direction`, each calling it with their own `Direction` value
and nothing else. This is a code-reuse detail only -- it does NOT create
a data dependency between the two: `_evaluate_direction` is a pure
function of `(direction, context, config, risk_profile)`, so calling it
twice with LONG then SHORT produces two fully independent results, per
MANDATORY_ARCHITECTURE_CHANGE section 1 ("The LONG evaluator must NEVER
depend on the result of the SHORT evaluator" -- and vice versa).
"""

from __future__ import annotations

from app.config.scoring_config import ScoringConfig
from app.core.exceptions import InvalidSetupError
from app.domain.context import MarketContext
from app.domain.directional import DirectionalAnalysis
from app.domain.enums import (
    Direction,
    ExecutionEligibility,
    HTFAlignmentStrength,
    MarketRiskLevel,
    RiskProfileName,
    TechnicalStatus,
)
from app.domain.events import ScoreBreakdown, ScoreFactor
from app.orderbook.analyzer import analyze_orderbook
from app.risk.risk_engine import calculate_risk_levels
from app.strategy.scoring.category_execution import score_execution
from app.strategy.scoring.category_liquidity import score_liquidity
from app.strategy.scoring.category_momentum import score_momentum
from app.strategy.scoring.category_mtf import score_mtf
from app.strategy.scoring.category_orderbook import classify_orderbook_risk, score_orderbook
from app.strategy.scoring.category_poi import score_poi, select_primary_poi_with_liquidity
from app.strategy.scoring.category_premium_discount import score_premium_discount
from app.strategy.scoring.category_structure import _htf_direction_chain_length, score_structure
from app.strategy.scoring.hard_gates import run_hard_gates
from app.strategy.scoring.htf_alignment import classify_htf_alignment
from app.strategy.scoring.market_risk import classify_market_risk

_RISK_LEVEL_ORDER = {
    MarketRiskLevel.LOW: 0, MarketRiskLevel.MEDIUM: 1,
    MarketRiskLevel.HIGH: 2, MarketRiskLevel.CRITICAL: 3,
}


def _evaluate_direction(
    direction: Direction,
    context: MarketContext,
    config: ScoringConfig,
    risk_profile: str = "moderate",
) -> DirectionalAnalysis:
    htf = context.timeframes.get("HTF")
    mtf = context.timeframes.get("MTF")
    ltf = context.timeframes.get("LTF")
    execution_tf = context.timeframes.get("EXECUTION")

    entry_source = execution_tf or ltf or mtf or htf
    if entry_source is None or not entry_source.candles or htf is None:
        return _invalid_result(direction, "No candle data available for any configured timeframe.")

    current_price = entry_source.candles[-1].close

    # --- Category A: Market Structure (HTF) ---
    a_points, a_factors = score_structure(
        direction, htf.structure, htf.indicators.ma, htf.indicators.ma20_slope_pct
    )

    # --- Primary POI selection + Category B: POI Quality (HTF) ---
    primary_poi = select_primary_poi_with_liquidity(direction, htf.pois, htf.liquidity, htf.structure)
    b_points, b_factors, primary_poi = score_poi(direction, primary_poi, htf.structure)

    # --- Category C: Liquidity & Price Action (LTF if available, else HTF) ---
    liquidity_tf = ltf or htf
    c_points, c_factors = score_liquidity(direction, liquidity_tf.liquidity, liquidity_tf.structure, current_price)

    # --- Category D: Momentum (execution/LTF timeframe) ---
    momentum_tf = execution_tf or ltf or htf
    d_points, d_factors = score_momentum(direction, momentum_tf.indicators.mfi, momentum_tf.indicators.rsi)

    # --- Category E: Multi-Timeframe Alignment ---
    e_points, e_factors = score_mtf(
        direction, htf.structure,
        mtf.structure if mtf else None,
        ltf.structure if ltf else None,
        ltf.liquidity if ltf else None,
        ltf.pois if ltf else None,
    )

    # --- Early LTF entry detection (documented heuristic -- see STRATEGY.md) ---
    htf_chain = _htf_direction_chain_length(htf.structure.breaks, direction)
    early_ltf_entry = e_points > 0 and (htf_chain is None or htf_chain == 0)

    # --- Category H: Premium/Discount (HTF range) + its Gate 4 signal ---
    h_points, h_factors, pd_gate_failed = score_premium_discount(direction, htf.indicators.premium_discount)

    # --- Risk levels (Entry/SL/TP) -- needed before Order Book & Execution categories ---
    risk = None
    if primary_poi is not None:
        invalidation = primary_poi.zone_low if direction == Direction.BULLISH else primary_poi.zone_high
        atr = (execution_tf or ltf or htf).indicators.atr or 0.0
        try:
            risk = calculate_risk_levels(
                direction=direction,
                entry=current_price,
                invalidation_level=invalidation,
                atr_buffer=atr * config.risk.atr_buffer_multiplier,
                r_multiples=config.risk.r_multiples,
            )
        except InvalidSetupError:
            risk = None

    # --- Directional order-book re-derivation (same cached raw book, direction-specific interpretation) ---
    directional_orderbook_analysis = None
    spread_pct = context.orderbook.spread_pct if context.orderbook else None
    if context.orderbook is not None and context.orderbook.raw is not None and risk is not None:
        directional_orderbook_analysis = analyze_orderbook(
            context.orderbook.raw, entry=risk.entry, stop_loss=risk.stop_loss, take_profit=risk.tp1
        )
    elif context.orderbook is not None:
        directional_orderbook_analysis = context.orderbook.analysis

    # --- Category F: Order Book ---
    f_points, f_factors = score_orderbook(direction, directional_orderbook_analysis)
    orderbook_risk, orderbook_risk_reasons = classify_orderbook_risk(
        directional_orderbook_analysis, spread_pct, direction
    )

    # --- Category G: Execution Quality ---
    g_points, g_factors, early_penalty_applied = score_execution(
        risk, config.risk.minimum_risk_reward, spread_pct, early_ltf_entry, config.execution.early_ltf_penalty
    )

    # --- HTF alignment + aggregate Market Risk ---
    htf_alignment = classify_htf_alignment(direction, htf.structure)
    market_risk, market_risk_reasons = classify_market_risk(
        orderbook_risk, orderbook_risk_reasons, g_points, early_ltf_entry, htf_alignment
    )

    total = a_points + b_points + c_points + d_points + e_points + f_points + g_points + h_points
    all_factors: list[ScoreFactor] = [*a_factors, *b_factors, *c_factors, *d_factors,
                                       *e_factors, *f_factors, *g_factors, *h_factors]
    breakdown = ScoreBreakdown(
        structure=a_points, poi=b_points, liquidity=c_points, momentum=d_points,
        mtf=e_points, orderbook=f_points, execution=g_points, premium_discount=h_points,
        total=round(total, 3), factors=tuple(all_factors),
    )

    hard_gates_passed, gate_results = run_hard_gates(
        context, direction, primary_poi, pd_gate_failed, risk, config.risk.minimum_risk_reward
    )
    gate_failures = tuple(g.reason for g in gate_results if not g.passed)

    profile = config.risk_profiles.get(risk_profile, config.risk_profiles.get(RiskProfileName.MODERATE.value))
    max_allowed_risk = MarketRiskLevel(profile.maximum_market_risk) if profile else MarketRiskLevel.HIGH
    threshold_ok = profile is not None and breakdown.total >= profile.threshold
    execution_ok = profile is not None and g_points >= profile.minimum_execution
    risk_ok = _RISK_LEVEL_ORDER[market_risk] <= _RISK_LEVEL_ORDER[max_allowed_risk]

    if not gate_results[0].passed:  # GATE_1 data validity
        status = TechnicalStatus.INVALID
    elif hard_gates_passed and threshold_ok and execution_ok and risk_ok:
        status = TechnicalStatus.READY
    else:
        status = TechnicalStatus.NOT_READY

    rejection_reasons: list[str] = list(gate_failures)
    if hard_gates_passed:
        if not threshold_ok and profile is not None:
            rejection_reasons.append(f"Score {breakdown.total} below {risk_profile} threshold ({profile.threshold}).")
        if not execution_ok and profile is not None:
            rejection_reasons.append(f"Execution Quality {g_points}/5 below minimum ({profile.minimum_execution}).")
        if not risk_ok:
            rejection_reasons.append(f"Market Risk {market_risk.value} exceeds maximum allowed ({max_allowed_risk.value}).")
    if market_risk in (MarketRiskLevel.HIGH, MarketRiskLevel.CRITICAL):
        rejection_reasons.extend(market_risk_reasons)

    return DirectionalAnalysis(
        direction=direction.value,
        status=status,
        execution_eligibility=ExecutionEligibility.UNKNOWN,  # set later by the resolver, per section 17
        execution_ineligibility_reason=None,
        score_breakdown=breakdown,
        execution_quality=g_points,
        market_risk=market_risk,
        htf_alignment=htf_alignment,
        hard_gates_passed=hard_gates_passed,
        hard_gate_failures=gate_failures,
        primary_poi=primary_poi,
        risk=risk,
        rejection_reasons=tuple(rejection_reasons),
        early_ltf_entry=early_penalty_applied,
    )


def _invalid_result(direction: Direction, reason: str) -> DirectionalAnalysis:
    empty_breakdown = ScoreBreakdown(
        structure=0, poi=0, liquidity=0, momentum=0, mtf=0, orderbook=0,
        execution=0, premium_discount=0, total=0, factors=(),
    )
    return DirectionalAnalysis(
        direction=direction.value,
        status=TechnicalStatus.INVALID,
        execution_eligibility=ExecutionEligibility.UNKNOWN,
        execution_ineligibility_reason=None,
        score_breakdown=empty_breakdown,
        execution_quality=0.0,
        market_risk=MarketRiskLevel.CRITICAL,
        htf_alignment=HTFAlignmentStrength.NEUTRAL,
        hard_gates_passed=False,
        hard_gate_failures=(reason,),
        primary_poi=None,
        risk=None,
        rejection_reasons=(reason,),
    )
