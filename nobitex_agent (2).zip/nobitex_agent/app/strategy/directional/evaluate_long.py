from __future__ import annotations

from app.config.scoring_config import ScoringConfig
from app.domain.context import MarketContext
from app.domain.directional import DirectionalAnalysis
from app.domain.enums import Direction
from app.strategy.directional.common import _evaluate_direction


def evaluate_long(
    context: MarketContext,
    config: ScoringConfig,
    risk_profile: str = "moderate",
) -> DirectionalAnalysis:
    """Independently evaluates the LONG scenario. Never reads or is
    influenced by any SHORT-side computation."""
    return _evaluate_direction(Direction.BULLISH, context, config, risk_profile)
