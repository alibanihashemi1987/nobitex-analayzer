"""Order Book liquidity analysis.

A "wall" is flagged only when its volume exceeds `wall_multiplier` times
the AVERAGE volume-per-level in that side of the book — a large level in
isolation is not automatically meaningful; it must be large *relative to*
the surrounding book (configurable, per spec section 5).
"""

from __future__ import annotations

from app.domain.models import OrderBookAnalysis


def analyze_orderbook(
    raw_orderbook: dict,
    entry: float,
    stop_loss: float,
    take_profit: float,
    wall_multiplier: float = 3.0,
    price_proximity_pct: float = 0.5,
) -> OrderBookAnalysis:
    bids = [(float(p), float(v)) for p, v in raw_orderbook.get("bids", [])]
    asks = [(float(p), float(v)) for p, v in raw_orderbook.get("asks", [])]

    bid_volume = sum(v for _, v in bids)
    ask_volume = sum(v for _, v in asks)
    total = bid_volume + ask_volume
    imbalance_ratio = (bid_volume - ask_volume) / total if total > 0 else 0.0

    walls_bid = _find_walls(bids, wall_multiplier)
    walls_ask = _find_walls(asks, wall_multiplier)

    liquidity_near_entry = _liquidity_near(bids + asks, entry, price_proximity_pct)
    liquidity_near_sl = _liquidity_near(bids + asks, stop_loss, price_proximity_pct)
    liquidity_near_tp = _liquidity_near(bids + asks, take_profit, price_proximity_pct)

    return OrderBookAnalysis(
        bid_volume=bid_volume,
        ask_volume=ask_volume,
        imbalance_ratio=round(imbalance_ratio, 4),
        walls_bid=walls_bid,
        walls_ask=walls_ask,
        liquidity_near_entry=liquidity_near_entry,
        liquidity_near_sl=liquidity_near_sl,
        liquidity_near_tp=liquidity_near_tp,
    )


def _find_walls(levels: list[tuple[float, float]], multiplier: float) -> list[tuple[float, float]]:
    if not levels:
        return []
    avg_volume = sum(v for _, v in levels) / len(levels)
    if avg_volume == 0:
        return []
    return [(p, v) for p, v in levels if v >= avg_volume * multiplier]


def _liquidity_near(levels: list[tuple[float, float]], price: float, proximity_pct: float) -> float:
    if price == 0:
        return 0.0
    band = price * (proximity_pct / 100.0)
    return sum(v for p, v in levels if abs(p - price) <= band)
