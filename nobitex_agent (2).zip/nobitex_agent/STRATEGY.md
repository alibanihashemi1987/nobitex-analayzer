# Strategy Rules Reference

This document describes the **Dual-Side LONG/SHORT Deterministic
Confluence Engine** -- the second-generation architecture that replaced
the original single-direction weighted-sum engine. It implements:

- `MANDATORY_ARCHITECTURE_CHANGE.md` -- independent LONG/SHORT evaluation,
  the Final Direction Resolver, CONFLICT state, SPOT/COMMITMENT execution
  modes.
- `ADDITIONAL_ARCHITECTURE_REQUIREMENTS.md` -- the cached, immutable
  `MarketContext`, the Technical Status / Execution Eligibility split,
  and the HTF alignment tie-breaker.
- `REPLACEMENT_MODULE.md` -- the deterministic 100-point, 8-category
  confluence score, Hard Gates, Execution Quality, Market Risk, the
  Equilibrium Buffer for Premium/Discount, and score traceability.

The old single-direction confluence engine (Trend=25/POI=35/MFI=20/
RSI=20) has been **completely removed** from the codebase, per
REPLACEMENT_MODULE section 44.

## Core principle

The system is a **dual-side market analysis engine**, not a buy-signal
generator. Every analysis cycle independently answers "what does the
market offer for LONG?" and "what does the market offer for SHORT?"
*before* asking "can the current execution mode actually trade that?"
`WAIT` never means "LONG failed" -- it means neither direction currently
has an executable setup. A `CONFLICT` state exists for when both sides
are genuinely valid and the system won't force a coin-flip.

## Pipeline (one analysis cycle)

```
Fetch candles (HTF/MTF/LTF/EXECUTION) + order book   <- the only network I/O
        v
build_market_context()   <- ONE immutable snapshot, computed once
        v
   +----+----+
   v         v
evaluate_long   evaluate_short      <- fully independent, share the same context
   v         v
   +----+----+
        v
resolve_final_decision()   <- comparison only, no technical analysis
        v
BUY / SELL / WAIT / CONFLICT
```

`app/domain/context.py:build_market_context` computes every shared
value (swings, BOS/CHoCH, FVGs, Order Blocks, Breaker Blocks, Mitigation
Blocks, liquidity sweeps, MA20/MA200 + slope, RSI14, MFI10, ATR,
Premium/Discount) **exactly once**, for each of the HTF/MTF/LTF/EXECUTION
timeframe roles, and stores it in a frozen `MarketContext`. Both
`evaluate_long` and `evaluate_short` (`app/strategy/directional/`) read
from this same object -- they never recompute a shared value and never
see each other's result.

## Confluence Score -- 100 points across 8 categories

| Category | Max | Module |
|---|---:|---|
| A. Market Structure | 20 | `scoring/category_structure.py` |
| B. POI Quality | 25 | `scoring/category_poi.py` |
| C. Liquidity & Price Action | 15 | `scoring/category_liquidity.py` |
| D. Momentum | 10 | `scoring/category_momentum.py` |
| E. Multi-Timeframe Alignment | 10 | `scoring/category_mtf.py` |
| F. Order Book & Market Depth | 10 | `scoring/category_orderbook.py` |
| G. Execution Quality | 5 | `scoring/category_execution.py` |
| H. Premium/Discount Location | 5 | `scoring/category_premium_discount.py` |

Every category is scored **independently for LONG and for SHORT** using
the same underlying `MarketContext`. Weights are centralized in
`app/config/scoring_config.yaml` (never hard-coded) and validated to sum
to 100 at load time (`CategoryWeights.__post_init__`).

### A. Market Structure (20)
- **A1 HTF direction (10)**: consecutive same-direction BOS-chain length
  since the last CHoCH -- chain >=3 = strong (10), 1-2 = moderate (7),
  0 (just flipped, no confirming BOS yet) = weak (4), opposed/unknown = 0.
- **A2 MA200 macro bias (5)**: price on the correct side of MA200 = 5, else 0.
- **A3 MA20 slope (3)**: `slope = (MA20[now] - MA20[N]) / MA20[N]`,
  `N` = `ma20_slope_lookback` (default 3). Aligned slope = 3, near-zero = 1,
  opposed = 0.
- **A4 MA20/MA200 relationship (2)**: correctly stacked = 2, a *fresh*
  cross in the right direction = 1, else 0.

### B. POI Quality (25)
Uses the single **Primary POI** selection (`scoring/primary_poi.py`,
`scoring/category_poi.py:select_primary_poi_with_liquidity`), following
this exact priority order -- the same selection feeds both Gate 3 and
Category B, so there's only ever one "primary" POI per cycle:
1. Liquidity Sweep + Structural Shift (12 pts if primary)
2. Order Block / Breaker Block (10)
3. FVG (8)
4. OTE (7)
5. Mitigation Block (6)
6. Volume Imbalance (5)
7. Dynamic MA (4) -- *not implemented as a POI type in this build; listed
   for forward compatibility only, never selected.*

- **B1 Primary POI Strength (12)**: table above.
- **B2 POI Freshness (5)**: ACTIVE=5, PARTIALLY_MITIGATED=3,
  MITIGATED=1, INVALIDATED=0.
- **B3 Structural Association (5)**: POI is the direct origin of a
  BOS/CHoCH = 5, POI near confirmed structure = 3, no confirmed HTF
  breaks yet = 1.
- **B4 Reaction Quality (3)**: uses the Order Block's ATR-based
  `strength_score` where available (>=0.66=3, >=0.33=2, else 1); POI types
  without an explicit strength measure get a documented moderate
  default (2).

### C. Liquidity & Price Action (15)
- **C1 Liquidity Sweep (7)**: confirmed sweep + reversal = 7, sweep
  without confirmed reversal = 4, none = 0.
- **C2 Structural Reaction (4)**: independent of C1 -- scores the most
  recent same-direction BOS/CHoCH on the liquidity timeframe (4) vs none (0).
- **C3 Liquidity Target Quality (4)**: an unswept opposite-direction
  swing beyond current price = external target (4); an unswept opposite
  swing on the near side = internal target (3); any swing at all = weak (1);
  none = 0.

### D. Momentum (10) -- MFI10 (5) + RSI14 (5)
Same tiered rule for both oscillators: regular divergence matching
direction = 5, hidden divergence matching direction = 4, oscillator at
an extreme (oversold for LONG / overbought for SHORT) = 3, supportive
side of the midline = 2, neutral band (45-55) = 1, opposed = 0.

### E. Multi-Timeframe Alignment (10)
- **E1 HTF+MTF (6)**: both aligned = 6, HTF aligned + MTF neutral = 4,
  HTF aligned + MTF counter-trend = 1, HTF not aligned = 0.
- **E2 LTF Confirmation (4)**: a same-direction LTF structure break = 4
  (strong), a matching LTF liquidity sweep = 3 (moderate), a matching
  active LTF FVG only = 1 (weak), none = 0. This is also what marks a
  setup as an `EARLY_LTF_ENTRY` (see Execution Quality below) when the
  HTF hasn't yet confirmed via its own BOS.

### F. Order Book & Market Depth (10)
Re-derives `OrderBookAnalysis` from the **same cached raw order book**
using the direction's actual computed Entry/SL/TP (this direction-specific
re-derivation from already-fetched data is explicitly allowed per
ADDITIONAL_ARCHITECTURE_REQUIREMENTS section 21 -- it is not a new network
call).
- **F1 Directional Liquidity Support (5)**: signed bid/ask imbalance
  (flipped for SHORT) mapped across 5 tiers from strongly-adverse (0) to
  strong (5).
- **F2 Liquidity Path Quality (5)**: counts liquidity walls between
  entry and the target side; 0 walls toward target = 5 (very clean),
  1 wall = 3 (acceptable), >=2 = 1 (obstructed).

A separate **Order Book Risk filter** (`classify_orderbook_risk`) feeds
into Market Risk: zero measurable liquidity near entry/SL, severe
adverse imbalance, or an abnormal spread (>1%) are each independently
sufficient to classify `CRITICAL`.

### G. Execution Quality (5)
Starts at 5 and subtracts: 2 points if R:R to TP1 is below the
configured minimum, 1 point for an elevated spread (>0.5%), and
`early_ltf_penalty` (default 1) for an `EARLY_LTF_ENTRY` -- never below 0.
This same 0-5 value is also reported as the standalone "Execution
Quality" metric (`DirectionalAnalysis.execution_quality`).

### H. Premium/Discount Location (5) -- Equilibrium Buffer
**Not** a rigid 50% boundary. Uses an Equilibrium Buffer (default +/-2%
around the 50% mark of the HTF dealing range --
`app/config/scoring_config.yaml: scoring.premium_discount`):
Discount (LONG) / Premium (SHORT) = 5, Equilibrium Buffer = 2 (allowed,
lower quality), the wrong side = 0 **and** fails Gate 4.

## Hard Gates (`scoring/hard_gates.py`)

Pass/fail checks, completely separate from scoring. A failed gate
invalidates the setup **regardless of score** -- a high score can never
override a failed Hard Gate.

1. **GATE_1 Data Validity** -- `MarketContext.data_validity == VALID`.
2. **GATE_2 HTF Structure Confirmed** -- at least 2 confirmed HTF swing
   points exist (deterministic proxy for "structure is not unclear").
3. **GATE_3 Valid HTF POI** -- a Primary POI was found for this direction.
4. **GATE_4 Premium/Discount Direction** -- price is not in the wrong
   zone (Premium for LONG / Discount for SHORT) per the Equilibrium
   Buffer rule above.
5. **GATE_5 Valid SL/TP & R:R** -- Entry/SL/TP could be computed and the
   R:R to TP1 clears `risk.minimum_risk_reward`. (This extends the
   spec's 4 named gates with an explicit 5th -- R:R/SL/TP validity is
   listed among the WAIT conditions in REPLACEMENT_MODULE section 33
   but wasn't given its own gate number; making it GATE_5 keeps every
   invalidation reason auditable via the same `GateResult` structure.)

## Market Risk (`scoring/market_risk.py`)

Aggregates the Order Book Risk filter, Execution Quality,
`EARLY_LTF_ENTRY` status, and HTF alignment into LOW/MEDIUM/HIGH/CRITICAL.
A `CRITICAL` classification also disables the HTF tie-breaker in the
resolver (see below) -- risk classification is never allowed to be
overridden by a forced directional pick.

## Technical Status vs. Execution Eligibility

`DirectionalAnalysis` deliberately keeps these separate
(ADDITIONAL_ARCHITECTURE_REQUIREMENTS section 5-8):

- **`status`** (`TechnicalStatus`: READY/NOT_READY/INVALID) -- did this
  direction pass all Hard Gates, clear its risk-profile score threshold,
  meet minimum Execution Quality, and stay within the max allowed Market
  Risk? Computed with **zero knowledge of the execution mode**.
- **`execution_eligibility`** (`ExecutionEligibility`: ELIGIBLE/
  NOT_ELIGIBLE/UNKNOWN) -- set **afterward**, by the resolver, purely
  from the SPOT/COMMITMENT execution mode. In SPOT, SHORT is always
  `NOT_ELIGIBLE` regardless of how strong the technical setup is.

A READY-but-NOT_ELIGIBLE SHORT under SPOT mode still shows its full
score and reasoning in the report -- it is never hidden or discarded.

## Final Direction Resolver (`strategy/directional/resolver.py`)

Pure comparison logic -- never touches candles or indicators.

1. **Both NOT_READY/INVALID** -> `WAIT`, with the explicit reason "LONG
   was evaluated but did not qualify. SHORT was evaluated but did not
   qualify. No executable directional setup currently exists."
2. **Only one READY** -> that direction wins *if* it's execution-eligible
   under the current mode, else `WAIT` (but the technical READY status
   and score are still reported -- see the SPOT example below).
3. **Both READY**, score gap >= `decision.minimum_directional_score_difference`
   (default 8) -> the higher-scoring direction wins.
4. **Both READY**, score gap below that minimum -> **HTF tie-breaker**
   attempted (see below); if it can't safely resolve, -> `CONFLICT`.

### HTF Alignment Tie-Breaker (`scoring/htf_alignment.py`)

Classifies each direction's alignment with the HTF trend/BOS-chain as
STRONG/MODERATE/WEAK/NEUTRAL/OPPOSITE. The tie-breaker may pick a winner
**only when all of these hold**:
1. Both directions are READY.
2. Both passed every Hard Gate.
3. Neither has CRITICAL Market Risk.
4. One direction's HTF alignment rank is *strictly* higher than the
   other's (equal ranks, even both STRONG, never force a pick).

If any condition fails, the result is `CONFLICT` -- the system
"prioritizes structural clarity over score maximization" per
ADDITIONAL_ARCHITECTURE_REQUIREMENTS section 11.

## SPOT vs. COMMITMENT execution mode

Execution mode **never** changes the technical analysis -- both
directions are always fully evaluated. It is applied only in the
resolver, after both `DirectionalAnalysis` objects exist:

- **SPOT**: LONG eligible, SHORT never eligible. A READY SHORT under
  SPOT still reports `Technical Status: READY`, `Execution Eligibility:
  NOT_ELIGIBLE`, and the final decision is `WAIT` with an explicit
  reason distinguishing "not eligible in this mode" from "not ready".
- **COMMITMENT**: both directions eligible when technically READY.

## Backtesting (`services/backtest_service.py`)

Walks candles chronologically; at every step it builds a `MarketContext`
from `candles[:i]` only (the entire lookahead-bias guarantee), then runs
the **exact same** `evaluate_long` -> `evaluate_short` ->
`resolve_final_decision` pipeline used live -- never a simplified
BUY-only shortcut (MANDATORY_ARCHITECTURE_CHANGE section 21). The
summary report (`summarize_backtest`) exposes LONG/SHORT opportunity
counts, BUY/SELL/WAIT/CONFLICT period counts -- never "BUY signals" alone.

**Known simplification**: true multi-timeframe backtesting requires
resampling one base candle series into synchronized HTF/MTF/LTF/EXECUTION
series. That resampler is not implemented in this build -- the
backtester currently runs all four timeframe roles off the same input
series. The dual-direction decision architecture and lookahead-safety
guarantee are still fully exercised; only the "genuine multi-timeframe"
aspect is approximated until a resampler is added.

## Score Traceability & Auditability

Every awarded point traces to a `ScoreFactor` (factor ID, category,
awarded/max points, a human-readable evidence string, and the
`event_id`s that justified it) -- see `app/domain/events.py`. A full
`AnalysisRecord` (both directions' scores, statuses, entry/SL/TP,
rejection reasons, and the final decision/reason) is persisted for
**every** cycle, live or backtest, regardless of whether a trade was
taken -- see `app/database/models.py:AnalysisRecord` and
REPLACEMENT_MODULE section 38.

## Underlying detector rules (unchanged from the first-generation build)

The individual ICT/SMC detectors that feed this scoring engine -- swing
points, BOS/CHoCH, FVG, Order Block, Breaker Block, Mitigation Block,
Volume Imbalance, Liquidity Sweep, Turtle Soup, OTE, MA20/MA200, RSI14/
MFI10 divergence -- are unchanged from the original build. Their exact
deterministic rules are documented in each module's docstring
(`app/indicators/`, `app/strategy/ict/`, `app/strategy/liquidity/`,
`app/strategy/fibonacci/`, `app/strategy/smc/structure.py`).

## Signal outcome tie-break (`app/tracking/performance_tracker.py`)

Unchanged: if a single candle's range contains both the stop loss and a
take-profit level, SL is assumed hit first unless the candle's `open`
price is already past TP1 in the signal's favor.

## Known limitations

- **Dynamic MA as a POI type** is not implemented (see Category B above).
- **Multi-timeframe backtesting** uses one candle series for all roles
  (see Backtesting above) -- a resampler is the natural next addition.
- **Anti-double-counting `EventRegistry`** (`app/domain/events.py`) is
  implemented and available, but the category-scoring functions
  currently prevent double counting through their own structural design
  (e.g. C1 and C2 deliberately measure different event types) rather
  than by actively consulting the registry on every factor award. Wiring
  every `ScoreFactor` award through `EventRegistry.already_counted` /
  `.consume()` is a natural hardening step if new categories are added
  later.
