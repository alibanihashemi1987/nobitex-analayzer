# ADDITIONAL ARCHITECTURE REQUIREMENTS
# CONTEXT CACHING, EXECUTION ELIGIBILITY & HTF CONFLICT RESOLUTION

The following requirements are mandatory extensions to the Dual-Side LONG/SHORT Analysis Engine.

These changes must be implemented in both Live Analysis and Backtesting.

---

# 1. READ-ONLY MARKET CONTEXT CACHING

The system MUST create a single immutable `MarketContext` snapshot at the beginning of every analysis cycle.

The purpose is to prevent duplicate calculations and, more importantly, guarantee that LONG and SHORT evaluations use exactly the same market state.

Architecture:

```text
Market Data
     ↓
Data Validation
     ↓
MarketContext Builder
     ↓
Immutable MarketContext
     ├───────────────┐
     ↓               ↓
LONG Evaluator   SHORT Evaluator
     ↓               ↓
     └───────┬───────┘
             ↓
       Decision Resolver
```

The following calculations must be performed ONCE per analysis cycle and stored in `MarketContext`:

- OHLCV datasets
- Closed-candle datasets
- HTF structure
- MTF structure
- LTF structure
- Swing Highs
- Swing Lows
- BOS
- CHoCH
- FVGs
- Order Blocks
- Breaker Blocks
- Mitigation Blocks
- Liquidity pools
- Liquidity sweeps
- Fibonacci ranges
- Premium/Discount levels
- MA20
- MA200
- MA20 slope
- MA20/MA200 relationship
- MFI10
- RSI14
- MFI divergences
- RSI divergences
- volatility metrics
- ATR where applicable
- Order Book snapshot
- Bid/Ask imbalance
- Liquidity walls
- Spread
- market timestamp

LONG and SHORT evaluators MUST NOT independently recalculate these values.

---

# 2. IMMUTABLE MARKET CONTEXT

`MarketContext` must behave as a read-only snapshot.

Example:

```python
@dataclass(frozen=True)
class MarketContext:
    symbol: str
    timestamp: datetime

    candles: Mapping[str, DataFrame]

    structure: Mapping[str, StructureState]

    swings: Mapping[str, SwingData]

    pois: Mapping[str, list[POIEvent]]

    liquidity: LiquidityContext

    indicators: IndicatorContext

    orderbook: OrderBookContext

    volatility: VolatilityContext
```

The evaluators may READ from the context but must not mutate it.

This prevents:

```text
LONG evaluation changes context
        ↓
SHORT evaluation sees different data
```

Such behavior is forbidden.

Both evaluators must see the exact same snapshot.

---

# 3. SINGLE-SNAPSHOT GUARANTEE

For every analysis cycle:

```python
context = build_market_context(...)
```

must execute exactly once.

Then:

```python
long_result = evaluate_long(context, config)
short_result = evaluate_short(context, config)
```

must use the same `context` object.

Do NOT do:

```python
evaluate_long(build_market_context(...))
evaluate_short(build_market_context(...))
```

because this can result in different timestamps, order-book states, indicator calculations, or candle states.

---

# 4. BACKTEST CONTEXT CACHING

The Backtester must use the same architecture.

For each historical evaluation timestamp:

```text
Historical Candle
      ↓
Historical MarketContext
      ↓
LONG Evaluation
SHORT Evaluation
      ↓
Resolver
```

The historical context must contain ONLY information available at that historical timestamp.

This is mandatory to prevent lookahead bias.

The system must NEVER use future candles when constructing a historical `MarketContext`.

---

# 5. EXECUTION ELIGIBILITY

The `DirectionalAnalysis` model MUST distinguish between:

1. Technical validity
2. Execution eligibility

Do not use the `status` field for both purposes.

Implement:

```python
class TechnicalStatus(str, Enum):
    READY = "READY"
    NOT_READY = "NOT_READY"
    INVALID = "INVALID"
```

and:

```python
class ExecutionEligibility(str, Enum):
    ELIGIBLE = "ELIGIBLE"
    NOT_ELIGIBLE = "NOT_ELIGIBLE"
    UNKNOWN = "UNKNOWN"
```

The directional model must contain both:

```python
class DirectionalAnalysis(BaseModel):

    direction: Literal["LONG", "SHORT"]

    status: TechnicalStatus

    execution_eligibility: ExecutionEligibility

    execution_ineligibility_reason: Optional[str]

    score: float

    execution_quality: float

    market_risk: MarketRiskLevel

    ...
```

---

# 6. TECHNICAL STATUS VS EXECUTION ELIGIBILITY

These two fields represent completely different concepts.

Example:

```text
SHORT

Technical Status:
READY

Execution Eligibility:
NOT_ELIGIBLE

Reason:
Current execution mode is SPOT.
SHORT positions are not supported.
```

This does NOT mean the SHORT setup is technically bad.

It means:

```text
Technical Analysis = valid
Platform Execution = unavailable
```

This distinction must be preserved in the database, API, backtester, and reports.

---

# 7. SPOT MODE BEHAVIOR

In SPOT:

```text
LONG:
Technical analysis → performed
Execution eligibility → ELIGIBLE

SHORT:
Technical analysis → performed
Execution eligibility → NOT_ELIGIBLE
```

Never skip SHORT analysis simply because the execution mode is SPOT.

The user must still be able to see that a technically valid SHORT opportunity existed.

---

# 8. COMMITMENT MODE BEHAVIOR

In COMMITMENT mode:

```text
LONG:
Technical analysis → performed
Execution eligibility → ELIGIBLE

SHORT:
Technical analysis → performed
Execution eligibility → ELIGIBLE
```

Both directions are fully executable, subject to all other risk and execution rules.

---

# 9. FINAL RESOLVER PRIORITY

The Resolver must distinguish:

```text
Technical Validity
Execution Eligibility
Directional Strength
HTF Alignment
Market Risk
```

The resolver must NOT simply select the highest score.

---

# 10. CONFLICT DEFINITION

A directional conflict exists when:

```text
LONG.status == READY
AND
SHORT.status == READY
AND
abs(LONG.score - SHORT.score)
<
minimum_directional_score_difference
```

Default:

```yaml
decision:
  minimum_directional_score_difference: 8
```

Example:

```text
LONG  = 84
SHORT = 81

Difference = 3
```

This is a CONFLICT candidate.

---

# 11. HTF ALIGNMENT AS A CONDITIONAL TIE-BREAKER

When both LONG and SHORT are technically READY and their score difference is below the configured threshold, the system MAY use HTF structural alignment as a tie-breaker.

However:

IMPORTANT:

HTF alignment must NOT override a failed Hard Gate.

HTF alignment must NOT convert a NOT_READY setup into READY.

HTF alignment is ONLY allowed to resolve an otherwise valid directional conflict.

---

# 12. HTF TIE-BREAKER RULE

Define:

```text
HTF_DIRECTION =
    BULLISH
    BEARISH
    NEUTRAL
```

Then:

### Bullish HTF

If:

```text
LONG.status == READY
SHORT.status == READY
HTF_DIRECTION == BULLISH
```

then LONG receives directional preference.

### Bearish HTF

If:

```text
LONG.status == READY
SHORT.status == READY
HTF_DIRECTION == BEARISH
```

then SHORT receives directional preference.

### Neutral HTF

If:

```text
HTF_DIRECTION == NEUTRAL
```

then do not use HTF as a tie-breaker.

Final result:

```text
CONFLICT
```

unless another deterministic resolver rule clearly separates the two sides.

---

# 13. HTF ALIGNMENT STRENGTH

Do not use only a Boolean value.

Calculate:

```text
HTF Alignment:
STRONG
MODERATE
WEAK
NEUTRAL
OPPOSITE
```

Example:

```text
LONG + Strong Bullish HTF = STRONG ALIGNMENT
LONG + Neutral HTF        = NEUTRAL
LONG + Bearish HTF        = OPPOSITE
```

The same applies inversely to SHORT.

---

# 14. HTF TIE-BREAKER SAFETY RULE

The HTF tie-breaker may only select a direction when:

```text
1. Both scenarios are technically READY.
2. Both pass all Hard Gates.
3. Neither has CRITICAL Market Risk.
4. Both meet minimum Execution Quality.
5. Score difference is below the normal winner threshold.
6. One direction has clearly stronger HTF structural alignment.
```

Otherwise:

```text
CONFLICT
```

---

# 15. EXAMPLE: HTF TIE-BREAKER

Example:

```text
LONG:
Score = 83
Status = READY
Execution = 4/5
Risk = MEDIUM
HTF Alignment = STRONG

SHORT:
Score = 81
Status = READY
Execution = 3/5
Risk = MEDIUM
HTF Alignment = OPPOSITE

Score Difference = 2
```

HTF = BULLISH.

Result:

```text
BUY
```

Reason:

```text
Both scenarios passed technical validation,
but LONG has strong HTF structural alignment
while SHORT is structurally counter-trend.
```

---

# 16. EXAMPLE: DO NOT FORCE A DECISION

Example:

```text
LONG:
Score = 84
READY
HTF Alignment = STRONG

SHORT:
Score = 82
READY
HTF Alignment = STRONG
```

If HTF structure itself is ambiguous or conflicting:

```text
Final Decision = CONFLICT
```

Do NOT force BUY.

---

# 17. EXECUTION ELIGIBILITY MUST BE APPLIED AFTER TECHNICAL ANALYSIS

The resolver should conceptually operate in this order:

```text
1. Evaluate LONG
2. Evaluate SHORT
3. Determine technical winners/conflict
4. Apply execution eligibility
5. Apply execution risk
6. Generate final decision
```

This prevents platform limitations from corrupting the underlying market analysis.

---

# 18. FINAL DECISION STATES

The system must support:

```text
BUY
SELL
WAIT
CONFLICT
```

Definitions:

### BUY

A technically valid LONG setup has been selected and is executable.

### SELL

A technically valid SHORT setup has been selected and is executable.

### WAIT

Neither side currently provides an executable trade.

### CONFLICT

Both directions are technically valid enough to remain contenders, but the system cannot establish sufficient deterministic directional superiority.

---

# 19. SPOT-SPECIFIC FINAL DECISION

Example:

```text
LONG:
72/100
NOT_READY

SHORT:
91/100
READY

Execution Mode:
SPOT

SHORT Eligibility:
NOT_ELIGIBLE
```

Final:

```text
WAIT
```

But the report MUST state:

```text
SHORT is technically READY,
but cannot be executed in SPOT mode.
```

This is NOT the same as:

```text
SHORT NOT_READY
```

---

# 20. READ-ONLY ANALYSIS + SEPARATE RESOLUTION

The following architecture is mandatory:

```python
context = build_market_context(...)

long_analysis = evaluate_long(
    context=context,
    config=config
)

short_analysis = evaluate_short(
    context=context,
    config=config
)

final_decision = resolve_final_decision(
    long_analysis=long_analysis,
    short_analysis=short_analysis,
    context=context,
    config=config
)
```

Neither evaluator may modify:

```text
context
other directional analysis
final decision
```

---

# 21. PERFORMANCE REQUIREMENT

The system should avoid repeated computation of:

```text
MA20
MA200
MFI10
RSI14
Swing Detection
BOS
CHoCH
FVG
Order Blocks
Liquidity
Order Book Metrics
```

These should be computed once and cached in `MarketContext`.

The only calculations that should remain direction-specific are those that genuinely depend on:

```text
LONG vs SHORT
```

such as:

- directional score assignment
- LONG/SHORT gate evaluation
- Entry direction
- SL direction
- TP direction
- directional order-book interpretation
- directional execution quality

---

# 22. CACHE INVALIDATION

The MarketContext cache must be invalidated when:

```text
New closed candle
OR
New analysis timestamp
OR
New order-book snapshot required
OR
Symbol changes
OR
Timeframe configuration changes
```

Do NOT reuse stale market context.

The cache key should include at minimum:

```text
symbol
analysis_timestamp
timeframe_configuration
data_version
```

For live Order Book data, use a separate short-lived cache with a configurable TTL.

---

# 23. BACKTEST REPRODUCIBILITY

The same historical timestamp must always generate the same:

```text
MarketContext
LONG result
SHORT result
Final decision
```

provided that:

```text
Historical Data
Configuration
Execution Mode
Risk Profile
```

are identical.

---

# 24. REPORTING

The report must explicitly separate:

```text
TECHNICAL STATUS
```

from:

```text
EXECUTION ELIGIBILITY
```

Example:

```text
🔴 SHORT

Technical Score:       91/100
Technical Status:      READY
Execution Eligibility: NOT_ELIGIBLE

Reason:
SPOT mode does not support SHORT execution.

Market Analysis:
VALID

Execution:
UNAVAILABLE
```

---

# 25. FINAL DESIGN PRINCIPLE

The architecture must preserve this fundamental separation:

```text
MARKET TRUTH
     ↓
TECHNICAL ANALYSIS
     ↓
LONG / SHORT SCENARIOS
     ↓
DIRECTIONAL RESOLUTION
     ↓
EXECUTION ELIGIBILITY
     ↓
RISK VALIDATION
     ↓
FINAL DECISION
```

Never reverse this order.

The execution platform must NOT influence the technical interpretation of the market.

The system must first determine:

```text
"What does the market currently offer?"
```

and only afterward determine:

```text
"Can the selected trading mode execute that opportunity?"
```

This architecture is mandatory for production code, live analysis, and backtesting.
