# ADDITIONAL MODULE: BALE AGENT CONTROL CENTER

Extend the existing Bale Bot interface into a control center for the Trading Agent.

The Bale interface must remain Persian and RTL-friendly.

## MAIN MENU

Provide a menu similar to:

```text
🤖 وضعیت ایجنت
📊 تحلیل بازار
⭐ نمادهای منتخب
⚙️ تنظیمات
🚨 هشدارها
📈 گزارش عملکرد
```

## AGENT STATUS

Show:

```text
🟢 وضعیت Agent: فعال
🟢 پایش بازار: فعال
🟢 نوبیتکس: متصل
🟢 Bale: متصل
🟢 Database: آماده

نمادهای فعال: 12
فاصله پایش: 5 دقیقه

آخرین پایش: [TIME]
```

## MONITORING CONTROLS

Buttons:

```text
▶️ شروع پایش
⏸ توقف پایش
🔄 ادامه پایش
```

## SYMBOL MANAGEMENT

Provide a Persian interactive symbol manager.

Functions:

- View selected symbols
- Add symbol
- Remove symbol
- Enable symbol
- Disable symbol
- Search symbol
- Edit watchlist

Support both:

- Rial
- Tether

## SETTINGS

Allow configuration of:

- Risk Profile
- Trading Mode
- Monitoring Interval
- Timeframes
- Scheduled Reports
- Event Alerts
- Alert Cooldown

## IMPORTANT

Bale commands must modify persistent configuration safely.

Changes must be validated before being applied.

Do not restart the entire application unnecessarily when changing a setting.

## ACCEPTANCE CRITERIA

- Bale can control monitoring.
- Bale can manage watchlist.
- Bale can display Agent status.
- Bale can modify supported settings.
- All user-facing text is Persian.