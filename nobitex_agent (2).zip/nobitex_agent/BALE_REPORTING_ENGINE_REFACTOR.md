# BALE REPORTING ENGINE REFACTOR
## Persian RTL Summary + On-Demand Detailed Reports

### OBJECTIVE

Refactor the existing Bale reporting layer without changing the existing market-analysis, scoring, risk-management, or execution logic.

The reporting system must generate **two distinct report levels** from the same stored `MarketAnalysisResult`:

1. **Summary Report**
   - Automatically sent to Bale after every analysis, scheduled scan, or alert.
   - This is the default report.
   - It must be concise and decision-oriented.

2. **Detailed Report**
   - Must NOT be sent automatically.
   - Sent only when the user explicitly requests it or presses the "View Detailed Analysis" button.
   - Must be generated from the already stored analysis result.
   - MUST NOT re-run the analysis engine.

The most important requirement is:

> **The internal Python code, class names, enums, variables, APIs, database fields, and technical architecture remain in English. Only the user-facing Bale reports must be Persian and RTL-oriented.**

---

# 1. LANGUAGE AND RTL REQUIREMENTS

All user-facing Bale report content MUST be written in Persian.

The report must be designed for a Persian-speaking user and must visually behave as an RTL report.

Do NOT generate English prose inside the report.

Do NOT translate technical identifiers into unnatural Persian terminology.

Technical trading terms should remain recognizable and may be presented with their Persian equivalent.

Examples:

```text
خرید (LONG)
فروش (SHORT)
شکاف ارزش منصفانه (FVG)
بلوک سفارش (Order Block)
بلوک شکست (Breaker Block)
بلوک تعدیل (Mitigation Block)
تغییر ساختار (CHoCH)
شکست ساختار (BOS)
میانگین متحرک ۲۰ (MA20)
میانگین متحرک ۲۰۰ (MA200)
شاخص جریان نقدینگی (MFI10)
شاخص قدرت نسبی (RSI14)
دفتر سفارشات (Order Book)
نقدینگی سمت خرید (BSL)
نقدینگی سمت فروش (SSL)
```

The code MUST NOT be localized.

For example, keep:

```python
DirectionalAnalysis
MarketAnalysisResult
SummaryReportGenerator
DetailedReportGenerator
ExecutionEligibility
FinalDecision
analysis_id
```

Do NOT rename these to Persian identifiers.

---

# 2. REPORT ARCHITECTURE

Implement the following architecture:

```text
Market Analysis Engine
        │
        ↓
MarketAnalysisResult
        │
        ↓
Persist Result
        │
        ├─────────────────────┐
        ↓                     ↓
SummaryReportGenerator   DetailedReportGenerator
        │                     │
        ↓                     ↓
   Bale Summary          Bale Detailed Report
```

Both report generators MUST consume the same `MarketAnalysisResult`.

The Detailed Report must never trigger another market analysis.

---

# 3. SINGLE ANALYSIS RESULT

Every analysis must receive a unique:

```python
analysis_id: UUID
```

The `analysis_id` must identify the exact analysis snapshot used to generate the report.

The stored result must contain enough information to generate both reports without recalculating the analysis.

Example:

```python
class StoredAnalysis(BaseModel):
    analysis_id: UUID
    symbol: str
    timestamp: datetime
    execution_mode: ExecutionMode
    risk_profile: RiskProfile

    market_context_snapshot: MarketContext | None

    long_analysis: DirectionalAnalysis
    short_analysis: DirectionalAnalysis

    final_decision: FinalDecision
    final_reason: str
```

The exact existing project models should be reused where possible.

Do not introduce duplicate analysis models unnecessarily.

---

# 4. SUMMARY REPORT

The Summary Report is the default Bale message.

It MUST be sent automatically after:

- scheduled analysis
- event-driven alert
- user-requested analysis
- high-confluence setup detection

The system MUST NOT automatically send the Detailed Report.

The Summary Report should answer these questions immediately:

1. What is the overall market direction?
2. What happened to LONG?
3. What happened to SHORT?
4. Which direction is stronger?
5. Is either direction technically READY?
6. Is either direction executable in the current trading mode?
7. Is the final decision BUY, SELL, WAIT, or CONFLICT?
8. Why?

---

# 5. SUMMARY REPORT FORMAT

The Bale Summary Report must follow this structure.

The actual user-facing text must be Persian.

Use this as the canonical structure:

```text
📊 تحلیل [SYMBOL]
━━━━━━━━━━━━━━━━━━

🕐 زمان: [TIME]
⚙️ حالت معامله: [SPOT / COMMITMENT]
🎯 پروفایل ریسک: [RISK PROFILE]

🌐 وضعیت بازار

روند تایم‌فریم بالا:
[🟢 صعودی / 🔴 نزولی / 🟡 خنثی]

۴ ساعته: [STATUS]
۱ ساعته: [STATUS]
۱۵ دقیقه: [STATUS]
۵ دقیقه: [STATUS]

━━━━━━━━━━━━━━━━━━

🟢 سناریوی خرید

امتیاز: [LONG_SCORE]/100
وضعیت فنی: [READY / NOT READY]
امکان اجرا: [ELIGIBLE / NOT ELIGIBLE]

نقطه مورد توجه: [POI]
هم‌راستایی HTF: [ALIGNMENT]
کیفیت ورود: [QUALITY]/5

━━━━━━━━━━━━━━━━━━

🔴 سناریوی فروش

امتیاز: [SHORT_SCORE]/100
وضعیت فنی: [READY / NOT READY]
امکان اجرا: [ELIGIBLE / NOT ELIGIBLE]

نقطه مورد توجه: [POI]
هم‌راستایی HTF: [ALIGNMENT]
کیفیت ورود: [QUALITY]/5

━━━━━━━━━━━━━━━━━━

⚖️ مقایسه دو سناریو

خرید: [SCORE] | [STATUS]
فروش: [SCORE] | [STATUS]

برتری:
[LONG / SHORT / NONE / CONFLICT]

━━━━━━━━━━━━━━━━━━

🎯 نتیجه نهایی

[BUY / SELL / WAIT / CONFLICT]

دلیل:
[SHORT PERSIAN HUMAN-READABLE REASON]

━━━━━━━━━━━━━━━━━━

🔍 مشاهده تحلیل کامل
```

The last item must be an Inline Keyboard button, not plain text.

---

# 6. IMPORTANT: WAIT MUST SHOW BOTH DIRECTIONS

A `WAIT` result must NEVER be represented as:

```text
شرایط خرید فراهم نیست.
```

because this incorrectly implies that only BUY was evaluated.

Instead, both directions must always be visible.

Example:

```text
🎯 نتیجه نهایی

⏸ WAIT

🟢 خرید:
73/100 | آماده نیست

🔴 فروش:
76/100 | آماده نیست

دلیل:
هیچ‌کدام از دو سناریوی خرید و فروش
در حال حاضر شرایط کامل ورود را ندارند.

⏳ سیستم منتظر تشکیل موقعیت معتبر است.
```

This distinction is mandatory.

The system evaluates LONG and SHORT independently before resolving the final decision.

---

# 7. READY VS EXECUTION ELIGIBILITY

Do not confuse technical readiness with platform execution capability.

The system must distinguish:

```text
Technical Status
```

from:

```text
Execution Eligibility
```

For example, in SPOT mode:

```text
🔴 سناریوی فروش

امتیاز: 91/100
وضعیت فنی: ✅ آماده
امکان اجرا: ❌ غیرمجاز

دلیل:
سناریوی فروش از نظر تکنیکال معتبر است،
اما حالت معاملاتی فعلی اسپات است
و فروش تعهدی در این حالت قابل اجرا نیست.
```

The analysis must NOT be discarded merely because the current execution mode cannot execute it.

The report must clearly communicate:

- technically valid
- executable or non-executable
- reason for non-execution

---

# 8. CONFLICT STATE

If both LONG and SHORT are technically READY and the resolver determines that neither direction has sufficient superiority, the final state must be:

```text
CONFLICT
```

Example:

```text
⚠️ تعارض جهت

🟢 خرید: 84/100 | آماده
🔴 فروش: 82/100 | آماده

اختلاف: 2 امتیاز

ساختار بازار برتری قطعی یکی از دو جهت
را تأیید نمی‌کند.

🎯 نتیجه:
CONFLICT

⏳ پیشنهاد سیستم:
فعلاً از ورود خودداری شود.
```

If the existing HTF tie-breaker rules resolve the conflict, show the resolved direction instead.

Do not invent a new tie-breaker inside the reporting layer.

The resolver remains part of the analysis engine.

---

# 9. DETAILED REPORT

The Detailed Report must be generated only when:

### Option A

The user presses:

```text
🔍 مشاهده تحلیل کامل
```

### Option B

The user explicitly requests a detailed report.

Recognize existing command/intent infrastructure where available.

Examples of Persian user requests:

```text
تحلیل کامل
گزارش کامل
جزئیات تحلیل
جزئیات
گزارش مفصل
```

Do not hard-code a second analysis flow for these commands.

Route them to the reporting layer using the stored `analysis_id`.

---

# 10. CRITICAL: DO NOT RE-RUN ANALYSIS

This is mandatory.

When the user requests the Detailed Report:

DO NOT execute:

```python
evaluate_long()
evaluate_short()
```

again.

DO NOT:

- fetch market data again
- recalculate indicators
- recalculate scoring
- recalculate POIs
- fetch Order Book again
- generate a new analysis snapshot

unless the existing architecture explicitly requires fresh data for a separate feature.

The normal Detailed Report flow must be:

```text
User clicks Detailed Report
        ↓
Read analysis_id
        ↓
Load StoredAnalysis
        ↓
DetailedReportGenerator
        ↓
Send Bale Message
```

Correct implementation pattern:

```python
async def handle_detailed_report(analysis_id: UUID):
    result = await analysis_repository.get(analysis_id)

    if result is None:
        return await send_analysis_not_found_message()

    report = detailed_report_generator.generate(result)

    await bale_client.send_message(report)
```

Incorrect implementation:

```python
async def handle_detailed_report():
    result = await run_full_analysis()
    report = generate_detailed_report(result)
```

---

# 11. DETAILED REPORT STRUCTURE

The Detailed Report must be entirely Persian in its user-facing text.

It must contain the following sections:

```text
۱. وضعیت کلی بازار

۲. ساختار چندتایم‌فریمی

۳. وضعیت MA20 / MA200

۴. سناریوی کامل خرید (LONG)

۵. امتیازدهی خرید

۶. نقاط مورد توجه خرید

۷. نقدینگی خرید

۸. MFI10 و RSI14 خرید

۹. تأیید تایم‌فریم پایین خرید

۱۰. Order Book خرید

۱۱. برنامه اجرای خرید

۱۲. سناریوی کامل فروش (SHORT)

۱۳. امتیازدهی فروش

۱۴. نقاط مورد توجه فروش

۱۵. نقدینگی فروش

۱۶. MFI10 و RSI14 فروش

۱۷. تأیید تایم‌فریم پایین فروش

۱۸. Order Book فروش

۱۹. برنامه اجرای فروش

۲۰. مقایسه خرید و فروش

۲۱. منطق تصمیم نهایی

۲۲. شرایط ابطال

۲۳. نتیجه نهایی
```

---

# 12. DETAILED REPORT CANONICAL FORMAT

Use this structure:

```text
📊 گزارش جامع تحلیل بازار
━━━━━━━━━━━━━━━━━━

نماد: BTC/USDT
بازار: نوبیتکس
حالت معامله: تعهدی
پروفایل ریسک: متوسط
زمان تحلیل: [TIME]

━━━━━━━━━━━━━━━━━━
🌐 ۱. وضعیت کلی بازار
━━━━━━━━━━━━━━━━━━

جهت غالب تایم‌فریم بالا: 🟢 صعودی

۴ ساعته:
روند: صعودی
ساختار: HH / HL
وضعیت: 🟢

۱ ساعته:
روند: صعودی
ساختار: BOS صعودی
وضعیت: 🟢

۱۵ دقیقه:
روند: اصلاحی
ساختار: Pullback
وضعیت: 🟡

۵ دقیقه:
روند: صعودی
ساختار: CHoCH صعودی
وضعیت: 🟢

MA200:
قیمت بالاتر از MA200

MA20:
بالاتر از MA200

━━━━━━━━━━━━━━━━━━
🟢 ۲. سناریوی خرید
━━━━━━━━━━━━━━━━━━

امتیاز: [SCORE]/100
وضعیت فنی: [STATUS]
امکان اجرا: [ELIGIBILITY]
ریسک: [RISK]
کیفیت ورود: [QUALITY]/5

📈 امتیازدهی:

روند و میانگین‌ها: [X]/25
نقطه مورد توجه: [X]/35
MFI10: [X]/20
RSI14: [X]/20

مجموع: [TOTAL]/100

🎯 نقطه مورد توجه:

نوع: [POI TYPE]
وضعیت: [ACTIVE / INVALID]
موقعیت: [PREMIUM / EQUILIBRIUM / DISCOUNT]

💧 نقدینگی:

[DETAIL]

📊 مومنتوم:

MFI10: [STATUS]
RSI14: [STATUS]
واگرایی: [STATUS]

⏱ تأیید تایم‌فریم پایین:

[DETAIL]

📖 دفتر سفارشات:

تعادل سفارشات: [STATUS]
حمایت: [PRICE]
مقاومت: [PRICE]
هشدار نقدینگی: [WARNING]

━━━━━━━━━━━━━━━━━━
📍 ۳. برنامه اجرای خرید
━━━━━━━━━━━━━━━━━━

محدوده ورود:
[ENTRY_ZONE]

ورود پیشنهادی:
[ENTRY]

حد ضرر:
[SL]

هدف اول:
[TP1]
نسبت سود به زیان: [RR1]

هدف دوم:
[TP2]
نسبت سود به زیان: [RR2]

هدف سوم:
[TP3]
نسبت سود به زیان: [RR3]

━━━━━━━━━━━━━━━━━━
🔴 ۴. سناریوی فروش
━━━━━━━━━━━━━━━━━━

امتیاز: [SCORE]/100
وضعیت فنی: [STATUS]
امکان اجرا: [ELIGIBILITY]
ریسک: [RISK]
کیفیت ورود: [QUALITY]/5

📉 امتیازدهی:

روند و میانگین‌ها: [X]/25
نقطه مورد توجه: [X]/35
MFI10: [X]/20
RSI14: [X]/20

مجموع: [TOTAL]/100

🎯 نقطه مورد توجه:

[DETAIL]

💧 نقدینگی:

[DETAIL]

📊 مومنتوم:

MFI10: [STATUS]
RSI14: [STATUS]
واگرایی: [STATUS]

⏱ تأیید تایم‌فریم پایین:

[DETAIL]

📖 دفتر سفارشات:

[DETAIL]

━━━━━━━━━━━━━━━━━━
📍 ۵. برنامه اجرای فروش
━━━━━━━━━━━━━━━━━━

ورود:
[ENTRY]

حد ضرر:
[SL]

هدف اول:
[TP1]

هدف دوم:
[TP2]

هدف سوم:
[TP3]

━━━━━━━━━━━━━━━━━━
⚖️ ۶. مقایسه دو سناریو
━━━━━━━━━━━━━━━━━━

🟢 خرید:
[SCORE]/100
[STATUS]

🔴 فروش:
[SCORE]/100
[STATUS]

اختلاف:
[DIFFERENCE]

هم‌راستایی HTF:

خرید: [ALIGNMENT]
فروش: [ALIGNMENT]

کیفیت ورود:

خرید: [QUALITY]
فروش: [QUALITY]

━━━━━━━━━━━━━━━━━━
🧠 ۷. منطق تصمیم
━━━━━━━━━━━━━━━━━━

[HUMAN_READABLE_PERSIAN_EXPLANATION]

━━━━━━━━━━━━━━━━━━
⚠️ ۸. شرایط ابطال
━━━━━━━━━━━━━━━━━━

[INVALIDATION_CONDITIONS]

━━━━━━━━━━━━━━━━━━
🎯 ۹. تصمیم نهایی
━━━━━━━━━━━━━━━━━━

[BUY / SELL / WAIT / CONFLICT]

دلیل:
[FINAL_REASON]

وضعیت فنی:
[STATUS]

امکان اجرا:
[ELIGIBILITY]

سطح ریسک:
[RISK]

وضعیت موقعیت:
[ACTIVE / WAITING / INVALIDATED]
```

---

# 13. AUTO ALERT REPORT

For automated alerts, send only the Summary Report.

Example:

```text
🚨 هشدار موقعیت

BTC/USDT

🟢 خرید
امتیاز: 88/100
وضعیت: آماده

ورود: XXXXX
حد ضرر: XXXXX
هدف اول: XXXXX
هدف دوم: XXXXX

ریسک: متوسط

🔍 مشاهده تحلیل کامل
```

The button must reference the exact `analysis_id` of the alert.

---

# 14. INLINE KEYBOARD

The Summary Report must include an Inline Keyboard.

Primary button:

```text
🔍 مشاهده تحلیل کامل
```

Callback format:

```text
detailed_analysis:{analysis_id}
```

The callback handler must retrieve the exact stored analysis.

Do not create a new analysis.

---

# 15. MULTIPLE SYMBOL SUPPORT

The `analysis_id` must uniquely identify the analysis instance.

Example:

```text
BTC/USDT → analysis_id_001
ETH/USDT → analysis_id_002
SOL/USDT → analysis_id_003
```

If the user requests the detailed report for BTC, only the BTC analysis must be returned.

---

# 16. REPORTING LAYER RESPONSIBILITIES

The reporting layer is responsible for:

- converting analysis results into human-readable Persian
- generating Summary Reports
- generating Detailed Reports
- generating Inline Keyboards
- displaying LONG and SHORT independently
- displaying technical status
- displaying execution eligibility
- displaying final resolver decision
- formatting numbers and prices
- formatting risk and R:R
- maintaining Persian RTL-friendly presentation

The reporting layer MUST NOT:

- calculate trading signals
- modify scores
- change the resolver result
- create new POIs
- change risk parameters
- override execution rules
- make trading decisions

The reporting layer is presentation-only.

---

# 17. RTL AND MIXED-DIRECTION TEXT

Because Persian text is RTL while symbols, numbers, prices, and technical identifiers are LTR, carefully format mixed-direction content.

Avoid producing confusing strings such as:

```text
84/100 امتیاز خرید BTC/USDT
```

when the rendering becomes visually ambiguous.

Prefer visually separated fields:

```text
امتیاز: 84 / 100

نماد: BTC/USDT

نسبت سود به زیان: 1 : 3
```

Keep prices, percentages, ratios, symbols, and technical identifiers in compact isolated fields whenever possible.

Use Unicode direction marks only when necessary.

Do not add unnecessary HTML unless Bale's supported message format requires it.

---

# 18. CODE QUALITY

Implement the reporting layer using clean separation of concerns.

Recommended structure:

```text
reporting/
    __init__.py
    summary_report.py
    detailed_report.py
    report_formatter.py
    report_keyboard.py
    report_localization.py
```

Suggested interfaces:

```python
class SummaryReportGenerator:
    def generate(self, result: StoredAnalysis) -> str:
        ...


class DetailedReportGenerator:
    def generate(self, result: StoredAnalysis) -> str:
        ...


class ReportKeyboardBuilder:
    def detailed_analysis_button(
        self,
        analysis_id: UUID
    ):
        ...
```

If the existing project already has equivalent components, adapt them rather than creating redundant architecture.

---

# 19. ERROR HANDLING

If the user requests a Detailed Report but the stored analysis no longer exists:

Return a Persian message such as:

```text
⚠️ گزارش تحلیل در دسترس نیست.

این تحلیل دیگر در حافظه سیستم وجود ندارد
یا منقضی شده است.

لطفاً یک تحلیل جدید درخواست کنید.
```

Do not run a new analysis automatically unless explicitly required by the existing product behavior.

---

# 20. FINAL ACCEPTANCE CRITERIA

The implementation is considered complete only if all of the following are true:

### Reporting

- [ ] Summary Report is automatically sent.
- [ ] Detailed Report is NOT automatically sent.
- [ ] Detailed Report is sent only on user request/button press.
- [ ] Both reports are generated from the same stored analysis result.
- [ ] Detailed Report does not re-run analysis.
- [ ] Every report has an `analysis_id`.

### Language

- [ ] All user-facing report prose is Persian.
- [ ] Reports are designed for RTL/Persian display.
- [ ] Technical terms remain recognizable.
- [ ] Internal code remains English.
- [ ] Database/model identifiers remain English.

### Analysis presentation

- [ ] LONG is always evaluated and displayed.
- [ ] SHORT is always evaluated and displayed.
- [ ] WAIT explicitly shows both directions were evaluated.
- [ ] CONFLICT is explicitly supported.
- [ ] Technical readiness is separate from execution eligibility.
- [ ] SPOT restrictions do not hide a technically valid SHORT scenario.

### Summary

- [ ] Market direction is shown.
- [ ] Multi-timeframe status is shown.
- [ ] LONG score/status is shown.
- [ ] SHORT score/status is shown.
- [ ] Comparison is shown.
- [ ] Final decision is shown.
- [ ] Final reason is shown.
- [ ] Detailed Report button is shown.

### Detailed

- [ ] Full market structure is shown.
- [ ] LONG analysis is shown.
- [ ] LONG scoring breakdown is shown.
- [ ] LONG POI/liquidity/momentum is shown.
- [ ] LONG Order Book analysis is shown.
- [ ] LONG execution plan is shown.
- [ ] SHORT analysis is shown.
- [ ] SHORT scoring breakdown is shown.
- [ ] SHORT POI/liquidity/momentum is shown.
- [ ] SHORT Order Book analysis is shown.
- [ ] SHORT execution plan is shown.
- [ ] LONG vs SHORT comparison is shown.
- [ ] Decision logic is shown.
- [ ] Invalidation conditions are shown.
- [ ] Final decision is shown.

---

# FINAL DESIGN PRINCIPLE

The system must behave like this:

```text
                ANALYSIS ENGINE
                       │
                       ↓
             MarketAnalysisResult
                       │
                       ↓
                STORE RESULT
                       │
                       ↓
              ┌─────────────────┐
              │ SUMMARY REPORT  │
              │ Persian + RTL   │
              └────────┬────────┘
                       │
                       ↓
                  SEND TO BALE
                       │
                       ↓
                 USER REQUEST
                       │
                       ↓
                 analysis_id
                       │
                       ↓
              LOAD STORED RESULT
                       │
                       ↓
             DETAILED REPORT
             Persian + RTL
                       │
                       ↓
                  SEND TO BALE
```

### NON-NEGOTIABLE RULE

**The first Bale message is always the concise Persian Summary Report.**

**The full Persian Detailed Report is sent only when the user explicitly requests it or presses the detailed-report button.**

**The Detailed Report must use the exact previously stored analysis result and must never silently perform a second analysis.**

Do not change the existing scoring, resolver, risk, POI, LONG/SHORT evaluation, or trading logic as part of this reporting refactor unless required strictly to expose already-existing fields to the reporting layer.